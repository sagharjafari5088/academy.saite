<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Academy_Site_Courses {
    const POST_TYPE = 'academy_course';
    const TAXONOMY  = 'academy_course_category';
    const TABLE     = 'academy_course_lessons';

    public static function boot() {
        add_action( 'init', array( __CLASS__, 'register_content_types' ) );
        add_action( 'add_meta_boxes', array( __CLASS__, 'register_meta_boxes' ) );
        add_action( 'save_post_' . self::POST_TYPE, array( __CLASS__, 'save_meta' ), 10, 2 );
        add_action( 'admin_post_academy_course_add_lesson', array( __CLASS__, 'admin_add_lesson' ) );
        add_action( 'admin_post_academy_course_delete_lesson', array( __CLASS__, 'admin_delete_lesson' ) );
        add_filter( 'academy_site_dynamic_data', array( __CLASS__, 'dynamic_data' ), 10, 2 );
    }

    public static function table_name() { global $wpdb; return $wpdb->prefix . self::TABLE; }

    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( "CREATE TABLE " . self::table_name() . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            course_id BIGINT UNSIGNED NOT NULL,
            chapter_title VARCHAR(255) NOT NULL DEFAULT '',
            lesson_title VARCHAR(255) NOT NULL,
            lesson_order INT UNSIGNED NOT NULL DEFAULT 0,
            duration_seconds INT UNSIGNED NOT NULL DEFAULT 0,
            video_attachment_id BIGINT UNSIGNED NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'draft',
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY course_order (course_id, lesson_order),
            KEY course_status (course_id, status),
            KEY video_attachment (video_attachment_id)
        ) " . $wpdb->get_charset_collate() . ";" );
    }

    public static function register_content_types() {
        register_post_type( self::POST_TYPE, array(
            'labels' => array( 'name' => 'دوره‌ها', 'singular_name' => 'دوره', 'add_new_item' => 'افزودن دوره', 'edit_item' => 'ویرایش دوره' ),
            'public' => true, 'show_in_rest' => true, 'menu_icon' => 'dashicons-welcome-learn-more',
            'supports' => array( 'title', 'editor', 'excerpt', 'thumbnail' ), 'has_archive' => true,
            'rewrite' => array( 'slug' => 'courses' ), 'capability_type' => array( 'academy_course', 'academy_courses' ), 'map_meta_cap' => true,
        ) );
        register_taxonomy( self::TAXONOMY, self::POST_TYPE, array(
            'labels' => array( 'name' => 'دسته‌بندی دوره‌ها', 'singular_name' => 'دسته‌بندی دوره' ),
            'public' => true, 'show_in_rest' => true, 'hierarchical' => true, 'rewrite' => array( 'slug' => 'course-category' ),
        ) );
    }

    public static function register_meta_boxes() {
        add_meta_box( 'academy-course-settings', 'اطلاعات دوره', array( __CLASS__, 'render_settings' ), self::POST_TYPE, 'normal', 'high' );
        add_meta_box( 'academy-course-lessons', 'فصل‌ها و Lessonها', array( __CLASS__, 'render_lessons' ), self::POST_TYPE, 'normal', 'default' );
    }

    public static function render_settings( $post ) {
        wp_nonce_field( 'academy_course_save', 'academy_course_nonce' );
        $status = get_post_meta( $post->ID, '_academy_course_status', true ) ?: 'draft';
        $subtitle = get_post_meta( $post->ID, '_academy_course_subtitle', true );
        $coming = get_post_meta( $post->ID, '_academy_course_coming_soon', true );
        $price = get_post_meta( $post->ID, '_academy_course_price', true );
        $regular_price = get_post_meta( $post->ID, '_academy_course_regular_price', true );
        $sale_price = get_post_meta( $post->ID, '_academy_course_sale_price', true );
        $banner = get_post_meta( $post->ID, '_academy_course_banner_id', true );
        $trailer = get_post_meta( $post->ID, '_academy_course_trailer_url', true );
        $instructor = get_post_meta( $post->ID, '_academy_course_instructor_id', true );
        $duration = get_post_meta( $post->ID, '_academy_course_duration', true );
        $sessions = get_post_meta( $post->ID, '_academy_course_sessions', true );
        $outcomes = get_post_meta( $post->ID, '_academy_course_outcomes', true );
        $certificate_type = get_post_meta( $post->ID, '_academy_course_certificate_type', true );
        $certificate_online = get_post_meta( $post->ID, '_academy_course_certificate_online', true );
        ?>
        <table class="form-table"><tr><th>زیرعنوان دوره</th><td><input class="regular-text" name="academy_course_subtitle" value="<?php echo esc_attr( $subtitle ); ?>"></td></tr>
            <tr><th>وضعیت فروش</th><td><select name="academy_course_status"><option value="draft" <?php selected( $status, 'draft' ); ?>>پیش‌نویس</option><option value="active" <?php selected( $status, 'active' ); ?>>فعال</option><option value="closed" <?php selected( $status, 'closed' ); ?>>بسته</option></select></td></tr>
            <tr><th>Coming Soon</th><td><label><input type="checkbox" name="academy_course_coming_soon" value="1" <?php checked( $coming, '1' ); ?>> فعال</label></td></tr>
            <tr><th>قیمت فعلی</th><td><input type="number" min="0" name="academy_course_price" value="<?php echo esc_attr( $price ); ?>"></td></tr>
            <tr><th>قیمت اصلی</th><td><input type="number" min="0" name="academy_course_regular_price" value="<?php echo esc_attr( $regular_price ); ?>"></td></tr>
            <tr><th>قیمت تخفیف‌خورده</th><td><input type="number" min="0" name="academy_course_sale_price" value="<?php echo esc_attr( $sale_price ); ?>"></td></tr>
            <tr><th>Banner Attachment ID</th><td><input type="number" min="0" name="academy_course_banner_id" value="<?php echo esc_attr( $banner ); ?>"></td></tr>
            <tr><th>Trailer URL</th><td><input type="url" name="academy_course_trailer_url" value="<?php echo esc_attr( $trailer ); ?>"></td></tr>
            <tr><th>مدرس دوره</th><td><select name="academy_course_instructor_id"><option value="0">بدون مدرس</option><?php if ( class_exists( 'Academy_Site_Instructors' ) ) : foreach ( Academy_Site_Instructors::get_all() as $teacher ) : ?><option value="<?php echo absint( $teacher['id'] ); ?>" <?php selected( $instructor, $teacher['id'] ); ?>><?php echo esc_html( $teacher['name'] ); ?></option><?php endforeach; endif; ?></select></td></tr>
            <tr><th>مدت دوره</th><td><input type="text" name="academy_course_duration" value="<?php echo esc_attr( $duration ); ?>" placeholder="مثلاً ۲۳ ساعت"></td></tr>
            <tr><th>تعداد جلسات</th><td><input type="number" min="0" name="academy_course_sessions" value="<?php echo esc_attr( $sessions ); ?>"></td></tr>
            <tr><th>آنچه در دوره خواهید آموخت</th><td><textarea name="academy_course_outcomes" rows="6" style="width:100%" placeholder="هر مورد را در یک خط بنویسید"><?php echo esc_textarea( $outcomes ); ?></textarea><p class="description">هر خط یک مورد آموزشی است.</p></td></tr>
            <tr><th>نوع گواهینامه</th><td><input type="text" name="academy_course_certificate_type" value="<?php echo esc_attr( $certificate_type ); ?>" placeholder="مثلاً گواهینامه رسمی آکادمی"></td></tr><tr><th>گواهینامه آنلاین</th><td><label><input type="checkbox" name="academy_course_certificate_online" value="1" <?php checked( $certificate_online, '1' ); ?>> دارد</label></td></tr>
        </table>
        <?php
    }

    public static function render_lessons( $post ) {
        $lessons = self::get_lessons( $post->ID ); ?>
        <p>این بخش فقط داده آموزشی را مدیریت می‌کند؛ ظاهر دوره و Lessonها در Elementor طراحی می‌شود.</p>
        <table class="widefat striped"><thead><tr><th>فصل</th><th>Lesson</th><th>ترتیب</th><th>مدت</th><th>وضعیت</th><th></th></tr></thead><tbody>
        <?php foreach ( $lessons as $lesson ) : ?><tr><td><?php echo esc_html( $lesson->chapter_title ); ?></td><td><?php echo esc_html( $lesson->lesson_title ); ?></td><td><?php echo esc_html( $lesson->lesson_order ); ?></td><td><?php echo esc_html( $lesson->duration_seconds ); ?></td><td><?php echo esc_html( $lesson->status ); ?></td><td><a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=academy_course_delete_lesson&course_id=' . $post->ID . '&lesson_id=' . absint( $lesson->id ) ), 'academy_delete_lesson_' . $post->ID ) ); ?>">حذف</a></td></tr><?php endforeach; ?>
        </tbody></table><hr><h4>افزودن Lesson</h4>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="academy_course_add_lesson"><input type="hidden" name="course_id" value="<?php echo absint( $post->ID ); ?>"><?php wp_nonce_field( 'academy_add_lesson_' . $post->ID ); ?>
        <p><input required type="text" name="chapter_title" placeholder="عنوان فصل"></p><p><input required type="text" name="lesson_title" placeholder="عنوان Lesson"></p><p><input type="number" min="0" name="lesson_order" placeholder="ترتیب"></p><p><input type="number" min="0" name="duration_seconds" placeholder="مدت به ثانیه"></p><p><input type="number" min="0" name="video_attachment_id" placeholder="Video Attachment ID"></p><p><select name="status"><option value="published">Published</option><option value="draft">Draft</option></select></p><p><button class="button button-primary">افزودن Lesson</button></p></form>
        <?php
    }

    public static function save_meta( $post_id, $post ) {
        if ( ! isset( $_POST['academy_course_nonce'] ) ) return;
        if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['academy_course_nonce'] ) ), 'academy_course_save' ) ) return;
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) return;
        $values = array(
            '_academy_course_subtitle' => sanitize_text_field( wp_unslash( $_POST['academy_course_subtitle'] ?? '' ) ),
            '_academy_course_status' => sanitize_key( $_POST['academy_course_status'] ?? 'draft' ),
            '_academy_course_coming_soon' => isset( $_POST['academy_course_coming_soon'] ) ? '1' : '0',
            '_academy_course_price' => absint( $_POST['academy_course_price'] ?? 0 ),
            '_academy_course_regular_price' => absint( $_POST['academy_course_regular_price'] ?? 0 ),
            '_academy_course_sale_price' => absint( $_POST['academy_course_sale_price'] ?? 0 ),
            '_academy_course_banner_id' => absint( $_POST['academy_course_banner_id'] ?? 0 ),
            '_academy_course_trailer_url' => esc_url_raw( wp_unslash( $_POST['academy_course_trailer_url'] ?? '' ) ),
            '_academy_course_instructor_id' => absint( $_POST['academy_course_instructor_id'] ?? 0 ),
            '_academy_course_duration' => sanitize_text_field( wp_unslash( $_POST['academy_course_duration'] ?? '' ) ),
            '_academy_course_sessions' => absint( $_POST['academy_course_sessions'] ?? 0 ),
            '_academy_course_outcomes' => sanitize_textarea_field( wp_unslash( $_POST['academy_course_outcomes'] ?? '' ) ),
            '_academy_course_certificate_online' => isset( $_POST['academy_course_certificate_online'] ) ? '1' : '0',
            '_academy_course_certificate_type' => sanitize_text_field( wp_unslash( $_POST['academy_course_certificate_type'] ?? '' ) ),
        );
        foreach ( $values as $key => $value ) update_post_meta( $post_id, $key, $value );
    }

    public static function get_lessons( $course_id, $status = '' ) {
        global $wpdb; $sql = 'SELECT * FROM ' . self::table_name() . ' WHERE course_id = %d'; $args = array( absint( $course_id ) );
        if ( '' !== $status ) { $sql .= ' AND status = %s'; $args[] = sanitize_key( $status ); }
        $sql .= ' ORDER BY lesson_order ASC, id ASC'; return $wpdb->get_results( $wpdb->prepare( $sql, $args ) );
    }

    public static function add_lesson( $course_id, array $data ) {
        global $wpdb; $now = current_time( 'mysql', true );
        $ok = $wpdb->insert( self::table_name(), array(
            'course_id' => absint( $course_id ), 'chapter_title' => sanitize_text_field( $data['chapter_title'] ?? '' ), 'lesson_title' => sanitize_text_field( $data['lesson_title'] ?? '' ),
            'lesson_order' => absint( $data['lesson_order'] ?? 0 ), 'duration_seconds' => absint( $data['duration_seconds'] ?? 0 ),
            'video_attachment_id' => absint( $data['video_attachment_id'] ?? 0 ) ?: null, 'status' => in_array( $data['status'] ?? 'draft', array( 'draft','published' ), true ) ? $data['status'] : 'draft',
            'created_at' => $now, 'updated_at' => $now,
        ), array( '%d','%s','%s','%d','%d','%d','%s','%s','%s' ) );
        return false === $ok ? 0 : (int) $wpdb->insert_id;
    }

    public static function delete_lesson( $course_id, $lesson_id ) { global $wpdb; return (int) $wpdb->delete( self::table_name(), array( 'id' => absint( $lesson_id ), 'course_id' => absint( $course_id ) ), array( '%d','%d' ) ); }

    public static function admin_add_lesson() {
        $course_id = absint( $_POST['course_id'] ?? 0 ); if ( ! $course_id || ! current_user_can( 'edit_post', $course_id ) ) wp_die( 'دسترسی غیرمجاز.' ); check_admin_referer( 'academy_add_lesson_' . $course_id );
        if ( '' === trim( (string) ( $_POST['chapter_title'] ?? '' ) ) || '' === trim( (string) ( $_POST['lesson_title'] ?? '' ) ) ) wp_die( 'عنوان فصل و Lesson الزامی است.' );
        self::add_lesson( $course_id, array( 'chapter_title' => wp_unslash( $_POST['chapter_title'] ), 'lesson_title' => wp_unslash( $_POST['lesson_title'] ), 'lesson_order' => $_POST['lesson_order'] ?? 0, 'duration_seconds' => $_POST['duration_seconds'] ?? 0, 'video_attachment_id' => $_POST['video_attachment_id'] ?? 0, 'status' => sanitize_key( $_POST['status'] ?? 'draft' ) ) );
        wp_safe_redirect( get_edit_post_link( $course_id, 'raw' ) ); exit;
    }

    public static function admin_delete_lesson() {
        $course_id = absint( $_GET['course_id'] ?? 0 ); $lesson_id = absint( $_GET['lesson_id'] ?? 0 ); if ( ! $course_id || ! current_user_can( 'edit_post', $course_id ) ) wp_die( 'دسترسی غیرمجاز.' ); check_admin_referer( 'academy_delete_lesson_' . $course_id ); self::delete_lesson( $course_id, $lesson_id ); wp_safe_redirect( get_edit_post_link( $course_id, 'raw' ) ); exit;
    }

    public static function get_course( $course_id ) {
        $post = get_post( absint( $course_id ) ); if ( ! $post || self::POST_TYPE !== $post->post_type ) return null;
        return array(
            'id' => (int) $post->ID, 'title' => get_the_title( $post ), 'description' => $post->post_content, 'excerpt' => get_the_excerpt( $post ),
            'image_id' => (int) get_post_thumbnail_id( $post ), 'banner_id' => (int) get_post_meta( $post->ID, '_academy_course_banner_id', true ),
            'trailer_url' => esc_url( get_post_meta( $post->ID, '_academy_course_trailer_url', true ) ), 'instructor_id' => (int) get_post_meta( $post->ID, '_academy_course_instructor_id', true ),
            'price' => (int) get_post_meta( $post->ID, '_academy_course_price', true ),
            'duration' => sanitize_text_field( get_post_meta( $post->ID, '_academy_course_duration', true ) ),
            'sessions' => absint( get_post_meta( $post->ID, '_academy_course_sessions', true ) ),
            'outcomes' => sanitize_textarea_field( get_post_meta( $post->ID, '_academy_course_outcomes', true ) ),
            'certificate_type' => sanitize_text_field( get_post_meta( $post->ID, '_academy_course_certificate_type', true ) ),
            'status' => sanitize_key( get_post_meta( $post->ID, '_academy_course_status', true ) ?: 'draft' ),
            'coming_soon' => '1' === get_post_meta( $post->ID, '_academy_course_coming_soon', true ), 'categories' => wp_get_post_terms( $post->ID, self::TAXONOMY, array( 'fields' => 'ids' ) ),
        );
    }

    public static function dynamic_data( $data, $context ) { if ( is_singular( self::POST_TYPE ) ) $data['course'] = self::get_course( get_the_ID() ); return $data; }
}
