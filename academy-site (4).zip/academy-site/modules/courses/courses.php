<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
require_once __DIR__ . '/class-courses.php';
Academy_Site_Courses::boot();
