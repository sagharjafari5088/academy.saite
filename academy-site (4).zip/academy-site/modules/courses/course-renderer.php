<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Academy_Site_Course_Renderer {
    public static function boot() {
        add_filter( 'academy_site_render_map', array( __CLASS__, 'map' ), 20, 3 );
    }
    public static function map( $map, $type, $data ) {
        if ( 'course' !== $type ) return $map;
        $d = is_array( $data ) ? $data : (array) $data;
        $id = absint( $d['id'] ?? 0 );
        $url = $id ? get_permalink( $id ) : '#';
        $m = array();
        $img_id = absint( $d['image_id'] ?? 0 );
            $instructor = class_exists( 'Academy_Site_Instructors' ) ? Academy_Site_Instructors::get_instructor( absint( $d['instructor_id'] ?? 0 ) ) : null;
            $terms = $id ? wp_get_post_terms( $id, 'academy_course_category', array( 'fields' => 'names' ) ) : array();
            $category = ( ! is_wp_error( $terms ) && $terms ) ? implode( '، ', $terms ) : '';
            $coming = ! empty( $d['coming_soon'] );
            $action = Academy_Site_HTML_Renderer::course_action( $id, $coming );
            $certificate = ( is_user_logged_in() && class_exists( 'Academy_Site_Certificates' ) )
                ? Academy_Site_Certificates::get_by_user_course( get_current_user_id(), $id )
                : null;
            $pricing = Academy_Site_HTML_Renderer::course_pricing( $id, $d['price'] ?? 0 );

            $m = array(
                'course_id'             => (string) $id,
                'course_title'         => esc_html( $d['title'] ?? '' ),
                'course_subtitle'      => esc_html( $d['subtitle'] ?? get_post_meta( $id, '_academy_course_subtitle', true ) ),
                'course_description'   => wp_kses_post( $d['description'] ?? '' ),
                'course_excerpt'       => wp_kses_post( $d['excerpt'] ?? '' ),
                'course_category'      => esc_html( $category ),
                'course_image'         => $d['image_html'] ?? ( $img_id ? wp_get_attachment_image( $img_id, 'full', false, array( 'class' => 'academy-course-image' ) ) : '' ),
                'course_image_url'     => esc_url( $d['image_url'] ?? ( $img_id ? wp_get_attachment_image_url( $img_id, 'full' ) : '' ) ),
                'course_price'         => esc_html( $pricing['current_display'] ),
                'course_regular_price' => esc_html( $pricing['regular_display'] ),
                'course_sale_price'    => esc_html( $pricing['sale_display'] ),
                'course_discount_percent' => esc_html( $pricing['discount_percent'] ),
                'course_has_discount'  => $pricing['has_discount'] ? '1' : '0',
                'course_price_html'    => $pricing['html'],
                'course_duration'      => esc_html( $d['duration'] ?? '' ),
                'course_sessions'     => ! empty( $d['sessions'] ) ? esc_html( number_format_i18n( absint( $d['sessions'] ) ) ) : '',
                'course_outcomes'     => Academy_Site_HTML_Renderer::outcomes_html( $d['outcomes'] ?? '' ),
                'course_certificate_type' => esc_html( $d['certificate_type'] ?? '' ),
                'course_certificate_online' => '1' === (string)get_post_meta( $id, '_academy_course_certificate_online', true ) ? 'دارد' : 'ندارد',
                'course_status'        => esc_html( $d['status'] ?? '' ),
                'coming_soon'          => $coming ? '<span class="academy-coming-soon">به‌زودی</span>' : '',
                'course_action'        => $action['html'],
                'course_action_url'    => esc_url( $action['url'] ),
                'course_url'           => esc_url( $url ),
                'course_instructor'    => $instructor ? esc_html( $instructor['name'] ?? '' ) : '',
                'course_instructor_url'=> $instructor ? esc_url( get_permalink( $instructor['id'] ) ) : '',
                'course_qr_url'        => class_exists( 'Academy_Site_QR' ) ? esc_url( Academy_Site_QR::image_url( $url, 220 ) ) : '',
                'course_qr'            => class_exists( 'Academy_Site_QR' ) ? Academy_Site_QR::image_html( $url, 'academy-course-qr', 'QR دوره', 220 ) : '',
                'certificate_verification_url' => ( $certificate && class_exists( 'Academy_Site_QR' ) ) ? esc_url( Academy_Site_QR::certificate_url( $certificate->verification_code ) ) : '',
                'certificate_qr_url'    => ( $certificate && class_exists( 'Academy_Site_QR' ) ) ? esc_url( Academy_Site_QR::image_url( Academy_Site_QR::certificate_url( $certificate->verification_code ), 220 ) ) : '',
                'certificate_qr'        => ( $certificate && class_exists( 'Academy_Site_QR' ) ) ? Academy_Site_QR::image_html( Academy_Site_QR::certificate_url( $certificate->verification_code ), 'academy-certificate-qr', 'QR گواهینامه', 220 ) : '',
                'course_certificate'   => $certificate ? $certificate : '',
                'certificate_html'      => ( $certificate && class_exists( 'Academy_Site_Certificates' ) ) ? Academy_Site_Certificates::render_certificate( $certificate ) : '',
                'certificate_verification_code' => $certificate ? esc_html( $certificate->verification_code ) : '',
                'certificate_title' => $certificate ? esc_html( $certificate->course_id ? get_the_title( $certificate->course_id ) : 'گواهینامه' ) : '',
                'certificate_student_name' => $certificate ? esc_html( get_the_author_meta( 'display_name', $certificate->user_id ) ) : '',
                'certificate_national_id' => $certificate ? esc_html( $certificate->national_id ) : '',
                'certificate_course_name' => $certificate && $certificate->course_id ? esc_html( get_the_title( $certificate->course_id ) ) : '',
                'certificate_issued_at' => $certificate ? esc_html( $certificate->issued_at ) : '',
                'certificate_qr' => ( $certificate && class_exists( 'Academy_Site_QR' ) ) ? Academy_Site_QR::image_html( Academy_Site_QR::certificate_url( $certificate->verification_code ), 'academy-certificate-qr', 'QR گواهینامه', 220 ) : '',
            );
        return $m;
    }
}
Academy_Site_Course_Renderer::boot();
