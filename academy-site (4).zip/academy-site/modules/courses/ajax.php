<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
// Reserved for authenticated course actions; no presentation logic lives here.
