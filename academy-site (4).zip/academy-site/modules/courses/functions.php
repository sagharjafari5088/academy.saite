<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
function academy_site_get_course( $course_id ) { return Academy_Site_Courses::get_course( $course_id ); }
function academy_site_get_course_lessons( $course_id, $status = '' ) { return Academy_Site_Courses::get_lessons( $course_id, $status ); }
