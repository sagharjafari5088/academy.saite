<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Academy_Site_Lesson_Renderer {
    public static function boot() {
        add_filter( 'academy_site_render_map', array( __CLASS__, 'map' ), 20, 3 );
    }
    public static function map( $map, $type, $data ) {
        if ( 'lesson' !== $type ) return $map;
        $d = is_array( $data ) ? $data : (array) $data;
        $id = absint( $d['id'] ?? 0 );
        $url = $id ? get_permalink( $id ) : '#';
        $m = array();
        $obj = is_object( $d ) ? $d : (object) $d;
            $video_id = absint( $obj->video_attachment_id ?? 0 );
            $m = array(
                'lesson_id'          => (string) ( $obj->id ?? 0 ),
                'lesson_chapter'     => esc_html( $obj->chapter_title ?? '' ),
                'lesson_title'       => esc_html( $obj->lesson_title ?? '' ),
                'lesson_order'       => (string) ( $obj->lesson_order ?? 0 ),
                'lesson_duration'    => esc_html( Academy_Site_HTML_Renderer::duration( $obj->duration_seconds ?? 0 ) ),
                'lesson_video_url'   => $video_id ? esc_url( wp_get_attachment_url( $video_id ) ) : '',
                'lesson_action'      => $video_id ? '<a class="academy-lesson-action" href="' . esc_url( wp_get_attachment_url( $video_id ) ) . '">مشاهده</a>' : '',
            );
        return $m;
    }
}
Academy_Site_Lesson_Renderer::boot();
