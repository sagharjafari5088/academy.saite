<?php
if(!defined('ABSPATH'))exit;
final class Academy_Site_Faq{
 const POST_TYPE='academy_faq';
 public static function boot(){add_action('init',array(__CLASS__,'cpt'));add_action('add_meta_boxes',array(__CLASS__,'boxes'));add_action('save_post_'.self::POST_TYPE,array(__CLASS__,'save'),10,2);}
 public static function cpt(){register_post_type(self::POST_TYPE,array('labels'=>array('name'=>'سوالات متداول','singular_name'=>'سوال متداول','add_new_item'=>'افزودن سوال متداول','edit_item'=>'ویرایش سوال متداول'),'public'=>true,'show_in_rest'=>true,'menu_icon'=>'dashicons-editor-help','supports'=>array('title','editor','excerpt','thumbnail'),'has_archive'=>true,'rewrite'=>array('slug'=>'faq')));}
 public static function boxes(){add_meta_box('academy-faq-meta','پاسخ سوال',array(__CLASS__,'box'),self::POST_TYPE,'normal','high');}
public static function box($post){wp_nonce_field('academy_faq_save','academy_faq_nonce');echo '<textarea class="widefat" rows="7" name="academy_faq_answer">'.esc_textarea(get_post_meta($post->ID,'_academy_faq_answer',true)).'</textarea>'; }
public static function save($id,$post){if(!isset($_POST['academy_faq_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['academy_faq_nonce'])),'academy_faq_save'))return;if(defined('DOING_AUTOSAVE')&&DOING_AUTOSAVE)return;if(wp_is_post_revision($id)||!current_user_can('edit_post',$id))return;update_post_meta($id,'_academy_faq_answer',wp_kses_post(wp_unslash($_POST['academy_faq_answer']??'')));}
public static function get($id){$p=get_post(absint($id));if(!$p||$p->post_type!==self::POST_TYPE)return null;return array('id'=>(int)$id,'title'=>get_the_title($p),'answer'=>get_post_meta($id,'_academy_faq_answer',true),'content'=>$p->post_content);}

 public static function all(){$ps=get_posts(array('post_type'=>self::POST_TYPE,'post_status'=>'publish','posts_per_page'=>-1,'orderby'=>'date','order'=>'DESC'));$o=array();foreach($ps as $p){$d=self::get($p->ID);if($d)$o[]=$d;}return $o;}
}
Academy_Site_Faq::boot();
