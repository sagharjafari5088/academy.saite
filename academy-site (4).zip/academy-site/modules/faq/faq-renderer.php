<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Academy_Site_Faq_Renderer {
    public static function boot() {
        add_filter( 'academy_site_render_map', array( __CLASS__, 'map' ), 20, 3 );
    }
    public static function map( $map, $type, $data ) {
        if ( 'faq' !== $type ) return $map;
        $d = is_array( $data ) ? $data : (array) $data;
        $id = absint( $d['id'] ?? 0 );
        $url = $id ? get_permalink( $id ) : '#';
        $m = array();
        $m = array(
                'faq_id'       => (string) $id,
                'faq_question' => esc_html( $d['title'] ?? '' ),
                'faq_answer'   => wp_kses_post( $d['answer'] ?? '' ),
            );
        return $m;
    }
}
Academy_Site_Faq_Renderer::boot();
