<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Academy_Site_Enrollment {
    const TABLE = 'academy_enrollments';

    public static function boot() {
        add_filter( 'academy_site_user_has_course_access', array( __CLASS__, 'has_access_filter' ), 10, 3 );
        add_filter( 'academy_site_dynamic_data', array( __CLASS__, 'dynamic_data' ), 20, 2 );
        add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
        add_action( 'admin_post_academy_enrollment_grant', array( __CLASS__, 'admin_grant' ) );
        add_action( 'admin_post_academy_enrollment_revoke', array( __CLASS__, 'admin_revoke' ) );

        // Decoupled integration points for WooCommerce/other commerce providers.
        add_action( 'academy_site_payment_completed', array( __CLASS__, 'grant_from_payment' ), 10, 4 );
        add_action( 'academy_site_payment_refunded', array( __CLASS__, 'revoke_from_refund' ), 10, 3 );
    }

    public static function table_name() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE;
    }

    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( "CREATE TABLE " . self::table_name() . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            course_id BIGINT UNSIGNED NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            source VARCHAR(30) NOT NULL DEFAULT 'manual',
            source_reference VARCHAR(100) NULL,
            starts_at DATETIME NULL,
            expires_at DATETIME NULL,
            revoked_at DATETIME NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY user_course (user_id, course_id),
            KEY user_status (user_id, status),
            KEY course_status (course_id, status),
            KEY source_reference (source, source_reference),
            KEY expires_at (expires_at)
        ) " . $wpdb->get_charset_collate() . ";" );
    }

    public static function get( $user_id, $course_id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            'SELECT * FROM ' . self::table_name() . ' WHERE user_id = %d AND course_id = %d LIMIT 1',
            absint( $user_id ), absint( $course_id )
        ) );
    }

    public static function has_access( $user_id, $course_id ) {
        $row = self::get( $user_id, $course_id );
        if ( ! $row || 'active' !== $row->status ) return false;
        $now = current_time( 'timestamp', true );
        if ( $row->starts_at && strtotime( $row->starts_at . ' UTC' ) > $now ) return false;
        if ( $row->expires_at && strtotime( $row->expires_at . ' UTC' ) <= $now ) return false;
        return true;
    }

    public static function grant( $user_id, $course_id, $args = array() ) {
        global $wpdb;
        $user_id = absint( $user_id ); $course_id = absint( $course_id );
        if ( ! $user_id || ! get_user_by( 'id', $user_id ) ) return new WP_Error( 'invalid_user', 'کاربر معتبر نیست.' );
        if ( 'academy_course' !== get_post_type( $course_id ) ) return new WP_Error( 'invalid_course', 'دوره معتبر نیست.' );

        $args = wp_parse_args( $args, array(
            'status' => 'active', 'source' => 'manual', 'source_reference' => '', 'starts_at' => null, 'expires_at' => null,
        ) );
        $status = in_array( $args['status'], array( 'active', 'paused', 'revoked' ), true ) ? $args['status'] : 'active';
        $source = sanitize_key( $args['source'] );
        $reference = sanitize_text_field( $args['source_reference'] );
        $starts = self::normalize_datetime( $args['starts_at'] );
        $expires = self::normalize_datetime( $args['expires_at'] );
        $now = current_time( 'mysql', true );
        $existing = self::get( $user_id, $course_id );

        $data = array(
            'status' => $status, 'source' => $source, 'source_reference' => $reference,
            'starts_at' => $starts, 'expires_at' => $expires, 'revoked_at' => null, 'updated_at' => $now,
        );
        $formats = array( '%s','%s','%s','%s','%s','%s','%s' );

        if ( $existing ) {
            $ok = $wpdb->update( self::table_name(), $data, array( 'id' => (int) $existing->id ), $formats, array( '%d' ) );
            if ( false === $ok ) return new WP_Error( 'db_error', 'به‌روزرسانی دسترسی ناموفق بود.' );
            do_action( 'academy_site_enrollment_granted', (int) $existing->id, $user_id, $course_id, $args );
            return (int) $existing->id;
        }

        $data['user_id'] = $user_id; $data['course_id'] = $course_id; $data['created_at'] = $now;
        $ok = $wpdb->insert( self::table_name(), $data, array( '%s','%s','%s','%s','%s','%s','%s','%d','%d','%s' ) );
        if ( false === $ok ) {
            $existing = self::get( $user_id, $course_id );
            return $existing ? self::grant( $user_id, $course_id, $args ) : new WP_Error( 'db_error', 'ایجاد دسترسی ناموفق بود.' );
        }
        $id = (int) $wpdb->insert_id;
        do_action( 'academy_site_enrollment_granted', $id, $user_id, $course_id, $args );
        return $id;
    }

    public static function revoke( $user_id, $course_id, $reason = 'manual' ) {
        global $wpdb;
        $row = self::get( $user_id, $course_id );
        if ( ! $row ) return true;
        $ok = $wpdb->update( self::table_name(), array(
            'status' => 'revoked', 'revoked_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ),
        ), array( 'id' => (int) $row->id ), array( '%s','%s','%s' ), array( '%d' ) );
        if ( false === $ok ) return new WP_Error( 'db_error', 'لغو دسترسی ناموفق بود.' );
        do_action( 'academy_site_enrollment_revoked', (int) $row->id, absint( $user_id ), absint( $course_id ), sanitize_text_field( $reason ) );
        return true;
    }

    public static function get_user_enrollments( $user_id, $status = '' ) {
        global $wpdb; $args = array( absint( $user_id ) );
        $sql = 'SELECT * FROM ' . self::table_name() . ' WHERE user_id = %d';
        if ( '' !== $status ) { $sql .= ' AND status = %s'; $args[] = sanitize_key( $status ); }
        $sql .= ' ORDER BY created_at DESC';
        return $wpdb->get_results( $wpdb->prepare( $sql, $args ) );
    }

    public static function has_access_filter( $current, $user_id, $course_id ) { return self::has_access( $user_id, $course_id ); }

    public static function dynamic_data( $data, $context ) {
        if ( ! is_user_logged_in() ) return $data;
        $user_id = get_current_user_id();
        $data['enrollment'] = array( 'user_id' => $user_id );
        if ( is_singular( 'academy_course' ) ) {
            $course_id = get_the_ID();
            $data['enrollment']['course_id'] = $course_id;
            $data['enrollment']['has_access'] = self::has_access( $user_id, $course_id );
            $data['enrollment']['record'] = self::get( $user_id, $course_id );
        }
        return $data;
    }

    public static function grant_from_payment( $user_id, $course_id, $reference = '', $source = 'payment' ) {
        return self::grant( $user_id, $course_id, array( 'source' => $source, 'source_reference' => $reference ) );
    }

    public static function revoke_from_refund( $user_id, $course_id, $reference = '' ) {
        return self::revoke( $user_id, $course_id, 'refund:' . sanitize_text_field( $reference ) );
    }

    private static function normalize_datetime( $value ) {
        if ( empty( $value ) ) return null;
        $timestamp = strtotime( (string) $value );
        return $timestamp ? gmdate( 'Y-m-d H:i:s', $timestamp ) : null;
    }

    public static function admin_menu() {
        add_submenu_page( 'edit.php?post_type=academy_course', 'دسترسی دوره‌ها', 'دسترسی‌ها', 'manage_options', 'academy-enrollments', array( __CLASS__, 'admin_page' ) );
    }

    public static function admin_page() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'دسترسی غیرمجاز.' );
        $user_id = absint( $_GET['user_id'] ?? 0 ); $course_id = absint( $_GET['course_id'] ?? 0 );
        echo '<div class="wrap"><h1>مدیریت Enrollment</h1><p>این ماژول فقط Access Control را مدیریت می‌کند و هیچ UI پنل دانش‌پذیر ایجاد نمی‌کند.</p>';
        if ( $user_id && $course_id ) {
            $row = self::get( $user_id, $course_id );
            echo '<p>کاربر: ' . esc_html( $user_id ) . ' — دوره: ' . esc_html( $course_id ) . ' — وضعیت: ' . esc_html( $row ? $row->status : 'none' ) . '</p>';
            if ( $row && 'active' === $row->status ) {
                echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="academy_enrollment_revoke"><input type="hidden" name="user_id" value="' . esc_attr( $user_id ) . '"><input type="hidden" name="course_id" value="' . esc_attr( $course_id ) . '">';
                wp_nonce_field( 'academy_enrollment_revoke' ); submit_button( 'لغو دسترسی', 'delete', 'submit', false ); echo '</form>';
            }
        }
        echo '</div>';
    }

    public static function admin_grant() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'دسترسی غیرمجاز.' ); check_admin_referer( 'academy_enrollment_grant' );
        $result = self::grant( absint( $_POST['user_id'] ?? 0 ), absint( $_POST['course_id'] ?? 0 ), array( 'source' => 'manual' ) );
        if ( is_wp_error( $result ) ) wp_die( esc_html( $result->get_error_message() ) );
        wp_safe_redirect( wp_get_referer() ?: admin_url() ); exit;
    }

    public static function admin_revoke() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'دسترسی غیرمجاز.' ); check_admin_referer( 'academy_enrollment_revoke' );
        $result = self::revoke( absint( $_POST['user_id'] ?? 0 ), absint( $_POST['course_id'] ?? 0 ), 'manual' );
        if ( is_wp_error( $result ) ) wp_die( esc_html( $result->get_error_message() ) );
        wp_safe_redirect( wp_get_referer() ?: admin_url() ); exit;
    }
}
