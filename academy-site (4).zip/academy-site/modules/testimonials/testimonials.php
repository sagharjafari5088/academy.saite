<?php
if(!defined('ABSPATH'))exit;
final class Academy_Site_Testimonials{
 const POST_TYPE='academy_testimonial';
 public static function boot(){add_action('init',array(__CLASS__,'cpt'));add_action('add_meta_boxes',array(__CLASS__,'boxes'));add_action('save_post_'.self::POST_TYPE,array(__CLASS__,'save'),10,2);}
 public static function cpt(){register_post_type(self::POST_TYPE,array('labels'=>array('name'=>'نظرات','singular_name'=>'نظر','add_new_item'=>'افزودن نظر','edit_item'=>'ویرایش نظر'),'public'=>true,'show_in_rest'=>true,'menu_icon'=>'dashicons-format-quote','supports'=>array('title','editor','excerpt','thumbnail'),'has_archive'=>true,'rewrite'=>array('slug'=>'testimonials')));}
 public static function boxes(){add_meta_box('academy-testimonial-meta','اطلاعات نظر',array(__CLASS__,'box'),self::POST_TYPE,'normal','high');}
public static function box($post){wp_nonce_field('academy_testimonial_save','academy_testimonial_nonce');echo '<p><label>نام</label><br><input class="widefat" name="academy_testimonial_name" value="'.esc_attr(get_post_meta($post->ID,'_academy_testimonial_name',true)).'"></p><p><label>سمت</label><br><input class="widefat" name="academy_testimonial_role" value="'.esc_attr(get_post_meta($post->ID,'_academy_testimonial_role',true)).'"></p>'; }
public static function save($id,$post){if(!isset($_POST['academy_testimonial_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['academy_testimonial_nonce'])),'academy_testimonial_save'))return;if(defined('DOING_AUTOSAVE')&&DOING_AUTOSAVE)return;if(wp_is_post_revision($id)||!current_user_can('edit_post',$id))return;update_post_meta($id,'_academy_testimonial_name',sanitize_text_field(wp_unslash($_POST['academy_testimonial_name']??'')));update_post_meta($id,'_academy_testimonial_role',sanitize_text_field(wp_unslash($_POST['academy_testimonial_role']??'')));}
public static function get($id){$p=get_post(absint($id));if(!$p||$p->post_type!==self::POST_TYPE)return null;$img=get_post_thumbnail_id($id);return array('id'=>(int)$id,'title'=>get_the_title($p),'name'=>get_post_meta($id,'_academy_testimonial_name',true),'role'=>get_post_meta($id,'_academy_testimonial_role',true),'content'=>$p->post_content,'image_id'=>$img,'image_url'=>$img?wp_get_attachment_image_url($img,'full'):'','image_html'=>$img?wp_get_attachment_image($img,'full',false,array('class'=>'academy-testimonial-image')):'');}

 public static function all(){$ps=get_posts(array('post_type'=>self::POST_TYPE,'post_status'=>'publish','posts_per_page'=>-1,'orderby'=>'date','order'=>'DESC'));$o=array();foreach($ps as $p){$d=self::get($p->ID);if($d)$o[]=$d;}return $o;}
}
Academy_Site_Testimonials::boot();
