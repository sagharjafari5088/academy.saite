<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Academy_Site_Testimonial_Renderer {
    public static function boot() {
        add_filter( 'academy_site_render_map', array( __CLASS__, 'map' ), 20, 3 );
    }
    public static function map( $map, $type, $data ) {
        if ( 'testimonial' !== $type ) return $map;
        $d = is_array( $data ) ? $data : (array) $data;
        $id = absint( $d['id'] ?? 0 );
        $url = $id ? get_permalink( $id ) : '#';
        $m = array();
        $m = array(
                'testimonial_id'    => (string) $id,
                'testimonial_title' => esc_html( $d['title'] ?? '' ),
                'testimonial_name'  => esc_html( $d['name'] ?? '' ),
                'testimonial_role'  => esc_html( $d['role'] ?? '' ),
                'testimonial_title' => esc_html( $d['role'] ?? ( $d['title'] ?? '' ) ),
                'testimonial_text'  => wp_kses_post( $d['content'] ?? '' ),
                'testimonial_image' => $d['image_html'] ?? '',
                'testimonial_image_url' => esc_url( $d['image_url'] ?? '' ),
            );
        return $m;
    }
}
Academy_Site_Testimonial_Renderer::boot();
