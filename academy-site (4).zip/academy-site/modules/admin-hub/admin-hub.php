<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Academy Site — Central Administration.
 *
 * Presentation is limited to WordPress admin screens. Front-end design remains
 * completely Elementor/HTML-widget driven. Business logic stays in modules and
 * this hub only calls public module APIs.
 */
final class Academy_Site_Admin_Hub {

    private static $booted = false;

    public static function boot() {
        if ( self::$booted ) return;
        self::$booted = true;

        add_action( 'admin_menu', array( __CLASS__, 'menu' ), 20 );
        add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
    }

    public static function register_settings() {
        $keys = array(
            'login_url','register_url','otp_url','complete_registration_url',
            'welcome_url','consultation_url','certificate_verify_url',
            'student_dashboard_url',
        );
        foreach ( $keys as $key ) {
            register_setting( 'academy_site_pages', 'academy_site_' . $key, array( 'sanitize_callback' => 'esc_url_raw' ) );
        }
    }

    public static function menu() {
        if ( ! current_user_can( 'manage_options' ) ) return;

        add_menu_page(
            'Academy Site', 'Academy Site', 'manage_options', 'academy-site',
            array( __CLASS__, 'dashboard' ), 'dashicons-welcome-learn-more', 26
        );
        add_submenu_page( 'academy-site', 'داشبورد', 'داشبورد', 'manage_options', 'academy-site', array( __CLASS__, 'dashboard' ) );
        add_submenu_page( 'academy-site', 'دانشجویان', 'دانشجویان', 'manage_options', 'academy-students-hub', array( __CLASS__, 'students' ) );
        add_submenu_page( 'academy-site', 'افزودن دانشجو', 'افزودن دانشجو', 'manage_options', 'academy-add-student', array( __CLASS__, 'add_student' ) );
        add_submenu_page( 'academy-site', 'پرونده دانشجو', 'پرونده دانشجو', 'manage_options', 'academy-student-profile', array( __CLASS__, 'student_profile' ) );
        add_submenu_page( 'academy-site', 'مدرسین', 'مدرسین', 'manage_options', 'academy-instructors', array( __CLASS__, 'instructors' ) );
        add_submenu_page( 'academy-site', 'افزودن مدرس', 'افزودن مدرس', 'manage_options', 'academy-add-instructor', array( __CLASS__, 'add_instructor' ) );
        add_submenu_page( 'academy-site', 'دوره‌ها', 'دوره‌ها', 'manage_options', 'academy-courses', array( __CLASS__, 'courses' ) );
        add_submenu_page( 'academy-site', 'افزودن دوره', 'افزودن دوره', 'manage_options', 'academy-add-course', array( __CLASS__, 'add_course' ) );
        add_submenu_page( 'academy-site', 'همایش‌ها و رویدادها', 'همایش‌ها و رویدادها', 'manage_options', 'academy-events', array( __CLASS__, 'events' ) );
        add_submenu_page( 'academy-site', 'افزودن رویداد', 'افزودن رویداد', 'manage_options', 'academy-add-event', array( __CLASS__, 'add_event' ) );
        add_submenu_page( 'academy-site', 'گواهینامه‌ها', 'گواهینامه‌ها', 'manage_options', 'academy-certificates-hub', array( __CLASS__, 'certificate_dashboard' ) );
        add_submenu_page( 'academy-site', 'قالب‌های گواهینامه', '— قالب‌ها', 'manage_options', 'academy-certificate-templates', array( __CLASS__, 'certificate_templates' ) );
        add_submenu_page( 'academy-site', 'گواهینامه‌های دوره‌ها', '— گواهینامه‌های دوره‌ها', 'manage_options', 'academy-course-certificates', array( __CLASS__, 'course_certificates' ) );
        add_submenu_page( 'academy-site', 'صدور دستی گواهینامه', '— صدور دستی', 'manage_options', 'academy-manual-certificates', array( __CLASS__, 'manual_certificates' ) );
        add_submenu_page( 'academy-site', 'آرشیو دارندگان گواهینامه', '— آرشیو دارندگان', 'manage_options', 'academy-certificate-holders', array( __CLASS__, 'certificate_holders' ) );
        add_submenu_page( 'academy-site', 'CRM', 'CRM', 'manage_options', 'academy-crm-hub', array( __CLASS__, 'crm' ) );
        add_submenu_page( 'academy-site', 'SMS.ir', 'SMS.ir', 'manage_options', 'academy-sms-hub', array( __CLASS__, 'sms' ) );
        add_submenu_page( 'academy-site', 'فروش و پرداخت', 'فروش و پرداخت', 'manage_options', 'academy-commerce-hub', array( __CLASS__, 'commerce' ) );
        add_submenu_page( 'academy-site', 'مشاوره', 'مشاوره', 'manage_options', 'academy-consultation-hub', array( __CLASS__, 'consultation' ) );
        add_submenu_page( 'academy-site', 'کیف پول', 'کیف پول', 'manage_options', 'academy-wallet-hub', array( __CLASS__, 'wallet' ) );
        add_submenu_page( 'academy-site', 'صفحات سیستم', 'صفحات سیستم', 'manage_options', 'academy-pages', array( __CLASS__, 'pages' ) );
        add_submenu_page( 'academy-site', 'وضعیت ماژول‌ها', 'وضعیت ماژول‌ها', 'manage_options', 'academy-modules-hub', array( __CLASS__, 'modules' ) );
    }

    public static function assets( $hook ) {
        if ( false === strpos( (string) $hook, 'academy' ) ) return;
        wp_register_style( 'academy-site-admin-hub', false, array(), defined('ACADEMY_SITE_VERSION') ? ACADEMY_SITE_VERSION : '1.0.0' );
        wp_enqueue_style( 'academy-site-admin-hub' );
        wp_add_inline_style( 'academy-site-admin-hub', '
            .academy-hub-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;margin:18px 0}
            .academy-hub-card{background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:18px}
            .academy-hub-card h2{margin:0 0 8px;font-size:17px}
            .academy-hub-kpi{font-size:26px;font-weight:700}
            .academy-hub-table{margin-top:18px}
            .academy-hub-actions{display:flex;gap:8px;flex-wrap:wrap}
            .academy-hub-tabs{margin:18px 0}
            .academy-hub-tabs a{margin-left:6px}
            .academy-detail-grid{display:grid;grid-template-columns:2fr 1fr;gap:18px;align-items:start}
            .academy-detail-box{background:#fff;border:1px solid #dcdcde;padding:18px;margin-bottom:18px;border-radius:8px}
            .academy-danger{color:#b32d2e}
            .academy-muted{color:#646970}
        ' );
    }

    private static function guard() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'دسترسی غیرمجاز.' );
    }

    private static function redirect( $page, $args = array() ) {
        $url = admin_url( 'admin.php?page=' . $page );
        if ( $args ) $url = add_query_arg( $args, $url );
        wp_safe_redirect( $url );
        exit;
    }

    private static function notice() {
        if ( empty( $_GET['academy_notice'] ) ) return;
        $type = ( 'error' === sanitize_key( $_GET['academy_notice_type'] ?? '' ) ) ? 'notice-error' : 'notice-success';
        echo '<div class="notice ' . esc_attr( $type ) . ' is-dismissible"><p>' . esc_html( wp_unslash( $_GET['academy_notice'] ) ) . '</p></div>';
    }

    public static function dashboard() {
        self::guard();
        $counts = array(
            'students' => count_users()['total_users'] ?? 0,
            'courses' => post_type_exists('academy_course') ? wp_count_posts('academy_course')->publish : 0,
            'instructors' => post_type_exists('academy_instructor') ? wp_count_posts('academy_instructor')->publish : 0,
            'events' => post_type_exists('academy_event') ? wp_count_posts('academy_event')->publish : 0,
        );
        ?>
        <div class="wrap"><h1>Academy Site</h1><p>مرکز مدیریت آکادمی. ظاهر سایت و صفحات فرانت‌اند وابسته به این UI نیست و از Elementor HTML Widget طراحی می‌شود.</p>
        <div class="academy-hub-grid"><?php foreach($counts as $k=>$v): ?><div class="academy-hub-card"><h2><?php echo esc_html(self::label($k)); ?></h2><div class="academy-hub-kpi"><?php echo esc_html(number_format_i18n((int)$v)); ?></div></div><?php endforeach; ?></div>
        <div class="academy-hub-grid">
            <?php self::card('دانشجویان','پرونده کامل دانشجو، کیف پول، دوره‌ها، گواهی‌ها، رویدادها، سفارش‌ها و فعالیت‌ها.','academy-students-hub'); ?>
            <?php self::card('مدرسین','ثبت و ویرایش مدرس، تصویر، حوزه فعالیت و QR.','academy-instructors'); ?>
            <?php self::card('دوره‌ها','اطلاعات دوره، قیمت اصلی، تخفیف، مدرس، سرفصل و Coming Soon.','academy-courses'); ?>
            <?php self::card('همایش‌ها','رویداد، ظرفیت، سخنران و انواع بلیت.','academy-events'); ?>
            <?php self::card('گواهینامه‌ها','قالب، صدور، لغو و استعلام.','academy-certificates-hub'); ?>
            <?php self::card('CRM','گروه‌بندی، فیلتر و کمپین پیامکی.','academy-crm-hub'); ?>
            <?php self::card('SMS.ir','API و Template IDهای مستقل برای تمام پیام‌ها.','academy-sms-hub'); ?>
            <?php self::card('فروش و پرداخت','سفارش‌ها و تنظیمات زرین‌پال.','academy-commerce-hub'); ?>
            <?php self::card('مشاوره','درخواست‌ها و وضعیت مشاوره.','academy-consultation-hub'); ?>
            <?php self::card('کیف پول','اعتبار، برداشت، هدیه تولد و تاریخچه تراکنش.','academy-wallet-hub'); ?>
        </div></div>
        <?php
    }

    private static function label($k) {
        return array('students'=>'دانشجویان','courses'=>'دوره‌های منتشرشده','instructors'=>'مدرسین','events'=>'رویدادهای منتشرشده')[$k] ?? $k;
    }

    private static function card($title,$desc,$page) {
        echo '<div class="academy-hub-card"><h2>'.esc_html($title).'</h2><p class="academy-muted">'.esc_html($desc).'</p><a class="button button-primary" href="'.esc_url(admin_url('admin.php?page='.$page)).'">مدیریت</a></div>';
    }

    public static function students() {
        self::guard();
        $q = sanitize_text_field(wp_unslash($_GET['s'] ?? ''));
        $users = get_users(array(
            'number'=>100,
            'search'=>$q ? '*'.$q.'*' : '',
            'search_columns'=>array('user_login','display_name','user_email'),
            'orderby'=>'registered','order'=>'DESC'
        ));
        ?>
        <div class="wrap"><h1>مدیریت دانشجویان</h1><?php self::notice(); ?>
        <p><a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=academy-add-student')); ?>">+ افزودن دانشجو</a></p>
        <form method="get"><input type="hidden" name="page" value="academy-students-hub"><input class="regular-text" name="s" value="<?php echo esc_attr($q); ?>" placeholder="نام، موبایل یا نام کاربری"> <button class="button">جستجو</button></form>
        <table class="widefat striped academy-hub-table"><thead><tr><th>نام</th><th>موبایل</th><th>استان</th><th>شهر</th><th>کیف پول</th><th>دوره</th><th>گواهی</th><th>عملیات</th></tr></thead><tbody>
        <?php foreach($users as $u):
            $en=class_exists('Academy_Site_Enrollment')?Academy_Site_Enrollment::get_user_enrollments($u->ID):array();
            $cert=class_exists('Academy_Site_Certificates')?Academy_Site_Certificates::get_user_certificates($u->ID):array();
            $bal=class_exists('Academy_Site_Wallet')?Academy_Site_Wallet::get_balance($u->ID):array('amount'=>0);
            ?>
            <tr><td><?php echo esc_html($u->display_name); ?></td><td><?php echo esc_html(get_user_meta($u->ID,'academy_phone',true)); ?></td><td><?php echo esc_html(get_user_meta($u->ID,'province',true)); ?></td><td><?php echo esc_html(get_user_meta($u->ID,'city',true)); ?></td><td><?php echo esc_html(number_format_i18n((float)($bal['amount']??0))); ?></td><td><?php echo esc_html(count($en)); ?></td><td><?php echo esc_html(count($cert)); ?></td><td><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=academy-student-profile&user_id='.$u->ID)); ?>">پرونده کامل</a></td></tr>
        <?php endforeach; if(!$users): ?><tr><td colspan="8">دانشجویی پیدا نشد.</td></tr><?php endif; ?></tbody></table></div>
        <?php
    }

    public static function add_student() {
        self::guard();
        if ( 'POST' === $_SERVER['REQUEST_METHOD'] && isset($_POST['academy_hub_add_student']) ) {
            check_admin_referer('academy_hub_add_student');
            $first=sanitize_text_field(wp_unslash($_POST['first_name']??'')); $last=sanitize_text_field(wp_unslash($_POST['last_name']??''));
            $phone=preg_replace('/\D+/','',wp_unslash($_POST['phone']??''));
            if(!$first||!$last||!$phone) self::redirect('academy-add-student',array('academy_notice'=>'نام، نام خانوادگی و موبایل الزامی است.','academy_notice_type'=>'error'));
            $existing=get_users(array('meta_key'=>'academy_phone','meta_value'=>$phone,'number'=>1,'fields'=>'ID'));
            if($existing) self::redirect('academy-add-student',array('academy_notice'=>'این شماره موبایل قبلاً ثبت شده است.','academy_notice_type'=>'error'));
            $login='academy_'.$phone; if(username_exists($login)) $login.='_'.wp_generate_password(4,false,false);
            $uid=wp_create_user($login,wp_generate_password(32,true,true),$phone.'@academy.local');
            if(is_wp_error($uid)) self::redirect('academy-add-student',array('academy_notice'=>$uid->get_error_message(),'academy_notice_type'=>'error'));
            wp_update_user(array('ID'=>$uid,'first_name'=>$first,'last_name'=>$last,'display_name'=>trim($first.' '.$last)));
            foreach(array('academy_phone'=>$phone,'birth_date'=>sanitize_text_field(wp_unslash($_POST['birth_date']??'')),'gender'=>sanitize_text_field(wp_unslash($_POST['gender']??'')),'province'=>sanitize_text_field(wp_unslash($_POST['province']??'')),'city'=>sanitize_text_field(wp_unslash($_POST['city']??'')),'national_id'=>sanitize_text_field(wp_unslash($_POST['national_id']??'')),'academy_status'=>'active') as $k=>$v) update_user_meta($uid,$k,$v);
            if(class_exists('Academy_Site_Wallet')) Academy_Site_Wallet::ensure_account($uid);
            do_action('academy_site_student_registered',$uid);
            self::redirect('academy-student-profile',array('user_id'=>$uid,'academy_notice'=>'دانشجو ثبت شد.'));
        }
        ?>
        <div class="wrap"><h1>افزودن دانشجو</h1><?php self::notice(); ?>
        <form method="post"><?php wp_nonce_field('academy_hub_add_student'); ?>
        <table class="form-table"><tr><th>نام</th><td><input class="regular-text" name="first_name" required></td></tr><tr><th>نام خانوادگی</th><td><input class="regular-text" name="last_name" required></td></tr><tr><th>شماره موبایل</th><td><input class="regular-text" name="phone" required></td></tr><tr><th>تاریخ تولد</th><td><input class="regular-text" name="birth_date"></td></tr><tr><th>جنسیت</th><td><select name="gender"><option value="">انتخاب</option><option value="female">زن</option><option value="male">مرد</option></select></td></tr><tr><th>استان</th><td><input class="regular-text" name="province"></td></tr><tr><th>شهر</th><td><input class="regular-text" name="city"></td></tr><tr><th>کد ملی</th><td><input class="regular-text" name="national_id"></td></tr></table>
        <button class="button button-primary" name="academy_hub_add_student" value="1">ثبت دانشجو</button></form></div>
        <?php
    }

    public static function student_profile() {
        self::guard();
        $uid=absint($_GET['user_id']??0); $u=get_userdata($uid); if(!$u) wp_die('دانشجو پیدا نشد.');
        if('POST'===($_SERVER['REQUEST_METHOD']??'GET')) {
            $action=sanitize_key($_POST['academy_student_action']??'');
            if($action==='update') {
                check_admin_referer('academy_student_update_'.$uid);
                wp_update_user(array('ID'=>$uid,'first_name'=>sanitize_text_field(wp_unslash($_POST['first_name']??'')),'last_name'=>sanitize_text_field(wp_unslash($_POST['last_name']??'')),'display_name'=>sanitize_text_field(wp_unslash($_POST['display_name']??''))));
                foreach(array('academy_phone','birth_date','gender','province','city','national_id','academy_status') as $k) update_user_meta($uid,$k,sanitize_text_field(wp_unslash($_POST[$k]??'')));
                self::redirect('academy-student-profile',array('user_id'=>$uid,'academy_notice'=>'اطلاعات دانشجو ذخیره شد.'));
            }
            if($action==='wallet') {
                check_admin_referer('academy_student_wallet_'.$uid);
                if(!class_exists('Academy_Site_Wallet')) self::redirect('academy-student-profile',array('user_id'=>$uid,'academy_notice'=>'ماژول کیف پول فعال نیست.','academy_notice_type'=>'error'));
                $amount=(float)($_POST['amount']??0); $type=sanitize_key($_POST['wallet_type']??'credit'); $desc=sanitize_text_field(wp_unslash($_POST['description']??'')); $exp=sanitize_text_field(wp_unslash($_POST['expires_at']??''));
                $ref='admin:'.$uid.':'.wp_generate_uuid4();
                $r=$type==='debit'?Academy_Site_Wallet::debit($uid,$amount,array('reference'=>$ref,'description'=>$desc,'created_by'=>get_current_user_id())):Academy_Site_Wallet::credit($uid,$amount,array('reference'=>$ref,'description'=>$desc,'expires_at'=>$exp?:null,'created_by'=>get_current_user_id()));
                self::redirect('academy-student-profile',array('user_id'=>$uid,'academy_notice'=>is_wp_error($r)?$r->get_error_message():'تراکنش کیف پول ثبت شد.','academy_notice_type'=>is_wp_error($r)?'error':''));
            }
            if($action==='enrollment') {
                check_admin_referer('academy_student_enrollment_'.$uid);
                $cid=absint($_POST['course_id']??0); $op=sanitize_key($_POST['enrollment_op']??'grant');
                $r=$op==='revoke'?Academy_Site_Enrollment::revoke($uid,$cid,'manual_admin'):Academy_Site_Enrollment::grant($uid,$cid,array('source'=>'manual','starts_at'=>sanitize_text_field($_POST['starts_at']??''),'expires_at'=>sanitize_text_field($_POST['expires_at']??'')));
                self::redirect('academy-student-profile',array('user_id'=>$uid,'academy_notice'=>is_wp_error($r)?$r->get_error_message():($op==='revoke'?'دسترسی دوره حذف شد.':'دوره به حساب دانشجو اضافه شد.'),'academy_notice_type'=>is_wp_error($r)?'error':''));
            }
        }
        $bal=class_exists('Academy_Site_Wallet')?Academy_Site_Wallet::get_balance($uid):array('amount'=>0,'currency'=>'IRT');
        $en=class_exists('Academy_Site_Enrollment')?Academy_Site_Enrollment::get_user_enrollments($uid):array();
        $cert=class_exists('Academy_Site_Certificates')?Academy_Site_Certificates::get_user_certificates($uid,true):array();
        $events=class_exists('Academy_Site_Events')?Academy_Site_Events::get_user_registrations($uid):array();
        $courses=get_posts(array('post_type'=>'academy_course','post_status'=>array('publish','draft'),'numberposts'=>200,'orderby'=>'title','order'=>'ASC'));
        ?>
        <div class="wrap"><h1>پرونده دانشجو: <?php echo esc_html($u->display_name); ?></h1><?php self::notice(); ?>
        <div class="academy-detail-grid"><div>
        <div class="academy-detail-box"><h2>اطلاعات حساب</h2><form method="post"><?php wp_nonce_field('academy_student_update_'.$uid); ?><input type="hidden" name="academy_student_action" value="update"><table class="form-table">
        <?php foreach(array('first_name'=>'نام','last_name'=>'نام خانوادگی','display_name'=>'نام نمایشی') as $k=>$l): ?><tr><th><?php echo esc_html($l); ?></th><td><input class="regular-text" name="<?php echo esc_attr($k); ?>" value="<?php echo esc_attr($k==='display_name'?$u->display_name:$u->$k); ?>"></td></tr><?php endforeach; ?>
        <?php foreach(array('academy_phone'=>'موبایل','national_id'=>'کد ملی','birth_date'=>'تاریخ تولد','province'=>'استان','city'=>'شهر') as $k=>$l): ?><tr><th><?php echo esc_html($l); ?></th><td><input class="regular-text" name="<?php echo esc_attr($k); ?>" value="<?php echo esc_attr(get_user_meta($uid,$k,true)); ?>"></td></tr><?php endforeach; ?>
        <tr><th>جنسیت</th><td><select name="gender"><option value="">-</option><option value="female" <?php selected(get_user_meta($uid,'gender',true),'female'); ?>>زن</option><option value="male" <?php selected(get_user_meta($uid,'gender',true),'male'); ?>>مرد</option></select></td></tr>
        <tr><th>وضعیت</th><td><select name="academy_status"><option value="active" <?php selected(get_user_meta($uid,'academy_status',true),'active'); ?>>فعال</option><option value="inactive" <?php selected(get_user_meta($uid,'academy_status',true),'inactive'); ?>>غیرفعال</option></select></td></tr>
        </table><?php submit_button('ذخیره اطلاعات'); ?></form></div>
        <div class="academy-detail-box"><h2>دوره‌های دانشجو</h2><table class="widefat striped"><thead><tr><th>دوره</th><th>وضعیت</th><th>شروع</th><th>انقضا</th><th>عملیات</th></tr></thead><tbody><?php foreach($en as $e): ?><tr><td><?php echo esc_html(get_the_title($e->course_id)); ?></td><td><?php echo esc_html($e->status); ?></td><td><?php echo esc_html($e->starts_at); ?></td><td><?php echo esc_html($e->expires_at); ?></td><td><form method="post" style="display:inline"><?php wp_nonce_field('academy_student_enrollment_'.$uid); ?><input type="hidden" name="academy_student_action" value="enrollment"><input type="hidden" name="course_id" value="<?php echo absint($e->course_id); ?>"><input type="hidden" name="enrollment_op" value="revoke"><button class="button button-small" onclick="return confirm('دسترسی این دوره حذف شود؟')">حذف دسترسی</button></form></td></tr><?php endforeach; if(!$en): ?><tr><td colspan="5">دوره‌ای ثبت نشده است.</td></tr><?php endif; ?></tbody></table></div>
        <div class="academy-detail-box"><h2>گواهینامه‌ها</h2><table class="widefat striped"><thead><tr><th>کد استعلام</th><th>دوره</th><th>وضعیت</th><th>تاریخ</th></tr></thead><tbody><?php foreach($cert as $c): ?><tr><td><code><?php echo esc_html($c->verification_code); ?></code></td><td><?php echo esc_html($c->course_id?get_the_title($c->course_id):'-'); ?></td><td><?php echo esc_html($c->status); ?></td><td><?php echo esc_html($c->issued_at); ?></td></tr><?php endforeach; if(!$cert): ?><tr><td colspan="4">گواهینامه‌ای ثبت نشده است.</td></tr><?php endif; ?></tbody></table></div>
        <div class="academy-detail-box"><h2>همایش‌ها و بلیت‌ها</h2><table class="widefat striped"><thead><tr><th>رویداد</th><th>کد بلیت</th><th>کد ورود</th><th>وضعیت</th></tr></thead><tbody><?php foreach($events as $e): ?><tr><td><?php echo esc_html(get_the_title($e->event_id)); ?></td><td><?php echo esc_html($e->ticket_code); ?></td><td><?php echo esc_html($e->entry_code); ?></td><td><?php echo esc_html($e->status); ?></td></tr><?php endforeach; if(!$events): ?><tr><td colspan="4">بلیت یا رویدادی ثبت نشده است.</td></tr><?php endif; ?></tbody></table></div>
        </div><div>
        <div class="academy-detail-box"><h2>کیف پول</h2><p class="academy-hub-kpi"><?php echo esc_html(number_format_i18n((float)($bal['amount']??0))); ?> <?php echo esc_html($bal['currency']??''); ?></p><form method="post"><?php wp_nonce_field('academy_student_wallet_'.$uid); ?><input type="hidden" name="academy_student_action" value="wallet"><p><select name="wallet_type"><option value="credit">افزایش موجودی / هدیه</option><option value="debit">کسر موجودی</option></select></p><p><input type="number" min="0.01" step="0.01" name="amount" class="regular-text" required placeholder="مبلغ"></p><p><input name="description" class="regular-text" placeholder="دلیل تراکنش"></p><p><label>انقضا برای اعتبار افزوده‌شده (اختیاری)<br><input type="datetime-local" name="expires_at"></label></p><?php submit_button('ثبت تراکنش کیف پول','primary'); ?></form></div>
        <div class="academy-detail-box"><h2>افزودن/حذف دوره</h2><form method="post"><?php wp_nonce_field('academy_student_enrollment_'.$uid); ?><input type="hidden" name="academy_student_action" value="enrollment"><select name="course_id" required><option value="">انتخاب دوره</option><?php foreach($courses as $c): ?><option value="<?php echo absint($c->ID); ?>"><?php echo esc_html($c->post_title); ?></option><?php endforeach; ?></select><p><select name="enrollment_op"><option value="grant">اضافه کردن دسترسی</option><option value="revoke">حذف دسترسی</option></select></p><p><input name="starts_at" placeholder="شروع اختیاری YYYY-MM-DD HH:MM:SS"></p><p><input name="expires_at" placeholder="انقضا اختیاری YYYY-MM-DD HH:MM:SS"></p><?php submit_button('اعمال','primary',false); ?></form></div>
        </div></div></div>
        <?php
    }

    public static function instructors() {
        self::guard();

        // حذف مدرس از همین صفحه مدیریت انجام می‌شود. حذف به سطل زباله
        // می‌رود تا در صورت خطا قابل بازیابی باشد و اطلاعات دیگر ماژول‌ها
        // نیز به‌صورت ناگهانی پاک نشوند.
        if ( isset( $_GET['action'], $_GET['instructor_id'] ) && 'delete_instructor' === $_GET['action'] ) {
            $delete_id = absint( $_GET['instructor_id'] );
            if ( $delete_id && current_user_can( 'delete_post', $delete_id ) ) {
                check_admin_referer( 'academy_delete_instructor_' . $delete_id );
                $post = get_post( $delete_id );
                if ( $post && Academy_Site_Instructors::POST_TYPE === $post->post_type ) {
                    wp_trash_post( $delete_id );
                    self::redirect( 'academy-instructors', array(
                        'academy_notice' => 'مدرس با موفقیت حذف شد.',
                    ) );
                }
            }
        }

        $posts=get_posts(array('post_type'=>'academy_instructor','post_status'=>array('publish','draft'),'posts_per_page'=>100,'orderby'=>'date','order'=>'DESC'));
        echo '<div class="wrap"><h1>مدرسین</h1>';
        self::notice();
        echo '<p><a class="button button-primary" href="'.esc_url(admin_url('admin.php?page=academy-add-instructor')).'">افزودن مدرس</a></p>';
        echo '<table class="widefat striped"><thead><tr><th>عکس</th><th>نام</th><th>زیرعنوان</th><th>QR</th><th>وضعیت</th><th>عملیات</th></tr></thead><tbody>';
        foreach($posts as $p){
            $d=Academy_Site_Instructors::get_instructor($p->ID);
            $edit_url=admin_url('admin.php?page=academy-add-instructor&instructor_id='.$p->ID);
            $delete_url=wp_nonce_url(
                admin_url('admin.php?page=academy-instructors&action=delete_instructor&instructor_id='.$p->ID),
                'academy_delete_instructor_'.$p->ID
            );
            echo '<tr><td>'.($d&&$d['image_url']?'<img src="'.esc_url($d['image_url']).'" style="width:55px;height:55px;object-fit:cover;border-radius:6px">':'-').'</td><td>'.esc_html($d['name']??$p->post_title).'</td><td>'.esc_html($d['subtitle']??'').'</td><td>'.($d&&$d['qr_url']?'<img src="'.esc_url($d['qr_url']).'" width="70" height="70">':'-').'</td><td>'.esc_html($p->post_status).'</td><td><a class="button" href="'.esc_url($edit_url).'">ویرایش</a> <a class="button" href="'.esc_url($delete_url).'" onclick="return confirm(\'آیا از حذف این مدرس مطمئن هستید؟ مدرس به سطل زباله منتقل می‌شود.\');">حذف</a></td></tr>';
        }
        if(!$posts)echo '<tr><td colspan="6">مدرسی ثبت نشده است.</td></tr>'; echo '</tbody></table></div>';
    }

    public static function add_instructor() {
        self::guard();
        $id=absint($_GET['instructor_id']??0); $p=$id?get_post($id):null;
        if('POST'===($_SERVER['REQUEST_METHOD']??'GET')&&isset($_POST['academy_hub_save_instructor'])){
            check_admin_referer('academy_hub_instructor');
            $id=absint($_POST['instructor_id']??0); $name=sanitize_text_field(wp_unslash($_POST['name']??'')); $subtitle=sanitize_text_field(wp_unslash($_POST['subtitle']??'')); $description=wp_kses_post(wp_unslash($_POST['description']??'')); $status=in_array(($_POST['status']??'publish'),array('publish','draft'),true)?$_POST['status']:'publish';
            if(!$name){self::redirect('academy-add-instructor',array('academy_notice'=>'نام مدرس الزامی است.','academy_notice_type'=>'error','instructor_id'=>$id));}
            $postarr=array('post_type'=>'academy_instructor','post_title'=>$name,'post_content'=>$description,'post_status'=>$status);
            if($id)$postarr['ID']=$id;
            $saved=$id?wp_update_post(wp_slash($postarr),true):wp_insert_post(wp_slash($postarr),true);
            if(is_wp_error($saved)){self::redirect('academy-add-instructor',array('academy_notice'=>$saved->get_error_message(),'academy_notice_type'=>'error','instructor_id'=>$id));}
            $id=$id?:absint($saved); update_post_meta($id,Academy_Site_Instructors::META_TITLE,$subtitle); Academy_Site_Instructors::ensure_qr_token($id);
            if(!empty($_FILES['instructor_image']['name'])){require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';$attachment=media_handle_upload('instructor_image',$id);if(!is_wp_error($attachment))set_post_thumbnail($id,$attachment);}
            self::redirect('academy-instructors',array('academy_notice'=>'مدرس با موفقیت ثبت شد.'));
        }
        $p=$id?get_post($id):null; $d=$id?Academy_Site_Instructors::get_instructor($id):array();
        echo '<div class="wrap"><h1>'.($id?'ویرایش مدرس':'افزودن مدرس').'</h1>';self::notice();echo '<form method="post" enctype="multipart/form-data">';wp_nonce_field('academy_hub_instructor');echo '<input type="hidden" name="instructor_id" value="'.absint($id).'">';echo '<table class="form-table">';
        echo '<tr><th>نام</th><td><input class="regular-text" required name="name" value="'.esc_attr($d['name']??'').'" /></td></tr><tr><th>زیرعنوان نام</th><td><input class="regular-text" name="subtitle" value="'.esc_attr($d['subtitle']??'').'" /></td></tr><tr><th>توضیح</th><td><textarea class="large-text" rows="7" name="description">'.esc_textarea($d['description']??'').'</textarea></td></tr><tr><th>عکس</th><td><input type="file" name="instructor_image" accept="image/*">'.($d['image_url']??''?'<p><img src="'.esc_url($d['image_url']).'" style="max-width:180px;max-height:180px"></p>':'').'</td></tr><tr><th>وضعیت</th><td><select name="status"><option value="publish" '.selected($p->post_status??'publish','publish',false).'>منتشرشده</option><option value="draft" '.selected($p->post_status??'','draft',false).'>پیش‌نویس</option></select></td></tr></table>';submit_button('ذخیره مدرس','primary','academy_hub_save_instructor');echo '</form></div>';
    }

    private static function course_meta_keys() {
        return array(
            'subtitle'=>'_academy_course_subtitle','status'=>'_academy_course_status','coming_soon'=>'_academy_course_coming_soon',
            'price'=>'_academy_course_price','regular_price'=>'_academy_course_regular_price','sale_price'=>'_academy_course_sale_price',
            'banner_id'=>'_academy_course_banner_id','trailer_url'=>'_academy_course_trailer_url','instructor_id'=>'_academy_course_instructor_id',
            'duration'=>'_academy_course_duration','sessions'=>'_academy_course_sessions','outcomes'=>'_academy_course_outcomes',
            'certificate_type'=>'_academy_course_certificate_type','certificate_online'=>'_academy_course_certificate_online'
        );
    }

    public static function courses() {
        self::guard(); $posts=get_posts(array('post_type'=>'academy_course','post_status'=>array('publish','draft'),'posts_per_page'=>100,'orderby'=>'date','order'=>'DESC'));
        echo '<div class="wrap"><h1>مدیریت دوره‌ها</h1><p><a class="button button-primary" href="'.esc_url(admin_url('admin.php?page=academy-add-course')).'">+ افزودن دوره</a></p><table class="widefat striped"><thead><tr><th>دوره</th><th>قیمت اصلی</th><th>قیمت تخفیف</th><th>قیمت فعلی</th><th>Coming Soon</th><th>مدرس</th><th>عملیات</th></tr></thead><tbody>';
        foreach($posts as $p){$m=self::course_meta_keys();$inst=absint(get_post_meta($p->ID,$m['instructor_id'],true));echo '<tr><td>'.esc_html($p->post_title).'</td><td>'.esc_html(number_format_i18n((float)get_post_meta($p->ID,$m['regular_price'],true))).'</td><td>'.esc_html(number_format_i18n((float)get_post_meta($p->ID,$m['sale_price'],true))).'</td><td>'.esc_html(number_format_i18n((float)get_post_meta($p->ID,$m['price'],true))).'</td><td>'.(get_post_meta($p->ID,$m['coming_soon'],true)?'فعال':'-').'</td><td>'.esc_html($inst?get_the_title($inst):'-').'</td><td><a class="button" href="'.esc_url(admin_url('admin.php?page=academy-add-course&course_id='.$p->ID)).'">ویرایش</a></td></tr>';}
        if(!$posts)echo'<tr><td colspan="7">دوره‌ای ثبت نشده است.</td></tr>'; echo '</tbody></table></div>';
    }

    public static function add_course() {
        self::guard(); $id=absint($_GET['course_id']??0); $p=$id?get_post($id):null; $keys=self::course_meta_keys();
        if('POST'===($_SERVER['REQUEST_METHOD']??'GET') && isset($_POST['academy_hub_save_course'])){
            check_admin_referer('academy_hub_course'); $id=absint($_POST['course_id']??0);
            $title=sanitize_text_field(wp_unslash($_POST['name']??'')); if(!$title) self::redirect('academy-add-course',array('academy_notice'=>'عنوان دوره الزامی است.','academy_notice_type'=>'error'));
            $postarr=array('post_type'=>'academy_course','post_title'=>$title,'post_content'=>wp_kses_post(wp_unslash($_POST['description']??'')),'post_excerpt'=>sanitize_textarea_field(wp_unslash($_POST['excerpt']??'')),'post_status'=>sanitize_key($_POST['post_status']??'publish'));
            $saved=$id?wp_update_post(array_merge($postarr,array('ID'=>$id)),true):wp_insert_post($postarr,true); if(!$id&&!is_wp_error($saved))$id=(int)$saved;
            if(is_wp_error($saved))self::redirect('academy-add-course',array('academy_notice'=>$saved->get_error_message(),'academy_notice_type'=>'error'));
            $data=array('subtitle'=>sanitize_text_field(wp_unslash($_POST['subtitle']??'')),'status'=>sanitize_key($_POST['course_status']??'draft'),'coming_soon'=>!empty($_POST['coming_soon'])?'1':'','price'=>(float)($_POST['price']??0),'regular_price'=>(float)($_POST['regular_price']??0),'sale_price'=>(float)($_POST['sale_price']??0),'banner_id'=>absint($_POST['banner_id']??0),'trailer_url'=>esc_url_raw(wp_unslash($_POST['trailer_url']??'')),'instructor_id'=>absint($_POST['instructor_id']??0),'duration'=>sanitize_text_field(wp_unslash($_POST['duration']??'')),'sessions'=>absint($_POST['sessions']??0),'outcomes'=>sanitize_textarea_field(wp_unslash($_POST['outcomes']??'')),'certificate_type'=>sanitize_text_field(wp_unslash($_POST['certificate_type']??'')),'certificate_online'=>!empty($_POST['certificate_online'])?'1':'' );
            foreach($data as $k=>$v)update_post_meta($id,$keys[$k],$v); if($data['banner_id'])set_post_thumbnail($id,$data['banner_id']);
            self::redirect('academy-courses',array('academy_notice'=>'دوره ذخیره شد.'));
        }
        $v=array();foreach($keys as $k=>$meta)$v[$k]=$id?get_post_meta($id,$meta,true):'';$v['name']=$p?$p->post_title:'';$v['description']=$p?$p->post_content:'';$v['excerpt']=$p?$p->post_excerpt:'';$v['post_status']=$p?$p->post_status:'publish';
        $teachers=class_exists('Academy_Site_Instructors')?Academy_Site_Instructors::get_all():array();
        ?>
        <div class="wrap"><h1><?php echo $id?'ویرایش دوره':'افزودن دوره'; ?></h1><?php self::notice(); ?><form method="post"><?php wp_nonce_field('academy_hub_course'); ?><input type="hidden" name="course_id" value="<?php echo absint($id); ?>"><table class="form-table">
        <tr><th>نام دوره</th><td><input class="regular-text" name="name" value="<?php echo esc_attr($v['name']); ?>" required></td></tr><tr><th>زیرعنوان</th><td><input class="regular-text" name="subtitle" value="<?php echo esc_attr($v['subtitle']); ?>"></td></tr><tr><th>توضیحات</th><td><textarea class="large-text" rows="8" name="description"><?php echo esc_textarea($v['description']); ?></textarea></td></tr><tr><th>خلاصه</th><td><textarea class="large-text" rows="3" name="excerpt"><?php echo esc_textarea($v['excerpt']); ?></textarea></td></tr>
        <tr><th>قیمت فعلی</th><td><input type="number" min="0" step="0.01" name="price" value="<?php echo esc_attr($v['price']); ?>"></td></tr><tr><th>قیمت اصلی</th><td><input type="number" min="0" step="0.01" name="regular_price" value="<?php echo esc_attr($v['regular_price']); ?>"></td></tr><tr><th>قیمت تخفیف‌خورده</th><td><input type="number" min="0" step="0.01" name="sale_price" value="<?php echo esc_attr($v['sale_price']); ?>"></td></tr>
        <tr><th>Coming Soon</th><td><label><input type="checkbox" name="coming_soon" value="1" <?php checked($v['coming_soon'],'1'); ?>> فعال</label></td></tr><tr><th>وضعیت فروش</th><td><select name="course_status"><option value="draft" <?php selected($v['status'],'draft'); ?>>پیش‌نویس</option><option value="active" <?php selected($v['status'],'active'); ?>>فعال</option><option value="closed" <?php selected($v['status'],'closed'); ?>>بسته</option></select></td></tr>
        <tr><th>پوستر / تصویر</th><td><input type="number" name="banner_id" value="<?php echo esc_attr($v['banner_id']); ?>"></td></tr><tr><th>ویدئوی معرفی</th><td><input type="url" class="regular-text" name="trailer_url" value="<?php echo esc_attr($v['trailer_url']); ?>"></td></tr>
        <tr><th>مدرس</th><td><select name="instructor_id"><option value="0">بدون مدرس</option><?php foreach($teachers as $t): ?><option value="<?php echo absint($t['id']); ?>" <?php selected($v['instructor_id'],$t['id']); ?>><?php echo esc_html($t['name']); ?></option><?php endforeach; ?></select></td></tr>
        <tr><th>مدت</th><td><input class="regular-text" name="duration" value="<?php echo esc_attr($v['duration']); ?>"></td></tr><tr><th>تعداد جلسات</th><td><input type="number" min="0" name="sessions" value="<?php echo esc_attr($v['sessions']); ?>"></td></tr><tr><th>آنچه یاد می‌گیرید</th><td><textarea class="large-text" rows="6" name="outcomes"><?php echo esc_textarea($v['outcomes']); ?></textarea></td></tr><tr><th>نوع گواهینامه</th><td><input class="regular-text" name="certificate_type" value="<?php echo esc_attr($v['certificate_type']); ?>"></td></tr><tr><th>گواهینامه آنلاین</th><td><label><input type="checkbox" name="certificate_online" value="1" <?php checked($v['certificate_online'],'1'); ?>> دارد</label></td></tr><tr><th>وضعیت WordPress</th><td><select name="post_status"><option value="publish" <?php selected($v['post_status'],'publish'); ?>>منتشرشده</option><option value="draft" <?php selected($v['post_status'],'draft'); ?>>پیش‌نویس</option></select></td></tr>
        </table><button class="button button-primary" name="academy_hub_save_course" value="1">ذخیره دوره</button></form></div>
        <?php
    }

    private static function event_meta() {
        return array('status'=>'_academy_event_status','capacity'=>'_academy_event_capacity','date'=>'_academy_event_date','time'=>'_academy_event_time','location'=>'_academy_event_location','speakers'=>'_academy_event_speakers','banner_id'=>'_academy_event_banner_id','invitation_enabled'=>'_academy_event_invitation_enabled');
    }

    public static function events() {
        self::guard(); $posts=get_posts(array('post_type'=>'academy_event','post_status'=>array('publish','draft'),'posts_per_page'=>100,'orderby'=>'date','order'=>'DESC'));
        echo '<div class="wrap"><h1>مدیریت همایش‌ها و رویدادها</h1><p><a class="button button-primary" href="'.esc_url(admin_url('admin.php?page=academy-add-event')).'">+ افزودن رویداد</a></p><table class="widefat striped"><thead><tr><th>رویداد</th><th>تاریخ</th><th>محل</th><th>ظرفیت</th><th>ثبت‌نام</th><th>عملیات</th></tr></thead><tbody>';
        foreach($posts as $p){$m=self::event_meta();$reg=class_exists('Academy_Site_Events')?Academy_Site_Events::count_event_registrations($p->ID):0;echo '<tr><td>'.esc_html($p->post_title).'</td><td>'.esc_html(get_post_meta($p->ID,$m['date'],true)).'</td><td>'.esc_html(get_post_meta($p->ID,$m['location'],true)).'</td><td>'.esc_html(get_post_meta($p->ID,$m['capacity'],true)).'</td><td>'.esc_html($reg).'</td><td><a class="button" href="'.esc_url(admin_url('admin.php?page=academy-add-event&event_id='.$p->ID)).'">مدیریت</a></td></tr>';}
        if(!$posts)echo'<tr><td colspan="6">رویدادی ثبت نشده است.</td></tr>';echo'</tbody></table></div>';
    }

    public static function add_event() {
        self::guard(); $id=absint($_GET['event_id']??0); $p=$id?get_post($id):null; $m=self::event_meta();
        if('POST'===($_SERVER['REQUEST_METHOD']??'GET') && isset($_POST['academy_hub_save_event'])){
            check_admin_referer('academy_hub_event');$id=absint($_POST['event_id']??0);$title=sanitize_text_field(wp_unslash($_POST['name']??''));if(!$title)self::redirect('academy-add-event',array('academy_notice'=>'عنوان رویداد الزامی است.','academy_notice_type'=>'error'));
            $postarr=array('post_type'=>'academy_event','post_title'=>$title,'post_content'=>wp_kses_post(wp_unslash($_POST['description']??'')),'post_excerpt'=>sanitize_textarea_field(wp_unslash($_POST['excerpt']??'')),'post_status'=>sanitize_key($_POST['post_status']??'publish'));
            $saved=$id?wp_update_post(array_merge($postarr,array('ID'=>$id)),true):wp_insert_post($postarr,true);if(!$id&&!is_wp_error($saved))$id=(int)$saved;if(is_wp_error($saved))self::redirect('academy-add-event',array('academy_notice'=>$saved->get_error_message(),'academy_notice_type'=>'error'));
            foreach(array('status'=>sanitize_key($_POST['status']??'coming_soon'),'capacity'=>absint($_POST['capacity']??0),'date'=>sanitize_text_field(wp_unslash($_POST['date']??'')),'time'=>sanitize_text_field(wp_unslash($_POST['time']??'')),'location'=>sanitize_text_field(wp_unslash($_POST['location']??'')),'speakers'=>sanitize_textarea_field(wp_unslash($_POST['speakers']??'')),'banner_id'=>absint($_POST['banner_id']??0),'invitation_enabled'=>!empty($_POST['invitation_enabled'])?'1':'0') as $k=>$v)update_post_meta($id,$m[$k],$v);
            if($m['banner_id']&&absint($_POST['banner_id']??0))set_post_thumbnail($id,absint($_POST['banner_id']));
            self::redirect('academy-add-event',array('event_id'=>$id,'academy_notice'=>'رویداد ذخیره شد.'));
        }
        $v=array();foreach($m as $k=>$meta)$v[$k]=$id?get_post_meta($id,$meta,true):'';$v['name']=$p?$p->post_title:'';$v['description']=$p?$p->post_content:'';$v['excerpt']=$p?$p->post_excerpt:'';$v['post_status']=$p?$p->post_status:'publish';
        ?>
        <div class="wrap"><h1><?php echo $id?'مدیریت رویداد':'افزودن رویداد'; ?></h1><?php self::notice(); ?><form method="post"><?php wp_nonce_field('academy_hub_event'); ?><input type="hidden" name="event_id" value="<?php echo absint($id); ?>"><table class="form-table">
        <tr><th>عنوان</th><td><input class="regular-text" name="name" value="<?php echo esc_attr($v['name']); ?>" required></td></tr><tr><th>توضیحات</th><td><textarea class="large-text" rows="7" name="description"><?php echo esc_textarea($v['description']); ?></textarea></td></tr><tr><th>خلاصه</th><td><textarea class="large-text" rows="3" name="excerpt"><?php echo esc_textarea($v['excerpt']); ?></textarea></td></tr><tr><th>پوستر</th><td><input type="number" name="banner_id" value="<?php echo esc_attr($v['banner_id']); ?>"></td></tr>
        <tr><th>تاریخ</th><td><input name="date" value="<?php echo esc_attr($v['date']); ?>"></td></tr><tr><th>ساعت</th><td><input name="time" value="<?php echo esc_attr($v['time']); ?>"></td></tr><tr><th>محل</th><td><input class="regular-text" name="location" value="<?php echo esc_attr($v['location']); ?>"></td></tr><tr><th>سخنران‌ها</th><td><textarea class="large-text" rows="4" name="speakers"><?php echo esc_textarea($v['speakers']); ?></textarea></td></tr><tr><th>ظرفیت</th><td><input type="number" min="0" name="capacity" value="<?php echo esc_attr($v['capacity']); ?>"></td></tr>
        <tr><th>وضعیت</th><td><select name="status"><?php foreach(array('coming_soon'=>'Coming Soon','open'=>'باز','closed'=>'بسته','full'=>'تکمیل ظرفیت','cancelled'=>'لغوشده') as $k=>$l): ?><option value="<?php echo esc_attr($k); ?>" <?php selected($v['status'],$k); ?>><?php echo esc_html($l); ?></option><?php endforeach; ?></select></td></tr><tr><th>دعوتنامه</th><td><label><input type="checkbox" name="invitation_enabled" value="1" <?php checked($v['invitation_enabled'],'1'); ?>> فعال</label></td></tr><tr><th>وضعیت WordPress</th><td><select name="post_status"><option value="publish" <?php selected($v['post_status'],'publish'); ?>>منتشرشده</option><option value="draft" <?php selected($v['post_status'],'draft'); ?>>پیش‌نویس</option></select></td></tr>
        </table><button class="button button-primary" name="academy_hub_save_event" value="1">ذخیره رویداد</button></form>
        <?php if($id && class_exists('Academy_Site_Events')): self::event_tickets($id); endif; ?></div>
        <?php
    }

    private static function event_tickets($event_id) {
        if('POST'===($_SERVER['REQUEST_METHOD']??'GET') && isset($_POST['academy_hub_ticket_action'])){
            check_admin_referer('academy_hub_ticket_'.$event_id);
            $op=sanitize_key($_POST['academy_hub_ticket_action']);
            if($op==='add'){ $r=Academy_Site_Events::add_ticket_type($event_id,array('ticket_key'=>sanitize_key($_POST['ticket_key']??''),'name'=>sanitize_text_field(wp_unslash($_POST['ticket_name']??'')),'price'=>(float)($_POST['ticket_price']??0),'capacity'=>($_POST['ticket_capacity']??'')===' '?null:($_POST['ticket_capacity']??''),'status'=>'active')); if(is_wp_error($r))echo'<div class="notice notice-error"><p>'.esc_html($r->get_error_message()).'</p></div>'; }
            if($op==='delete'){ $r=Academy_Site_Events::delete_ticket_type(absint($_POST['ticket_id']??0)); if(is_wp_error($r))echo'<div class="notice notice-error"><p>'.esc_html($r->get_error_message()).'</p></div>'; }
        }
        $tickets=Academy_Site_Events::get_ticket_types($event_id,false);
        echo '<div class="academy-detail-box"><h2>انواع بلیت</h2><table class="widefat striped"><thead><tr><th>نوع</th><th>نام</th><th>قیمت</th><th>ظرفیت</th><th>فروخته/ثبت‌نام</th><th></th></tr></thead><tbody>';
        foreach($tickets as$t){$count=Academy_Site_Events::count_ticket_registrations($t->id);echo'<tr><td>'.esc_html($t->ticket_key).'</td><td>'.esc_html($t->name).'</td><td>'.esc_html(number_format_i18n((float)$t->price)).'</td><td>'.esc_html($t->capacity===null?'نامحدود':$t->capacity).'</td><td>'.esc_html($count).'</td><td><form method="post">'.wp_nonce_field('academy_hub_ticket_'.$event_id,'_wpnonce',true,false).'<input type="hidden" name="academy_hub_ticket_action" value="delete"><input type="hidden" name="ticket_id" value="'.absint($t->id).'"><button class="button button-small" onclick="return confirm(\'حذف شود؟\')">حذف</button></form></td></tr>';}
        echo'</tbody></table><h3>افزودن بلیت</h3><form method="post">'.wp_nonce_field('academy_hub_ticket_'.$event_id,'_wpnonce',true,false).'<input type="hidden" name="academy_hub_ticket_action" value="add"><select name="ticket_key"><option value="regular">عادی</option><option value="vip">VIP</option><option value="cip">CIP</option></select> <input required name="ticket_name" placeholder="عنوان بلیت"> <input type="number" min="0" step="0.01" name="ticket_price" placeholder="قیمت"> <input type="number" min="0" name="ticket_capacity" placeholder="ظرفیت اختیاری"> <button class="button button-primary">افزودن بلیت</button></form></div>';
    }

    public static function certificate_dashboard() {
        self::guard();
        self::cert_header('گواهینامه‌ها');

        echo '<div class="academy-hub-grid">';
        $items = array(
            array('قالب‌های گواهینامه','ثبت، ویرایش، حذف و آرشیو قالب‌های گواهینامه.','academy-certificate-templates'),
            array('گواهینامه‌های دوره‌ها','انتخاب قالب برای دوره‌ها و مشاهده آرشیو گواهینامه‌های دوره.','academy-course-certificates'),
            array('صدور دستی گواهینامه','صدور دستی با قالب، نام و نام خانوادگی، کد ملی، تاریخ و مدت دوره.','academy-manual-certificates'),
            array('آرشیو دارندگان گواهینامه','مشاهده تمام گواهینامه‌ها با امکان ویرایش و حذف هر رکورد.','academy-certificate-holders'),
        );
        foreach ( $items as $item ) {
            echo '<div class="academy-hub-card">';
            echo '<h2>'.esc_html($item[0]).'</h2>';
            echo '<p>'.esc_html($item[1]).'</p>';
            echo '<a class="button button-primary" href="'.esc_url(admin_url('admin.php?page='.$item[2])).'">ورود</a>';
            echo '</div>';
        }
        echo '</div>';

        self::cert_footer();
    }

    public static function certificates() { self::certificate_templates(); }

    private static function cert_header($title){echo '<div class="wrap"><h1>'.esc_html($title).'</h1>';self::notice();}
    private static function cert_footer(){echo '</div>';}
    private static function cert_nav(){echo '<p><a class="button" href="'.esc_url(admin_url('admin.php?page=academy-certificate-templates')).'">قالب‌ها</a> <a class="button" href="'.esc_url(admin_url('admin.php?page=academy-course-certificates')).'">گواهینامه‌های دوره‌ها</a> <a class="button" href="'.esc_url(admin_url('admin.php?page=academy-manual-certificates')).'">صدور دستی</a> <a class="button" href="'.esc_url(admin_url('admin.php?page=academy-certificate-holders')).'">آرشیو دارندگان</a></p>'; }

    public static function certificate_templates(){self::guard();if('POST'===($_SERVER['REQUEST_METHOD']??'GET')){
        if(isset($_POST['academy_cert_save_template'])){check_admin_referer('academy_cert_template');$r=Academy_Site_Certificates::save_template(array('title'=>wp_unslash($_POST['title']??''),'mode'=>wp_unslash($_POST['mode']??'text'),'image_url'=>wp_unslash($_POST['image_url']??''),'body_text'=>wp_unslash($_POST['body_text']??''),'custom_field'=>wp_unslash($_POST['custom_field']??'')),absint($_POST['template_id']??0));self::redirect('academy-certificate-templates',array('academy_notice'=>is_wp_error($r)?$r->get_error_message():'قالب با موفقیت ذخیره شد.','academy_notice_type'=>is_wp_error($r)?'error':''));}
        if(isset($_POST['academy_cert_delete_template'])){check_admin_referer('academy_cert_delete_template');$r=Academy_Site_Certificates::delete_template(absint($_POST['template_id']??0));self::redirect('academy-certificate-templates',array('academy_notice'=>is_wp_error($r)?$r->get_error_message():'قالب حذف شد.','academy_notice_type'=>is_wp_error($r)?'error':''));}}
        $edit=absint($_GET['edit']??0);$t=$edit?Academy_Site_Certificates::get_template($edit):null;$templates=Academy_Site_Certificates::get_templates();self::cert_header('قالب‌های گواهینامه');self::cert_nav();echo '<h2>'.($t?'ویرایش قالب':'ثبت قالب جدید').'</h2><form method="post">';wp_nonce_field('academy_cert_template');echo '<input type="hidden" name="template_id" value="'.absint($edit).'">';echo '<table class="form-table"><tr><th>عنوان قالب</th><td><input required class="regular-text" name="title" value="'.esc_attr($t->title??'').'" /></td></tr><tr><th>نوع</th><td><select name="mode"><option value="text" '.selected($t->mode??'text','text',false).'>متن</option><option value="image" '.selected($t->mode??'','image',false).'>عکس</option><option value="image_text" '.selected($t->mode??'','image_text',false).'>متن + عکس</option></select></td></tr><tr><th>لینک عکس</th><td><input class="large-text" type="url" name="image_url" value="'.esc_attr($t->image_url??'').'" /></td></tr><tr><th>متن استعلام</th><td><textarea required class="large-text code" rows="10" name="body_text">'.esc_textarea($t->body_text??'').'</textarea><p class="description">متغیرهای ثابت قابل استفاده در متن استعلام (برای درج سریع روی هر متغیر کلیک کنید):<br>
<code class="academy-cert-var" data-var="{{student-name}}">{{student-name}}</code> 
<code class="academy-cert-var" data-var="{{national-id}}">{{national-id}}</code> 
<code class="academy-cert-var" data-var="{{date}}">{{date}}</code> 
<code class="academy-cert-var" data-var="{{duration}}">{{duration}}</code> 
<code class="academy-cert-var" data-var="{{template-title}}">{{template-title}}</code> 
<code class="academy-cert-var" data-var="{{custom-field}}">{{custom-field}}</code> 
<code class="academy-cert-var" data-var="{{certificate-qr}}">{{certificate-qr}}</code></p>
<script>document.addEventListener("click",function(e){var el=e.target.closest(".academy-cert-var");if(!el)return;var ta=document.querySelector("textarea[name=body_text]");if(!ta)return;e.preventDefault();var v=el.getAttribute("data-var")||"";var a=ta.selectionStart,b=ta.selectionEnd;ta.value=ta.value.slice(0,a)+v+ta.value.slice(b);ta.focus();ta.setSelectionRange(a+v.length,a+v.length);});</script></td></tr><tr><th>فیلد آزاد</th><td><textarea class="large-text" rows="5" name="custom_field">'.esc_textarea($t->custom_field??'').'</textarea></td></tr></table>';submit_button($t?'ویرایش قالب':'ذخیره قالب','primary','academy_cert_save_template');echo '</form><hr><h2>آرشیو قالب‌ها</h2><table class="widefat striped"><thead><tr><th>عنوان</th><th>نوع</th><th>تاریخ</th><th>عملیات</th></tr></thead><tbody>';
        foreach($templates as $row){echo '<tr><td>'.esc_html($row->title).'</td><td>'.esc_html($row->mode).'</td><td>'.esc_html($row->created_at).'</td><td><a class="button" href="'.esc_url(admin_url('admin.php?page=academy-certificate-templates&edit='.$row->id)).'">ویرایش</a> <form style="display:inline" method="post">'.wp_nonce_field('academy_cert_delete_template','_wpnonce',true,false).'<input type="hidden" name="template_id" value="'.absint($row->id).'"> <button class="button" name="academy_cert_delete_template" value="1" onclick="return confirm(\'حذف شود؟\')">حذف</button></form></td></tr>';}
        if(!$templates)echo '<tr><td colspan="4">قالبی ثبت نشده است.</td></tr>';echo '</tbody></table>';self::cert_footer();
    }

    public static function course_certificates(){
        self::guard();
        if(isset($_POST['academy_cert_assign_course'])){check_admin_referer('academy_cert_course');$r=Academy_Site_Certificates::assign_course_template(absint($_POST['course_id']??0),absint($_POST['template_id']??0));self::redirect('academy-course-certificates',array('academy_notice'=>is_wp_error($r)?$r->get_error_message():'اتصال قالب به دوره ذخیره شد.','academy_notice_type'=>is_wp_error($r)?'error':''));}
        $courses=get_posts(array('post_type'=>'academy_course','post_status'=>array('publish','draft'),'posts_per_page'=>500,'orderby'=>'title','order'=>'ASC'));$templates=Academy_Site_Certificates::get_templates();
        self::cert_header('گواهینامه‌های دوره‌ها');self::cert_nav();
        echo '<form method="post">';wp_nonce_field('academy_cert_course');echo '<table class="form-table"><tr><th>دوره</th><td><select name="course_id" required><option value="">انتخاب دوره</option>';foreach($courses as $c){echo '<option value="'.absint($c->ID).'">'.esc_html($c->post_title).'</option>';}echo '</select></td></tr><tr><th>قالب</th><td><select name="template_id"><option value="0">بدون گواهینامه</option>';foreach($templates as $t){echo '<option value="'.absint($t->id).'">'.esc_html($t->title).'</option>';}echo '</select></td></tr></table>';submit_button('ذخیره اتصال','primary','academy_cert_assign_course');echo '</form>';
        echo '<hr><h2>آرشیو گواهینامه‌های دوره</h2><table class="widefat striped"><thead><tr><th>دانشجو</th><th>دوره</th><th>قالب</th><th>کد استعلام</th><th>تاریخ</th><th>QR</th></tr></thead><tbody>';
        $rows=Academy_Site_Certificates::all_issued();$has=false;foreach($rows as $r){if(!$r->course_id)continue;$has=true;$t=Academy_Site_Certificates::get_template($r->template_id);$qr=Academy_Site_Certificates::qr_url($r->verification_code);echo '<tr><td>'.esc_html($r->student_name).'</td><td>'.esc_html(get_the_title($r->course_id)).'</td><td>'.esc_html($t->title??'-').'</td><td><code>'.esc_html($r->verification_code).'</code></td><td>'.esc_html($r->issue_date).'</td><td>'.($qr?'<img src="'.esc_url($qr).'" width="60" height="60">':'-').'</td></tr>';}
        if(!$has)echo '<tr><td colspan="6">هنوز گواهینامه دوره‌ای صادر نشده است.</td></tr>';echo '</tbody></table>';self::cert_footer();
    }

    public static function manual_certificates(){self::guard();if(isset($_POST['academy_cert_issue_manual'])){check_admin_referer('academy_cert_manual');$name=sanitize_text_field(wp_unslash($_POST['student_name']??''));$national=Academy_Site_Certificates::normalize_national_id(wp_unslash($_POST['national_id']??''));$tid=absint($_POST['template_id']??0);$duration=sanitize_text_field(wp_unslash($_POST['duration']??''));$r=Academy_Site_Certificates::issue(0,0,array('template_id'=>$tid,'student_name'=>$name,'national_id'=>$national,'issue_date'=>sanitize_text_field(wp_unslash($_POST['issue_date']??'')),'duration'=>$duration));self::redirect('academy-manual-certificates',array('academy_notice'=>is_wp_error($r)?$r->get_error_message():'گواهینامه دستی صادر شد. کد: '.$r->verification_code,'academy_notice_type'=>is_wp_error($r)?'error':''));}$templates=Academy_Site_Certificates::get_templates();self::cert_header('صدور دستی گواهینامه');self::cert_nav();echo '<form method="post">';wp_nonce_field('academy_cert_manual');echo '<table class="form-table"><tr><th>قالب</th><td><select name="template_id" required><option value="">انتخاب قالب</option>';foreach($templates as $t)echo '<option value="'.absint($t->id).'">'.esc_html($t->title).'</option>';echo '</select></td></tr><tr><th>نام و نام خانوادگی</th><td><input class="regular-text" required name="student_name"></td></tr><tr><th>کد ملی</th><td><input class="regular-text" required inputmode="numeric" name="national_id"></td></tr><tr><th>تاریخ</th><td><input class="regular-text" required name="issue_date" placeholder="مثلاً ۱ اسفند ۱۴۰۴"><p class="description">هر تاریخی که برای این گواهینامه می‌خواهید وارد کنید؛ این تاریخ فقط برای همین گواهینامه ذخیره می‌شود.</p></td></tr><tr><th>مدت دوره</th><td><input class="regular-text" required name="duration" placeholder="مثلاً ۱۲ ساعت"><p class="description">مدت دوره‌ای که روی همین گواهینامه نمایش داده می‌شود.</p></td></tr></table>';submit_button('صدور گواهینامه','primary','academy_cert_issue_manual');echo '</form>';self::cert_footer();}

    public static function certificate_holders(){
        self::guard();

        if ( 'POST' === ($_SERVER['REQUEST_METHOD'] ?? 'GET') ) {
            if ( isset($_POST['academy_cert_holder_update']) ) {
                check_admin_referer('academy_cert_holder_edit');
                $id = absint($_POST['certificate_id'] ?? 0);
                $r = Academy_Site_Certificates::update_issued($id, array(
                    'template_id'  => absint($_POST['template_id'] ?? 0),
                    'student_name' => sanitize_text_field(wp_unslash($_POST['student_name'] ?? '')),
                    'national_id'  => sanitize_text_field(wp_unslash($_POST['national_id'] ?? '')),
                    'issue_date'   => sanitize_text_field(wp_unslash($_POST['issue_date'] ?? '')),
                    'duration'     => sanitize_text_field(wp_unslash($_POST['duration'] ?? '')),
                ));
                self::redirect('academy-certificate-holders', array(
                    'academy_notice' => is_wp_error($r) ? $r->get_error_message() : 'گواهینامه با موفقیت ویرایش شد.',
                    'academy_notice_type' => is_wp_error($r) ? 'error' : ''
                ));
            }

            if ( isset($_POST['academy_cert_holder_delete']) ) {
                check_admin_referer('academy_cert_holder_delete');
                $id = absint($_POST['certificate_id'] ?? 0);
                $r = Academy_Site_Certificates::delete_issued($id);
                self::redirect('academy-certificate-holders', array(
                    'academy_notice' => is_wp_error($r) ? $r->get_error_message() : 'گواهینامه حذف شد.',
                    'academy_notice_type' => is_wp_error($r) ? 'error' : ''
                ));
            }
        }

        $edit = absint($_GET['edit'] ?? 0);
        $editing = $edit ? Academy_Site_Certificates::get($edit) : null;

        self::cert_header('آرشیو دارندگان گواهینامه');
        self::cert_nav();

        if ( $editing ) {
            $templates = Academy_Site_Certificates::get_templates();
            echo '<h2>ویرایش گواهینامه</h2><form method="post">';
            wp_nonce_field('academy_cert_holder_edit');
            echo '<input type="hidden" name="certificate_id" value="'.absint($editing->id).'">';
            echo '<table class="form-table">';
            echo '<tr><th>قالب</th><td><select name="template_id" required>';
            foreach($templates as $t) echo '<option value="'.absint($t->id).'" '.selected($editing->template_id,$t->id,false).'>'.esc_html($t->title).'</option>';
            echo '</select></td></tr>';
            echo '<tr><th>نام و نام خانوادگی</th><td><input class="regular-text" required name="student_name" value="'.esc_attr($editing->student_name).'"></td></tr>';
            echo '<tr><th>کد ملی</th><td><input class="regular-text" name="national_id" value="'.esc_attr($editing->national_id).'"></td></tr>';
            echo '<tr><th>تاریخ</th><td><input class="regular-text" required name="issue_date" value="'.esc_attr($editing->issue_date).'"></td></tr>';
            echo '<tr><th>مدت دوره</th><td><input class="regular-text" name="duration" value="'.esc_attr($editing->duration).'"></td></tr>';
            echo '</table>';
            submit_button('ذخیره تغییرات','primary','academy_cert_holder_update');
            echo ' <a class="button" href="'.esc_url(admin_url('admin.php?page=academy-certificate-holders')).'">انصراف</a>';
            echo '</form><hr>';
        }

        $rows=Academy_Site_Certificates::all_issued();
        echo '<table class="widefat striped"><thead><tr><th>نام</th><th>کد ملی</th><th>قالب</th><th>تاریخ</th><th>مدت</th><th>کد استعلام</th><th>QR</th><th>وضعیت</th><th>عملیات</th></tr></thead><tbody>';
        foreach($rows as $r){
            $t=Academy_Site_Certificates::get_template($r->template_id);
            $qr=Academy_Site_Certificates::qr_url($r->verification_code);
            echo '<tr><td>'.esc_html($r->student_name).'</td><td>'.esc_html($r->national_id?:'-').'</td><td>'.esc_html($t->title??'-').'</td><td>'.esc_html($r->issue_date).'</td><td>'.esc_html($r->duration?:'-').'</td><td><code>'.esc_html($r->verification_code).'</code></td><td>'.($qr?'<img src="'.esc_url($qr).'" width="70" height="70">':'-').'</td><td>'.esc_html($r->status).'</td><td>';
            echo '<a class="button button-small" href="'.esc_url(admin_url('admin.php?page=academy-certificate-holders&edit='.absint($r->id))).'">ویرایش</a> ';
            echo '<form style="display:inline" method="post">'.wp_nonce_field('academy_cert_holder_delete','_wpnonce',true,false).'<input type="hidden" name="certificate_id" value="'.absint($r->id).'"><button class="button button-small" name="academy_cert_holder_delete" value="1" onclick="return confirm(\'این گواهینامه حذف شود؟\')">حذف</button></form>';
            echo '</td></tr>';
        }
        if(!$rows) echo '<tr><td colspan="9">گواهینامه‌ای صادر نشده است.</td></tr>';
        echo '</tbody></table>';
        self::cert_footer();
    }

    public static function crm() {
        self::guard();
        if(class_exists('Academy_Site_Campaigns') && method_exists('Academy_Site_Campaigns','admin_page')) Academy_Site_Campaigns::admin_page();
        else echo '<div class="wrap"><h1>CRM</h1><div class="notice notice-error"><p>ماژول CRM فعال نیست.</p></div></div>';
    }

    public static function sms() {
        self::guard();
        echo '<div class="wrap"><h1>SMS.ir</h1>';
        if(class_exists('Academy_Site_SMS') && method_exists('Academy_Site_SMS','settings_page')) Academy_Site_SMS::settings_page();
        else echo '<div class="notice notice-error"><p>ماژول SMS.ir فعال نیست.</p></div>';
        echo '</div>';
    }

    public static function commerce() {
        self::guard();
        echo '<div class="wrap"><h1>فروش و پرداخت</h1>';
        if(class_exists('Academy_Site_Commerce') && method_exists('Academy_Site_Commerce','settings_page')) Academy_Site_Commerce::settings_page();
        else echo '<div class="notice notice-error"><p>ماژول پرداخت فعال نیست.</p></div>';
        self::commerce_orders();
        echo '</div>';
    }

    private static function commerce_orders() {
        if(!class_exists('Academy_Site_Commerce')) return;
        global $wpdb; $table=$wpdb->prefix.Academy_Site_Commerce::ORDERS;
        $rows=$wpdb->get_results("SELECT * FROM {$table} ORDER BY id DESC LIMIT 100");
        echo '<h2>آخرین سفارش‌ها</h2><table class="widefat striped"><thead><tr><th>شماره</th><th>دانشجو</th><th>نوع</th><th>مورد</th><th>مبلغ</th><th>وضعیت</th><th>تاریخ</th></tr></thead><tbody>';
        foreach($rows as$r){echo'<tr><td>#'.absint($r->id).'</td><td>'.esc_html(get_userdata($r->user_id)?get_userdata($r->user_id)->display_name:'-').'</td><td>'.esc_html($r->item_type).'</td><td>'.esc_html($r->item_id).'</td><td>'.esc_html(number_format_i18n((float)$r->amount)).' '.esc_html($r->currency).'</td><td>'.esc_html($r->status).'</td><td>'.esc_html($r->created_at).'</td></tr>';}
        if(!$rows)echo'<tr><td colspan="7">سفارشی ثبت نشده است.</td></tr>';echo'</tbody></table>';
    }

    public static function consultation() {
        self::guard();
        if(!class_exists('Academy_Site_Consultations')){echo'<div class="wrap"><h1>مشاوره</h1><div class="notice notice-error"><p>ماژول مشاوره فعال نیست.</p></div></div>';return;}
        global $wpdb; $table=Academy_Site_Consultations::table();
        if('POST'===($_SERVER['REQUEST_METHOD']??'GET') && isset($_POST['academy_consult_update'])){
            check_admin_referer('academy_consult_update');
            $id=absint($_POST['id']??0);$status=sanitize_key($_POST['status']??'new');$consultant=sanitize_text_field(wp_unslash($_POST['consultant_name']??''));$mobile=sanitize_text_field(wp_unslash($_POST['consultant_mobile']??''));
            $wpdb->update($table,array('status'=>$status,'consultant_name'=>$consultant,'consultant_mobile'=>$mobile,'updated_at'=>current_time('mysql',true)),array('id'=>$id),array('%s','%s','%s','%s'),array('%d'));
        }
        $rows=$wpdb->get_results("SELECT * FROM {$table} ORDER BY id DESC LIMIT 200");
        echo'<div class="wrap"><h1>مدیریت مشاوره</h1><table class="widefat striped"><thead><tr><th>متقاضی</th><th>موبایل</th><th>نوع</th><th>زمان تماس</th><th>وضعیت</th><th>مشاور</th><th>عملیات</th></tr></thead><tbody>';
        foreach($rows as$r){echo'<tr><td>'.esc_html($r->first_name.' '.$r->last_name).'</td><td>'.esc_html($r->mobile).'</td><td>'.esc_html($r->consultation_type).'</td><td>'.esc_html($r->preferred_period).'</td><td>'.esc_html($r->status).'</td><td>'.esc_html($r->consultant_name).'</td><td><details><summary>ویرایش</summary><form method="post">'.wp_nonce_field('academy_consult_update','_wpnonce',true,false).'<input type="hidden" name="id" value="'.absint($r->id).'"><select name="status"><option value="new" '.selected($r->status,'new',false).'>جدید</option><option value="contacted" '.selected($r->status,'contacted',false).'>تماس گرفته شد</option><option value="scheduled" '.selected($r->status,'scheduled',false).'>زمان‌بندی شد</option><option value="completed" '.selected($r->status,'completed',false).'>انجام شد</option><option value="cancelled" '.selected($r->status,'cancelled',false).'>لغو</option></select> <input name="consultant_name" value="'.esc_attr($r->consultant_name).'"> <input name="consultant_mobile" value="'.esc_attr($r->consultant_mobile).'"> <button class="button">ذخیره</button></form></details></td></tr>';}
        if(!$rows)echo'<tr><td colspan="7">درخواستی ثبت نشده است.</td></tr>';echo'</tbody></table></div>';
    }

    public static function wallet() {
        self::guard();
        echo '<div class="wrap"><h1>مدیریت کیف پول</h1><p>برای تغییر موجودی هر دانشجو وارد پرونده کامل او شوید.</p><p><a class="button button-primary" href="'.esc_url(admin_url('admin.php?page=academy-students-hub')).'">انتخاب دانشجو</a></p>';
        if(class_exists('Academy_Site_Wallet')) {
            global $wpdb; $t=Academy_Site_Wallet::tables()['transactions']; $rows=$wpdb->get_results("SELECT * FROM {$t} ORDER BY id DESC LIMIT 100");
            echo'<h2>آخرین تراکنش‌ها</h2><table class="widefat striped"><thead><tr><th>دانشجو</th><th>نوع</th><th>مبلغ</th><th>مانده بعد</th><th>توضیح</th><th>انقضا</th><th>تاریخ</th></tr></thead><tbody>';
            foreach($rows as$r){$u=get_userdata($r->user_id);echo'<tr><td>'.esc_html($u?$u->display_name:'-').'</td><td>'.esc_html($r->type).'</td><td>'.esc_html(number_format_i18n((float)$r->amount)).'</td><td>'.esc_html(number_format_i18n((float)$r->balance_after)).'</td><td>'.esc_html($r->description).'</td><td>'.esc_html($r->expires_at).'</td><td>'.esc_html($r->created_at).'</td></tr>';}
            echo'</tbody></table>';
        }
        echo'</div>';
    }

    public static function pages() {
        self::guard();
        $keys=array('login_url'=>'صفحه ورود','register_url'=>'صفحه ثبت‌نام','otp_url'=>'صفحه OTP','complete_registration_url'=>'تکمیل ثبت‌نام','welcome_url'=>'خوش‌آمدگویی','consultation_url'=>'مشاوره','certificate_verify_url'=>'صفحه ورود استعلام','certificate_results_url'=>'صفحه نتایج استعلام','certificate_detail_url'=>'صفحه متن استعلام گواهینامه','student_dashboard_url'=>'پنل دانشجو');
        if('POST'===($_SERVER['REQUEST_METHOD']??'GET') && isset($_POST['academy_pages_save'])){check_admin_referer('academy_site_pages');foreach($keys as $k=>$l)update_option('academy_site_'.$k,esc_url_raw(wp_unslash($_POST[$k]??'')));echo'<div class="notice notice-success"><p>صفحات ذخیره شدند.</p></div>';}
        echo'<div class="wrap"><h1>صفحات سیستم</h1><form method="post">'.wp_nonce_field('academy_site_pages','_wpnonce',true,false).'<table class="form-table">';
        foreach($keys as$k=>$l)echo'<tr><th>'.esc_html($l).'</th><td><input type="url" class="regular-text" name="'.esc_attr($k).'" value="'.esc_attr(get_option('academy_site_'.$k,'')).'"></td></tr>';
        echo'</table><button class="button button-primary" name="academy_pages_save" value="1">ذخیره صفحات</button></form></div>';
    }

    public static function modules() {
        self::guard(); $states=get_option('academy_site_loaded_modules',array());if(!is_array($states))$states=array();$manifest=function_exists('academy_site_module_manifest')?academy_site_module_manifest():array();
        echo'<div class="wrap"><h1>وضعیت ماژول‌ها</h1><p>وضعیت ذخیره‌شده فقط گزارش است؛ Loader نباید Module را در درخواست بعدی Skip کند.</p><table class="widefat striped"><thead><tr><th>Module</th><th>وضعیت</th><th>فایل</th></tr></thead><tbody>';
        foreach($manifest as$m){$file=ACADEMY_SITE_PATH.'modules/'.$m.'/'.$m.'.php';echo'<tr><td><code>'.esc_html($m).'</code></td><td>'.esc_html($states[$m]??'not-loaded').'</td><td>'.(file_exists($file)?'✓':'✕').'</td></tr>';}
        echo'</tbody></table></div>';
    }
}
Academy_Site_Admin_Hub::boot();
