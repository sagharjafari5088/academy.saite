jQuery(function($){
  const form = $('#academy-consultation-form');
  if(!form.length) return;
  form.on('submit', function(e){
    e.preventDefault();
    const btn=form.find('.ac-consult-submit'), msg=form.find('.ac-consult-message');
    msg.removeClass('error success').text('');
    btn.prop('disabled',true); btn.find('span:first').hide(); btn.find('.ac-loading').prop('hidden',false);
    const data=form.serializeArray(); data.push({name:'action',value:'academy_submit_consultation'},{name:'nonce',value:AcademyConsultations.nonce});
    $.post(AcademyConsultations.ajaxUrl,data).done(function(res){
      if(res.success && res.data.redirect){ window.location.href=res.data.redirect; return; }
      msg.addClass('error').text(res.data && res.data.message ? res.data.message : 'ثبت درخواست ناموفق بود.');
    }).fail(function(xhr){ msg.addClass('error').text(xhr.responseJSON?.data?.message || 'خطایی رخ داد. دوباره تلاش کنید.');
    }).always(function(){ btn.prop('disabled',false); btn.find('span:first').show(); btn.find('.ac-loading').prop('hidden',true); });
  });
});
