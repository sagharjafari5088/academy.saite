<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Academy_Site_Consultations {
    const TABLE_SUFFIX = 'academy_consultations';

    public static function init() {
        self::maybe_upgrade();
        self::ensure_columns();
        add_shortcode( 'academy_consultation_form', array( __CLASS__, 'shortcode_form' ) );
        add_shortcode( 'academy_consultation_confirmation', array( __CLASS__, 'shortcode_confirmation' ) );
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
    }

    public static function table() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE_SUFFIX;
    }

    public static function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $table = self::table();
        $sql = "CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            tracking_code VARCHAR(32) NOT NULL,
            confirmation_token_hash CHAR(64) NOT NULL,
            first_name VARCHAR(100) NOT NULL,
            last_name VARCHAR(100) NOT NULL,
            mobile VARCHAR(20) NOT NULL,
            consultation_type VARCHAR(40) NOT NULL,
            preferred_period VARCHAR(20) NULL,
            reason TEXT NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'new',
            consultant_name VARCHAR(150) NULL,
            consultant_mobile VARCHAR(20) NULL,
            client_sms_status VARCHAR(20) NOT NULL DEFAULT 'pending',
            consultant_sms_status VARCHAR(20) NOT NULL DEFAULT 'pending',
            session_date DATE NULL,
            session_time TIME NULL,
            session_mode VARCHAR(30) NULL,
            session_link TEXT NULL,
            session_notes TEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY tracking_code (tracking_code),
            KEY mobile (mobile),
            KEY status (status),
            KEY created_at (created_at)
        ) {$charset};";
        dbDelta( $sql );
    }

    public static function maybe_upgrade() {
        $version = get_option( 'academy_site_consultations_db_version', '0' );
        if ( version_compare( $version, '1.1.0', '<' ) ) {
            self::activate();
            global $wpdb;
            $table = self::table();
            $columns = array(
                'session_date' => "DATE NULL",
                'session_time' => "TIME NULL",
                'session_mode' => "VARCHAR(30) NULL",
                'session_link' => "TEXT NULL",
                'session_notes' => "TEXT NULL",
                'preferred_period' => "VARCHAR(20) NULL",
            );
            foreach ( $columns as $column => $definition ) {
                $exists = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$table} LIKE %s", $column ) );
                if ( ! $exists ) $wpdb->query( "ALTER TABLE {$table} ADD {$column} {$definition}" );
            }
            update_option( 'academy_site_consultations_db_version', '1.1.0' );
        }
    }

    public static function ensure_columns() {
        global $wpdb; $table=self::table(); $exists=$wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM {$table} LIKE %s",'preferred_period')); if(!$exists) $wpdb->query("ALTER TABLE {$table} ADD preferred_period VARCHAR(20) NULL");
    }

    public static function assets() {
        wp_enqueue_style( 'academy-site-consultations', plugins_url( 'assets/css/consultations.css', __FILE__ ), array(), ACADEMY_SITE_VERSION );
        wp_enqueue_script( 'academy-site-consultations', plugins_url( 'assets/js/consultations.js', __FILE__ ), array( 'jquery' ), ACADEMY_SITE_VERSION, true );
        wp_localize_script( 'academy-site-consultations', 'AcademyConsultations', array(
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            'nonce' => wp_create_nonce( 'academy_consultation_submit' ),
            'successText' => 'درخواست شما با موفقیت ثبت شد.',
        ) );
    }

    public static function shortcode_form() {
        $types = academy_site_consultation_types();
        ob_start(); ?>
        <form class="academy-consultation-form" id="academy-consultation-form" novalidate>
            <div class="ac-consult-grid">
                <div class="ac-field"><label>نام <span>*</span></label><input type="text" name="first_name" required maxlength="100"></div>
                <div class="ac-field"><label>نام خانوادگی <span>*</span></label><input type="text" name="last_name" required maxlength="100"></div>
                <div class="ac-field"><label>شماره موبایل <span>*</span></label><input type="tel" name="mobile" inputmode="tel" required maxlength="20" placeholder="09xxxxxxxxx"></div>
                <div class="ac-field"><label>نوع مشاوره <span>*</span></label><select name="consultation_type" required><option value="">انتخاب کنید</option><?php foreach ( $types as $key => $label ) : ?><option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></div><div class="ac-field"><label>زمان تماس <span>*</span></label><select name="preferred_period" required><option value="">انتخاب کنید</option><option value="morning">صبح</option><option value="afternoon">عصر</option></select></div>
                <div class="ac-field ac-field-full"><label>توضیحات و علت درخواست مشاوره <span>*</span></label><textarea name="reason" rows="6" required maxlength="5000" placeholder="موضوع، چالش یا هدفی که می‌خواهید درباره آن مشاوره بگیرید را توضیح دهید..."></textarea></div>
            </div>
            <div class="ac-consult-message" aria-live="polite"></div>
            <button type="submit" class="ac-consult-submit"><span>ثبت درخواست مشاوره</span><span class="ac-loading" hidden>در حال ثبت...</span></button>
        </form>
        <?php return ob_get_clean();
    }

    public static function shortcode_confirmation() {
        $token = isset( $_GET['consultation_confirmation'] ) ? sanitize_text_field( wp_unslash( $_GET['consultation_confirmation'] ) ) : '';
        if ( ! $token ) return '<div class="ac-consult-confirm"><h2>درخواست مشاوره</h2><p>درخواست معتبری برای نمایش وجود ندارد.</p></div>';
        global $wpdb;
        $hash = hash( 'sha256', $token );
        $row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE confirmation_token_hash = %s LIMIT 1', $hash ) );
        if ( ! $row ) return '<div class="ac-consult-confirm"><h2>درخواست مشاوره</h2><p>اطلاعات درخواست پیدا نشد یا لینک معتبر نیست.</p></div>';
        $types = academy_site_consultation_types();
        ob_start(); ?>
        <div class="ac-consult-confirm">
            <div class="ac-confirm-icon">✓</div>
            <h2>درخواست مشاوره شما ثبت شد</h2>
            <p>درخواست شما با موفقیت ثبت شده است. مشاوران آکادمی در اسرع وقت با شما تماس خواهند گرفت.</p>
            <div class="ac-confirm-card">
                <div><small>نام متقاضی</small><strong><?php echo esc_html( $row->first_name . ' ' . $row->last_name ); ?></strong></div>
                <div><small>نوع مشاوره</small><strong><?php echo esc_html( $types[ $row->consultation_type ] ?? $row->consultation_type ); ?></strong></div>
                <div><small>کد پیگیری</small><strong dir="ltr"><?php echo esc_html( $row->tracking_code ); ?></strong></div>
            </div>
            <p class="ac-confirm-note">کد پیگیری خود را برای پیگیری‌های بعدی نزد خود نگه دارید.</p>
        </div>
        <?php return ob_get_clean();
    }

    public static function send_sms( $mobile, $message, $template_key = 'consultation', $parameters = array() ) {
        if ( ! class_exists( 'Academy_Site_SMS' ) ) return false;
        $r = Academy_Site_SMS::send_template( 0, $template_key, $parameters, array( 'phone' => $mobile ) );
        return ! is_wp_error( $r );
    }

    public static function get( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $id ) );
    }
}
