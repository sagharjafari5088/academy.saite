<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Academy_Site_Consultations_Admin {
    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
        add_action( 'admin_init', array( __CLASS__, 'settings' ) );
        add_action( 'admin_post_academy_consultation_update', array( __CLASS__, 'update_request' ) );
    }

    public static function menu() {
        add_menu_page( 'مشاوره‌ها', 'مشاوره‌ها', 'manage_options', 'academy-consultations', array( __CLASS__, 'page' ), 'dashicons-format-chat', 31 );
        add_submenu_page( 'academy-consultations', 'درخواست‌های مشاوره', 'درخواست‌ها', 'manage_options', 'academy-consultations', array( __CLASS__, 'page' ) );
        add_submenu_page( 'academy-consultations', 'تنظیمات مشاوره', 'تنظیمات', 'manage_options', 'academy-consultations-settings', array( __CLASS__, 'settings_page' ) );
    }

    public static function settings() {
        register_setting( 'academy_site_consultations', 'academy_site_sms_api_key', array( 'sanitize_callback' => 'sanitize_text_field' ) );
        register_setting( 'academy_site_consultations', 'academy_site_sms_line_number', array( 'sanitize_callback' => 'sanitize_text_field' ) );
        register_setting( 'academy_site_consultations', 'academy_site_consultation_confirmation_page_id', array( 'sanitize_callback' => 'absint' ) );
        register_setting( 'academy_site_consultations', 'academy_site_consultants', array( 'sanitize_callback' => array( __CLASS__, 'sanitize_consultants' ) ) );
    }

    public static function sanitize_consultants( $value ) {
        $out = array();
        foreach ( academy_site_consultation_types() as $key => $label ) {
            $out[ $key ] = array(
                'name' => sanitize_text_field( $value[ $key ]['name'] ?? '' ),
                'mobile' => academy_site_consultation_mobile( $value[ $key ]['mobile'] ?? '' ),
            );
        }
        return $out;
    }

    public static function settings_page() {
        $consultants = get_option( 'academy_site_consultants', array() ); ?>
        <div class="wrap" dir="rtl"><h1>تنظیمات بخش مشاوره</h1><form method="post" action="options.php">
        <?php settings_fields( 'academy_site_consultations' ); ?>
        <table class="form-table"><tr><th>SMS.ir API Key</th><td><input type="password" class="regular-text" name="academy_site_sms_api_key" value="<?php echo esc_attr( get_option( 'academy_site_sms_api_key', '' ) ); ?>"></td></tr>
        <tr><th>شماره خط SMS.ir</th><td><input class="regular-text" name="academy_site_sms_line_number" value="<?php echo esc_attr( get_option( 'academy_site_sms_line_number', '' ) ); ?>"></td></tr>
        <tr><th>برگه تأیید ثبت درخواست</th><td><?php wp_dropdown_pages( array( 'name' => 'academy_site_consultation_confirmation_page_id', 'selected' => absint( get_option( 'academy_site_consultation_confirmation_page_id' ) ), 'show_option_none' => '— انتخاب برگه —' ) ); ?><p class="description">در Elementor طراحی و شورت‌کد <code>[academy_consultation_confirmation]</code> را قرار دهید.</p></td></tr></table>
        <h2>مشاور پیش‌فرض هر نوع درخواست</h2><table class="widefat striped"><thead><tr><th>نوع مشاوره</th><th>نام مشاور</th><th>موبایل مشاور</th></tr></thead><tbody>
        <?php foreach ( academy_site_consultation_types() as $key => $label ) : $c = $consultants[ $key ] ?? array(); ?><tr><td><?php echo esc_html( $label ); ?></td><td><input name="academy_site_consultants[<?php echo esc_attr( $key ); ?>][name]" value="<?php echo esc_attr( $c['name'] ?? '' ); ?>"></td><td><input dir="ltr" name="academy_site_consultants[<?php echo esc_attr( $key ); ?>][mobile]" value="<?php echo esc_attr( $c['mobile'] ?? '' ); ?>"></td></tr><?php endforeach; ?></tbody></table>
        <?php submit_button( 'ذخیره تنظیمات' ); ?></form></div><?php
    }

    public static function page() {
        global $wpdb;
        $rows = $wpdb->get_results( 'SELECT * FROM ' . Academy_Site_Consultations::table() . ' ORDER BY id DESC LIMIT 200' );
        $types = academy_site_consultation_types(); $statuses = academy_site_consultation_statuses(); ?>
        <div class="wrap" dir="rtl"><h1>درخواست‌های مشاوره</h1><table class="widefat striped"><thead><tr><th>کد پیگیری</th><th>متقاضی</th><th>موبایل</th><th>نوع</th><th>مشاور</th><th>وضعیت</th><th>جلسه</th><th>تاریخ ثبت</th><th></th></tr></thead><tbody>
        <?php if ( ! $rows ) : ?><tr><td colspan="9">هنوز درخواستی ثبت نشده است.</td></tr><?php endif; ?>
        <?php foreach ( $rows as $r ) : ?><tr><td><strong><?php echo esc_html( $r->tracking_code ); ?></strong></td><td><?php echo esc_html( $r->first_name . ' ' . $r->last_name ); ?></td><td dir="ltr"><?php echo esc_html( $r->mobile ); ?></td><td><?php echo esc_html( $types[ $r->consultation_type ] ?? $r->consultation_type ); ?></td><td><?php echo esc_html( $r->consultant_name ?: 'تعیین نشده' ); ?></td><td><?php echo esc_html( $statuses[ $r->status ] ?? $r->status ); ?></td><td><?php echo $r->session_date ? esc_html( $r->session_date . ' ' . substr( (string) $r->session_time, 0, 5 ) ) : '—'; ?></td><td><?php echo esc_html( $r->created_at ); ?></td><td><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=academy-consultations&action=edit&id=' . absint( $r->id ) ) ); ?>">مدیریت</a></td></tr><?php endforeach; ?></tbody></table></div><?php
        if ( isset( $_GET['action'], $_GET['id'] ) && $_GET['action'] === 'edit' ) self::edit_page( absint( $_GET['id'] ) );
    }

    private static function edit_page( $id ) {
        $r = Academy_Site_Consultations::get( $id );
        if ( ! $r ) return;
        $types = academy_site_consultation_types(); $statuses = academy_site_consultation_statuses(); $modes = academy_site_consultation_session_modes(); ?>
        <div class="wrap" dir="rtl"><hr><h2>مدیریت درخواست <?php echo esc_html( $r->tracking_code ); ?></h2><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
        <input type="hidden" name="action" value="academy_consultation_update"><input type="hidden" name="id" value="<?php echo absint( $r->id ); ?>"><?php wp_nonce_field( 'academy_consultation_update_' . $r->id ); ?>
        <table class="form-table"><tr><th>متقاضی</th><td><?php echo esc_html( $r->first_name . ' ' . $r->last_name ); ?> — <span dir="ltr"><?php echo esc_html( $r->mobile ); ?></span></td></tr>
        <tr><th>نوع مشاوره</th><td><?php echo esc_html( $types[ $r->consultation_type ] ?? $r->consultation_type ); ?></td></tr>
        <tr><th>علت درخواست</th><td><div style="max-width:700px;white-space:pre-wrap;background:#fff;border:1px solid #ddd;padding:12px"><?php echo esc_html( $r->reason ); ?></div></td></tr>
        <tr><th>وضعیت</th><td><select name="status"><?php foreach ( $statuses as $key => $label ) : ?><option value="<?php echo esc_attr( $key ); ?>" <?php selected( $r->status, $key ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></td></tr>
        <tr><th>تاریخ جلسه</th><td><input type="date" name="session_date" value="<?php echo esc_attr( $r->session_date ); ?>"></td></tr>
        <tr><th>ساعت جلسه</th><td><input type="time" name="session_time" value="<?php echo esc_attr( $r->session_time ); ?>"></td></tr>
        <tr><th>نحوه برگزاری</th><td><select name="session_mode"><option value="">انتخاب کنید</option><?php foreach ( $modes as $key => $label ) : ?><option value="<?php echo esc_attr( $key ); ?>" <?php selected( $r->session_mode, $key ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></td></tr>
        <tr><th>لینک جلسه</th><td><input type="url" class="regular-text" dir="ltr" name="session_link" value="<?php echo esc_attr( $r->session_link ); ?>"></td></tr>
        <tr><th>یادداشت جلسه</th><td><textarea name="session_notes" rows="5" class="large-text"><?php echo esc_textarea( $r->session_notes ); ?></textarea></td></tr></table>
        <?php submit_button( 'ذخیره و بروزرسانی درخواست' ); ?></form></div><?php
    }

    public static function update_request() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
        $id = absint( $_POST['id'] ?? 0 ); check_admin_referer( 'academy_consultation_update_' . $id );
        $r = Academy_Site_Consultations::get( $id ); if ( ! $r ) wp_die( 'درخواست پیدا نشد.' );
        $status = sanitize_key( $_POST['status'] ?? 'new' ); $statuses = academy_site_consultation_statuses();
        if ( ! isset( $statuses[ $status ] ) ) $status = 'new';
        $date = sanitize_text_field( $_POST['session_date'] ?? '' ); $time = sanitize_text_field( $_POST['session_time'] ?? '' );
        $mode = sanitize_key( $_POST['session_mode'] ?? '' ); if ( ! isset( academy_site_consultation_session_modes()[ $mode ] ) ) $mode = '';
        $link = esc_url_raw( $_POST['session_link'] ?? '' ); $notes = sanitize_textarea_field( $_POST['session_notes'] ?? '' );
        global $wpdb; $wpdb->update( Academy_Site_Consultations::table(), array( 'status'=>$status, 'session_date'=>$date ?: null, 'session_time'=>$time ?: null, 'session_mode'=>$mode ?: null, 'session_link'=>$link ?: null, 'session_notes'=>$notes, 'updated_at'=>current_time('mysql') ), array('id'=>$id) );
        if ( $status === 'scheduled' && ( $date || $time ) && $r->status !== 'scheduled' ) {
            $mode_label = $mode ? academy_site_consultation_session_modes()[ $mode ] : 'مشخص نشده';
            $message = sprintf("آکادمی\nجلسه مشاوره شما تعیین شد.\nکد پیگیری: %s\nتاریخ: %s\nساعت: %s\nنحوه برگزاری: %s", $r->tracking_code, $date ?: '—', $time ?: '—', $mode_label);
            if ( $link ) $message .= "\nلینک جلسه: " . $link;
            $sent = Academy_Site_Consultations::send_sms( $r->mobile, $message );
            $wpdb->update( Academy_Site_Consultations::table(), array('client_sms_status'=>$sent ? 'sent':'failed','updated_at'=>current_time('mysql')), array('id'=>$id) );
        }
        wp_safe_redirect( admin_url( 'admin.php?page=academy-consultations&updated=1' ) ); exit;
    }
}
