<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function academy_site_consultation_types() {
    return array(
        'general_business' => 'مشاوره عمومی کسب و کار',
        'specialized_business' => 'مشاوره تخصصی کسب و کار',
        'money_investing' => 'مشاوره پولسازی و سرمایه‌گذاری',
    );
}

function academy_site_consultation_tracking_code() {
    return 'AC-' . wp_date( 'ymd' ) . '-' . strtoupper( wp_generate_password( 6, false, false ) );
}

function academy_site_consultation_mobile( $mobile ) {
    $mobile = preg_replace( '/[^0-9+]/', '', (string) $mobile );
    if ( strpos( $mobile, '+98' ) === 0 ) $mobile = '0' . substr( $mobile, 3 );
    if ( strpos( $mobile, '98' ) === 0 && strlen( $mobile ) === 12 ) $mobile = '0' . substr( $mobile, 2 );
    if ( strlen( $mobile ) === 10 && strpos( $mobile, '9' ) === 0 ) $mobile = '0' . $mobile;
    return $mobile;
}

function academy_site_consultation_confirmation_url( $token ) {
    $page_id = absint( get_option( 'academy_site_consultation_confirmation_page_id' ) );
    $url = $page_id ? get_permalink( $page_id ) : home_url( '/' );
    return add_query_arg( 'consultation_confirmation', rawurlencode( $token ), $url );
}


function academy_site_consultation_statuses() {
    return array(
        'new' => 'جدید',
        'reviewing' => 'در حال بررسی',
        'contacted' => 'تماس گرفته شد',
        'scheduled' => 'جلسه تعیین شد',
        'completed' => 'انجام شد',
        'cancelled' => 'لغو شد',
    );
}

function academy_site_consultation_session_modes() {
    return array(
        'phone' => 'تلفنی',
        'online' => 'آنلاین',
        'in_person' => 'حضوری',
    );
}

function academy_site_consultation_periods() { return array('morning'=>'صبح','afternoon'=>'عصر'); }
