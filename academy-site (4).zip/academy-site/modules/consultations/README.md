# Consultations Module

## Workflow
1. Applicant submits the Elementor shortcode form.
2. A unique tracking code is generated and stored.
3. Applicant is redirected to the confirmation page.
4. SMS is sent to the applicant and the configured consultant for the selected consultation type.
5. Admin manages request status and, when needed, schedules a consultation session.
6. When a request is moved to `scheduled` with a date/time, the applicant receives a session-confirmation SMS once.

## Statuses
- new: جدید
- reviewing: در حال بررسی
- contacted: تماس گرفته شد
- scheduled: جلسه تعیین شد
- completed: انجام شد
- cancelled: لغو شد

## Session fields
- date
- time
- mode: phone / online / in_person
- meeting link
- notes

## Elementor shortcodes
- `[academy_consultation_form]`
- `[academy_consultation_confirmation]`
