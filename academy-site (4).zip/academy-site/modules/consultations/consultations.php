<?php
if ( ! defined( 'ABSPATH' ) ) exit;
require_once __DIR__ . '/class-consultations.php';
require_once __DIR__ . '/ajax.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/admin/class-admin.php';

Academy_Site_Consultations::init();
Academy_Site_Consultations_Ajax::init();
Academy_Site_Consultations_Admin::init();
