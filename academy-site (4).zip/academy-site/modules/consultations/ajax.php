<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Academy_Site_Consultations_Ajax {
    public static function init() {
        add_action( 'wp_ajax_nopriv_academy_submit_consultation', array( __CLASS__, 'submit' ) );
        add_action( 'wp_ajax_academy_submit_consultation', array( __CLASS__, 'submit' ) );
    }

    public static function submit() {
        check_ajax_referer( 'academy_consultation_submit', 'nonce' );
        $first = sanitize_text_field( wp_unslash( $_POST['first_name'] ?? '' ) );
        $last = sanitize_text_field( wp_unslash( $_POST['last_name'] ?? '' ) );
        $mobile = academy_site_consultation_mobile( wp_unslash( $_POST['mobile'] ?? '' ) );
        $type = sanitize_key( wp_unslash( $_POST['consultation_type'] ?? '' ) );
        $reason = sanitize_textarea_field( wp_unslash( $_POST['reason'] ?? '' ) );
        $preferred_period = sanitize_key( wp_unslash( $_POST['preferred_period'] ?? '' ) );
        $types = academy_site_consultation_types();

        if ( ! $first || ! $last || ! $mobile || ! $type || ! $reason || ! in_array( $preferred_period, array( 'morning', 'afternoon' ), true ) ) wp_send_json_error( array( 'message' => 'لطفاً همه فیلدهای الزامی را تکمیل کنید.' ), 422 );
        if ( ! preg_match( '/^09\d{9}$/', $mobile ) ) wp_send_json_error( array( 'message' => 'شماره موبایل واردشده معتبر نیست.' ), 422 );
        if ( ! isset( $types[ $type ] ) ) wp_send_json_error( array( 'message' => 'نوع مشاوره انتخاب‌شده معتبر نیست.' ), 422 );

        global $wpdb;
        $tracking = academy_site_consultation_tracking_code();
        $token = wp_generate_password( 48, false, false );
        $now = current_time( 'mysql' );
        $consultant = get_option( 'academy_site_consultants', array() );
        $consultant = is_array( $consultant ) && isset( $consultant[ $type ] ) ? $consultant[ $type ] : array();
        $consultant_name = sanitize_text_field( $consultant['name'] ?? '' );
        $consultant_mobile = academy_site_consultation_mobile( $consultant['mobile'] ?? '' );

        $ok = $wpdb->insert( Academy_Site_Consultations::table(), array(
            'tracking_code' => $tracking,
            'confirmation_token_hash' => hash( 'sha256', $token ),
            'first_name' => $first,
            'last_name' => $last,
            'mobile' => $mobile,
            'consultation_type' => $type,
            'preferred_period' => $preferred_period,
            'reason' => $reason,
            'status' => 'new',
            'consultant_name' => $consultant_name,
            'consultant_mobile' => $consultant_mobile,
            'created_at' => $now,
            'updated_at' => $now,
        ) );
        if ( ! $ok ) wp_send_json_error( array( 'message' => 'ثبت درخواست انجام نشد. لطفاً دوباره تلاش کنید.' ), 500 );

        $id = (int) $wpdb->insert_id;
        $client_sms = Academy_Site_Consultations::send_sms( $mobile, '', 'consultation', array( 'FirstName' => $first, 'LastName' => $last, 'ConsultationType' => $types[ $type ], 'TrackingCode' => $tracking ) );
        $consultant_sms = false;
        if ( $consultant_mobile && preg_match( '/^09\d{9}$/', $consultant_mobile ) ) {
            $consultant_sms = Academy_Site_Consultations::send_sms( $consultant_mobile, '', 'consultation_admin', array( 'FirstName' => $first, 'LastName' => $last, 'ConsultationType' => $types[ $type ], 'TrackingCode' => $tracking ) );
        }
        $wpdb->update( Academy_Site_Consultations::table(), array(
            'client_sms_status' => $client_sms ? 'sent' : 'failed',
            'consultant_sms_status' => $consultant_mobile ? ( $consultant_sms ? 'sent' : 'failed' ) : 'not_configured',
            'updated_at' => current_time( 'mysql' ),
        ), array( 'id' => $id ) );

        wp_send_json_success( array( 'redirect' => academy_site_consultation_confirmation_url( $token ) ) );
    }
}

if ( ! method_exists( 'Academy_Site_Consultations', 'send_sms' ) ) {
    add_filter( 'academy_site_consultation_sms_send', '__return_false' );
}
