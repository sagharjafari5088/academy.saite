<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Academy Site — My Courses / Learning Access API.
 * UI-agnostic: exposes secured server-side data for Elementor and future clients.
 */
final class Academy_Site_My_Courses {
	public static function boot() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_filter( 'academy_site_dynamic_data', array( __CLASS__, 'dynamic_data' ), 40, 2 );
	}
	public static function register_routes() {
		register_rest_route( 'academy-site/v1', '/me/courses', array(
			'methods' => WP_REST_Server::READABLE,
			'callback' => array( __CLASS__, 'rest_courses' ),
			'permission_callback' => array( __CLASS__, 'rest_permission' ),
		) );
		register_rest_route( 'academy-site/v1', '/me/courses/(?P<course_id>\d+)', array(
			'methods' => WP_REST_Server::READABLE,
			'callback' => array( __CLASS__, 'rest_course' ),
			'permission_callback' => array( __CLASS__, 'rest_permission' ),
			'args' => array('course_id'=>array('sanitize_callback'=>'absint')),
		) );
	}
	public static function rest_permission() {
		return is_user_logged_in() ? true : new WP_Error('rest_not_logged_in','ورود الزامی است.',array('status'=>401));
	}
	/** Backward-compatible API used by the central Dynamic layer. */
	public static function get_my_courses( $user_id ) {
		return self::user_courses( $user_id );
	}
	public static function user_courses( $user_id ) {
		if ( ! class_exists('Academy_Site_Enrollment') ) return array();
		$rows = Academy_Site_Enrollment::get_user_enrollments( absint($user_id), 'active' );
		$out = array();
		foreach ( $rows as $row ) {
			$course_id = absint($row->course_id ?? 0);
			if ( ! $course_id || 'academy_course' !== get_post_type($course_id) ) continue;
			$out[] = self::course_payload($user_id,$course_id,$row);
		}
		return $out;
	}
	public static function course_payload( $user_id, $course_id, $enrollment=null ) {
		$progress = class_exists('Academy_Site_Progress') ? Academy_Site_Progress::calculate($user_id,$course_id) : 0;
		$last = class_exists('Academy_Site_Progress') ? Academy_Site_Progress::get_last_viewed($user_id,$course_id) : null;
		$next = class_exists('Academy_Site_Progress') ? Academy_Site_Progress::get_next_lesson($user_id,$course_id) : null;
		return array(
			'id'=>$course_id,
			'title'=>get_the_title($course_id),
			'url'=>get_permalink($course_id),
			'thumbnail'=>get_the_post_thumbnail_url($course_id,'large') ?: '',
			'progress'=>(int)$progress,
			'completed'=>100 === (int)$progress,
			'last_lesson_id'=>$last ? absint($last->lesson_id) : 0,
			'last_position_seconds'=>$last ? absint($last->position_seconds) : 0,
			'next_lesson'=>$next ? array(
				'id'=>absint(is_object($next) ? ($next->id ?? 0) : ($next['id'] ?? 0)),
				'title'=>sanitize_text_field(is_object($next) ? ($next->lesson_title ?? $next->title ?? '') : ($next['title'] ?? '')),
				'url'=>esc_url_raw(is_object($next) ? '' : ($next['url'] ?? '')),
			) : null,
			'enrollment'=>$enrollment ? array(
				'status'=>sanitize_key($enrollment->status ?? ''),
				'starts_at'=>sanitize_text_field($enrollment->starts_at ?? ''),
				'expires_at'=>sanitize_text_field($enrollment->expires_at ?? ''),
			) : null,
		);
	}
	public static function rest_courses() {
		return rest_ensure_response(array('courses'=>self::user_courses(get_current_user_id())));
	}
	public static function rest_course( WP_REST_Request $request ) {
		$user_id=get_current_user_id(); $course_id=absint($request['course_id']);
		if ( ! class_exists('Academy_Site_Enrollment') || ! Academy_Site_Enrollment::has_access($user_id,$course_id) )
			return new WP_Error('academy_access_denied','دسترسی به این دوره ندارید.',array('status'=>403));
		$rows=Academy_Site_Enrollment::get_user_enrollments($user_id,'active');
		$enrollment=null; foreach($rows as $row){if(absint($row->course_id)===$course_id){$enrollment=$row;break;}}
		return rest_ensure_response(self::course_payload($user_id,$course_id,$enrollment));
	}
	public static function dynamic_data($data,$context) {
		if ( ! is_user_logged_in() ) return $data;
		$courses=self::user_courses(get_current_user_id());
		$data['my_courses']=$courses;
		$data['my_courses_count']=count($courses);
		return $data;
	}
}
Academy_Site_My_Courses::boot();
