<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Academy_Site_Article_Renderer {
    public static function boot() {
        add_filter( 'academy_site_render_map', array( __CLASS__, 'map' ), 20, 3 );
    }
    public static function map( $map, $type, $data ) {
        if ( 'article' !== $type ) return $map;
        $d = is_array( $data ) ? $data : (array) $data;
        $id = absint( $d['id'] ?? 0 );
        $url = $id ? get_permalink( $id ) : '#';
        $m = array();
        $m = array(
                'article_id'        => (string) $id,
                'article_title'     => esc_html( $d['title'] ?? '' ),
                'article_category'  => esc_html( $d['category'] ?? '' ),
                'article_excerpt'   => wp_kses_post( $d['excerpt'] ?? '' ),
                'article_content'   => wp_kses_post( $d['content'] ?? '' ),
                'article_image'     => $d['image_html'] ?? '',
                'article_image_url' => esc_url( $d['image_url'] ?? '' ),
                'article_date'      => esc_html( get_the_date( '', $id ) ),
                'article_url'       => esc_url( $url ),
                'article_action'    => '<a class="academy-article-action" href="' . esc_url( $url ) . '">مطالعه مقاله</a>',
                 'article_qr_url'    => class_exists( 'Academy_Site_QR' ) ? esc_url( Academy_Site_QR::image_url( $url, 220 ) ) : '',
                 'article_qr'        => class_exists( 'Academy_Site_QR' ) ? Academy_Site_QR::image_html( $url, 'academy-article-qr', 'QR مقاله', 220 ) : '',
            );
        return $m;
    }
}
Academy_Site_Article_Renderer::boot();
