<?php
if(!defined('ABSPATH'))exit;
final class Academy_Site_Articles{
 const POST_TYPE='academy_article';
 public static function boot(){add_action('init',array(__CLASS__,'cpt'));add_action('add_meta_boxes',array(__CLASS__,'boxes'));add_action('save_post_'.self::POST_TYPE,array(__CLASS__,'save'),10,2);}
 public static function cpt(){register_post_type(self::POST_TYPE,array('labels'=>array('name'=>'مقالات','singular_name'=>'مقاله','add_new_item'=>'افزودن مقاله','edit_item'=>'ویرایش مقاله'),'public'=>true,'show_in_rest'=>true,'menu_icon'=>'dashicons-media-document','supports'=>array('title','editor','excerpt','thumbnail'),'has_archive'=>true,'rewrite'=>array('slug'=>'articles')));}
 public static function boxes(){}
public static function save($id,$post){}
public static function get($id){$p=get_post(absint($id));if(!$p||$p->post_type!==self::POST_TYPE)return null;$img=get_post_thumbnail_id($id);return array('id'=>(int)$id,'title'=>get_the_title($p),'content'=>$p->post_content,'excerpt'=>get_the_excerpt($p),'image_id'=>$img,'image_url'=>$img?wp_get_attachment_image_url($img,'full'):'','image_html'=>$img?wp_get_attachment_image($img,'full',false,array('class'=>'academy-article-image')):'');}

 public static function all(){$ps=get_posts(array('post_type'=>self::POST_TYPE,'post_status'=>'publish','posts_per_page'=>-1,'orderby'=>'date','order'=>'DESC'));$o=array();foreach($ps as $p){$d=self::get($p->ID);if($d)$o[]=$d;}return $o;}
}
Academy_Site_Articles::boot();
