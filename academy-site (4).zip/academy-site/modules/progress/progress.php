<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Academy_Site_Progress {
    const TABLE = 'academy_course_progress';

    public static function boot() {
        add_action( 'wp_ajax_academy_mark_lesson_viewed', array( __CLASS__, 'ajax_mark_lesson_viewed' ) );
        add_action( 'wp_ajax_academy_save_lesson_position', array( __CLASS__, 'ajax_save_lesson_position' ) );
        add_action( 'wp_ajax_academy_complete_lesson', array( __CLASS__, 'ajax_complete_lesson' ) );
        add_filter( 'academy_site_dynamic_data', array( __CLASS__, 'dynamic_data' ), 30, 2 );
        add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
    }

    public static function table_name() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE;
    }

    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $sql = "CREATE TABLE " . self::table_name() . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            course_id BIGINT UNSIGNED NOT NULL,
            lesson_id BIGINT UNSIGNED NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'started',
            position_seconds INT UNSIGNED NOT NULL DEFAULT 0,
            completed_at DATETIME NULL,
            last_viewed_at DATETIME NOT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY user_course_lesson (user_id, course_id, lesson_id),
            KEY user_course (user_id, course_id),
            KEY course_lesson (course_id, lesson_id),
            KEY user_last_viewed (user_id, last_viewed_at),
            KEY status (status)
        ) " . $wpdb->get_charset_collate() . ";";
        dbDelta( $sql );
    }

    public static function get( $user_id, $course_id, $lesson_id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            'SELECT * FROM ' . self::table_name() . ' WHERE user_id = %d AND course_id = %d AND lesson_id = %d LIMIT 1',
            absint( $user_id ), absint( $course_id ), absint( $lesson_id )
        ) );
    }

    public static function get_last_viewed( $user_id, $course_id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            'SELECT * FROM ' . self::table_name() . ' WHERE user_id = %d AND course_id = %d ORDER BY last_viewed_at DESC LIMIT 1',
            absint( $user_id ), absint( $course_id )
        ) );
    }

    public static function lessons( $course_id ) {
        if ( ! class_exists( 'Academy_Site_Courses' ) ) { return array(); }
        return Academy_Site_Courses::get_lessons( absint( $course_id ), 'published' );
    }

    private static function lesson_exists( $course_id, $lesson_id ) {
        foreach ( self::lessons( $course_id ) as $lesson ) {
            if ( absint( $lesson->id ?? 0 ) === absint( $lesson_id ) ) { return true; }
        }
        return false;
    }

    private static function can_access( $user_id, $course_id, $lesson_id ) {
        return class_exists( 'Academy_Site_Enrollment' )
            && Academy_Site_Enrollment::has_access( absint( $user_id ), absint( $course_id ) )
            && self::lesson_exists( $course_id, $lesson_id );
    }

    public static function mark_viewed( $user_id, $course_id, $lesson_id, $position = 0 ) {
        global $wpdb;
        $user_id = absint( $user_id ); $course_id = absint( $course_id ); $lesson_id = absint( $lesson_id ); $position = absint( $position );
        if ( ! self::can_access( $user_id, $course_id, $lesson_id ) ) {
            return new WP_Error( 'lesson_access_denied', 'دسترسی به این Lesson مجاز نیست.' );
        }
        $now = current_time( 'mysql', true );
        $existing = self::get( $user_id, $course_id, $lesson_id );
        if ( $existing ) {
            $ok = $wpdb->update( self::table_name(), array(
                'status' => 'started', 'position_seconds' => $position, 'last_viewed_at' => $now, 'updated_at' => $now,
            ), array( 'id' => (int) $existing->id ), array( '%s','%d','%s','%s' ), array( '%d' ) );
            return false === $ok ? new WP_Error( 'db_error', 'ذخیره پیشرفت ناموفق بود.' ) : (int) $existing->id;
        }
        $ok = $wpdb->insert( self::table_name(), array(
            'user_id' => $user_id, 'course_id' => $course_id, 'lesson_id' => $lesson_id, 'status' => 'started',
            'position_seconds' => $position, 'completed_at' => null, 'last_viewed_at' => $now, 'created_at' => $now, 'updated_at' => $now,
        ), array( '%d','%d','%d','%s','%d','%s','%s','%s','%s' ) );
        return false === $ok ? new WP_Error( 'db_error', 'ذخیره پیشرفت ناموفق بود.' ) : (int) $wpdb->insert_id;
    }

    public static function complete_lesson( $user_id, $course_id, $lesson_id ) {
        global $wpdb;
        $user_id = absint( $user_id ); $course_id = absint( $course_id ); $lesson_id = absint( $lesson_id );
        if ( ! self::can_access( $user_id, $course_id, $lesson_id ) ) {
            return new WP_Error( 'lesson_access_denied', 'دسترسی به این Lesson مجاز نیست.' );
        }
        $existing = self::get( $user_id, $course_id, $lesson_id );
        if ( ! $existing ) {
            $created = self::mark_viewed( $user_id, $course_id, $lesson_id, 0 );
            if ( is_wp_error( $created ) ) { return $created; }
            $existing = self::get( $user_id, $course_id, $lesson_id );
        }
        $now = current_time( 'mysql', true );
        $ok = $wpdb->update( self::table_name(), array(
            'status' => 'completed', 'completed_at' => $now, 'last_viewed_at' => $now, 'updated_at' => $now,
        ), array( 'id' => (int) $existing->id ), array( '%s','%s','%s','%s' ), array( '%d' ) );
        if ( false === $ok ) { return new WP_Error( 'db_error', 'تکمیل Lesson ثبت نشد.' ); }
        $progress = self::calculate( $user_id, $course_id );
        do_action( 'academy_site_lesson_completed', $user_id, $course_id, $lesson_id );
        if ( 100 === $progress ) { do_action( 'academy_site_course_completed', $user_id, $course_id ); }
        return true;
    }

    public static function calculate( $user_id, $course_id ) {
        $lessons = self::lessons( $course_id );
        if ( empty( $lessons ) ) { return 0; }
        global $wpdb;
        $ids = array_map( function( $lesson ) { return absint( $lesson->id ); }, $lessons );
        $ids = array_values( array_filter( array_unique( $ids ) ) );
        if ( empty( $ids ) ) { return 0; }
        $placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
        $args = array_merge( array( absint( $user_id ), absint( $course_id ) ), $ids );
        $completed = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(DISTINCT lesson_id) FROM " . self::table_name() . " WHERE user_id = %d AND course_id = %d AND status = 'completed' AND lesson_id IN ($placeholders)",
            $args
        ) );
        return min( 100, (int) round( ( $completed / count( $ids ) ) * 100 ) );
    }

    /** Backward-compatible API used by My Courses. */
    public static function get_next_lesson( $user_id, $course_id ) {
        return self::next_lesson( $user_id, $course_id );
    }

    public static function next_lesson( $user_id, $course_id ) {
        foreach ( self::lessons( $course_id ) as $lesson ) {
            $row = self::get( $user_id, $course_id, $lesson->id );
            if ( ! $row || 'completed' !== $row->status ) { return $lesson; }
        }
        return null;
    }

    public static function dynamic_data( $data, $context ) {
        if ( ! is_user_logged_in() || ! is_singular( 'academy_course' ) ) { return $data; }
        $user_id = get_current_user_id(); $course_id = get_the_ID();
        $data['course_progress'] = array(
            'course_id' => $course_id,
            'percentage' => self::calculate( $user_id, $course_id ),
            'last_viewed' => self::get_last_viewed( $user_id, $course_id ),
            'next_lesson' => self::next_lesson( $user_id, $course_id ),
        );
        return $data;
    }

    private static function verify_request() {
        if ( ! is_user_logged_in() ) { wp_send_json_error( array( 'message' => 'ورود الزامی است.' ), 401 ); }
        $nonce = sanitize_text_field( wp_unslash( $_POST['nonce'] ?? '' ) );
        if ( ! wp_verify_nonce( $nonce, 'academy_progress' ) ) { wp_send_json_error( array( 'message' => 'درخواست نامعتبر است.' ), 403 ); }
    }

    public static function ajax_mark_lesson_viewed() {
        self::verify_request();
        $result = self::mark_viewed( get_current_user_id(), absint( $_POST['course_id'] ?? 0 ), absint( $_POST['lesson_id'] ?? 0 ), absint( $_POST['position'] ?? 0 ) );
        if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message() ), 403 ); }
        $course_id = absint( $_POST['course_id'] ?? 0 );
        wp_send_json_success( array( 'progress' => self::calculate( get_current_user_id(), $course_id ) ) );
    }

    public static function ajax_save_lesson_position() {
        self::verify_request();
        $result = self::mark_viewed( get_current_user_id(), absint( $_POST['course_id'] ?? 0 ), absint( $_POST['lesson_id'] ?? 0 ), absint( $_POST['position'] ?? 0 ) );
        if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message() ), 403 ); }
        wp_send_json_success();
    }

    public static function ajax_complete_lesson() {
        self::verify_request();
        $course_id = absint( $_POST['course_id'] ?? 0 ); $lesson_id = absint( $_POST['lesson_id'] ?? 0 );
        $result = self::complete_lesson( get_current_user_id(), $course_id, $lesson_id );
        if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message() ), 403 ); }
        wp_send_json_success( array( 'progress' => self::calculate( get_current_user_id(), $course_id ) ) );
    }

    public static function admin_menu() {
        add_submenu_page( 'edit.php?post_type=academy_course', 'پیشرفت دوره', 'پیشرفت دوره', 'manage_options', 'academy-course-progress', array( __CLASS__, 'admin_page' ) );
    }

    public static function admin_page() {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'دسترسی غیرمجاز.' ); }
        echo '<div class="wrap"><h1>پیشرفت دوره</h1><p>Progress آموزشی مستقل از UI و Elementor ذخیره می‌شود.</p></div>';
    }
}

Academy_Site_Progress::boot();
