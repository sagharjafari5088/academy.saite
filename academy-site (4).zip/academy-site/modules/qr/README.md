# Academy Site QR Module

Provides QR image URL/HTML generation for public verification and public entity URLs.
The QR payload should be a public URL or an opaque verification URL; do not put
private student data directly into the payload.

Current public markers are documented in `docs/ELEMENTOR-HTML-MASTER.md`.
