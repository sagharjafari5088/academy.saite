<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Academy Site — QR Generator.
 *
 * QR images are generated from an opaque/public URL through the configured
 * image endpoint. No personal data is placed in the QR payload by this module.
 */
final class Academy_Site_QR {

    const DEFAULT_ENDPOINT = 'https://api.qrserver.com/v1/create-qr-code/';

    public static function boot() {
        add_filter( 'academy_site_qr_endpoint', array( __CLASS__, 'endpoint' ) );
    }

    public static function install() {
        // Reserved for future local QR storage/migration. No DB table is required.
    }

    public static function endpoint( $endpoint ) {
        $saved = get_option( 'academy_site_qr_endpoint', '' );
        return $saved ? esc_url_raw( $saved ) : self::DEFAULT_ENDPOINT;
    }

    public static function image_url( $payload, $size = 220 ) {
        $payload = trim( (string) $payload );
        if ( '' === $payload ) {
            return '';
        }

        $size = max( 100, min( 1000, absint( $size ) ) );
        $endpoint = apply_filters( 'academy_site_qr_endpoint', self::DEFAULT_ENDPOINT );

        return add_query_arg(
            array(
                'size' => $size . 'x' . $size,
                'data' => $payload,
            ),
            $endpoint
        );
    }

    public static function image_html( $payload, $class = 'academy-qr-code', $alt = 'QR Code', $size = 220 ) {
        $url = self::image_url( $payload, $size );
        if ( '' === $url ) {
            return '';
        }

        return '<img class="' . esc_attr( $class ) . '" src="' . esc_url( $url ) . '" alt="' . esc_attr( $alt ) . '" width="' . absint( $size ) . '" height="' . absint( $size ) . '" loading="lazy" decoding="async">';
    }

    public static function student_card_url( $token ) {
        $token = sanitize_text_field( $token );
        if ( '' === $token ) {
            return '';
        }

        return rest_url( 'academy-site/v1/card/verify/' . rawurlencode( $token ) );
    }

    /**
     * Public verification URL for a certificate.
     *
     * The verification page is configured by the Academy admin. The
     * certificate code is appended as ?certificate=CODE so the same
     * Elementor HTML renderer can render the selected certificate.
     * REST remains the final fallback for installations that have not
     * configured a page yet.
     */
    public static function certificate_url( $code ) {
        $code = sanitize_text_field( $code );
        if ( '' === $code ) {
            return '';
        }

        $page_url = esc_url_raw(
            get_option( 'academy_site_certificate_detail_url', '' )
        );

        if ( ! $page_url ) {
            $page_url = esc_url_raw(
                get_option( 'academy_site_certificate_verify_url', '' )
            );
        }

        if ( ! $page_url ) {
            $page_url = esc_url_raw(
                get_option( 'academy_certificate_verification_page_url', '' )
            );
        }

        if ( $page_url ) {
            return add_query_arg(
                'certificate',
                rawurlencode( $code ),
                $page_url
            );
        }

        return rest_url(
            'academy-site/v1/certificates/verify/' .
            rawurlencode( $code )
        );
    }

    public static function public_url( $url ) {
        return esc_url_raw( $url );
    }
}

Academy_Site_QR::boot();
