(function () {
  'use strict';

  // This file is intended to run in the browser as a WordPress frontend asset.
  // If someone double-clicks the .js file on Windows, Windows Script Host has
  // no `document` object; exit quietly instead of throwing an error.
  if (typeof document === 'undefined') return;

  var AUTOPLAY_DELAY = 4000;
  var RESUME_DELAY = 1000;

  function init(root) {
    if (!root || root.dataset.academyInstructorCarouselReady === '1') return;
    root.dataset.academyInstructorCarouselReady = '1';

    var track = root.querySelector('[data-academy-instructor-track]');
    if (!track) return;

    var prev = root.querySelector('[data-academy-instructor-prev]');
    var next = root.querySelector('[data-academy-instructor-next]');
    var timer = null;
    var resumeTimer = null;
    var step = function () {
      var first = track.querySelector('[data-academy-instructor-slide]');
      if (!first) return track.clientWidth || 1;
      var gap = parseFloat(getComputedStyle(track).gap || 0);
      return Math.max(first.getBoundingClientRect().width + (isNaN(gap) ? 0 : gap), 1);
    };

    function move(direction) {
      var amount = step() * direction;
      track.scrollBy({ left: amount, behavior: 'smooth' });
    }

    if (prev) prev.addEventListener('click', function (e) {
      e.preventDefault();
      pause(true);
      move(-1);
    });

    if (next) next.addEventListener('click', function (e) {
      e.preventDefault();
      pause(true);
      move(1);
    });

    // Autoplay is intentionally isolated to the instructor module.
    // It does not change card dimensions, layout, responsive settings, or Elementor styles.
    function advance() {
      var slides = track.querySelectorAll('[data-academy-instructor-slide]');
      if (!slides.length || track.scrollWidth <= track.clientWidth + 2) return;

      var first = slides[0];
      var before = first.getBoundingClientRect().left;
      move(1);

      // If the next movement reaches the end, return to the beginning.
      // The geometry check works without depending on browser-specific RTL scrollLeft values.
      window.setTimeout(function () {
        var after = first.getBoundingClientRect().left;
        var atEnd = Math.abs(after - before) < 1;
        if (atEnd) {
          track.scrollTo({ left: 0, behavior: 'smooth' });
        } else {
          var last = slides[slides.length - 1];
          var trackRect = track.getBoundingClientRect();
          var lastRect = last.getBoundingClientRect();
          if (lastRect.right <= trackRect.right + 2) {
            track.scrollTo({ left: 0, behavior: 'smooth' });
          }
        }
      }, 550);
    }

    function start() {
      if (timer || document.hidden) return;
      timer = window.setInterval(advance, AUTOPLAY_DELAY);
    }

    function stop() {
      if (timer) {
        window.clearInterval(timer);
        timer = null;
      }
    }

    function pause(resume) {
      stop();
      if (resume) {
        if (resumeTimer) window.clearTimeout(resumeTimer);
        resumeTimer = window.setTimeout(start, RESUME_DELAY);
      }
    }

    // Pause while the user is interacting with the carousel, then resume automatically.
    root.addEventListener('mouseenter', stop);
    root.addEventListener('mouseleave', start);
    root.addEventListener('focusin', stop);
    root.addEventListener('focusout', function () {
      if (!root.matches(':hover')) start();
    });

    document.addEventListener('visibilitychange', function () {
      if (document.hidden) stop();
      else start();
    });

    start();
  }

  function boot() {
    document.querySelectorAll('[data-academy-instructor-carousel]').forEach(init);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
