<?php
if ( ! defined( 'ABSPATH' ) ) exit;

final class Academy_Site_Instructors {
    const POST_TYPE = 'academy_instructor';
    const META_TITLE = '_academy_instructor_subtitle';
    const META_QR = '_academy_instructor_qr_token';
    const META_ORDER = '_academy_instructor_display_order';

    public static function boot() {
        add_action( 'init', array( __CLASS__, 'register_cpt' ) );
        add_action( 'add_meta_boxes', array( __CLASS__, 'register_meta_box' ) );
        add_action( 'save_post_' . self::POST_TYPE, array( __CLASS__, 'save_post' ), 10, 3 );
        add_filter( 'academy_site_dynamic_data', array( __CLASS__, 'dynamic_data' ), 20, 2 );
        add_action( 'rest_api_init', array( __CLASS__, 'rest' ) );
        add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ), 30 );
        add_action( 'wp_ajax_academy_instructors_save_order', array( __CLASS__, 'ajax_save_order' ) );
    }

    public static function install() { self::register_cpt(); }

    public static function register_cpt() {
        register_post_type( self::POST_TYPE, array(
            'labels' => array(
                'name' => 'مدرسین', 'singular_name' => 'مدرس',
                'add_new' => 'افزودن مدرس', 'add_new_item' => 'افزودن مدرس',
                'edit_item' => 'ویرایش مدرس', 'search_items' => 'جستجوی مدرسین',
            ),
            'public' => true,
            'show_ui' => false,
            'show_in_rest' => true,
            'supports' => array( 'title', 'editor', 'thumbnail' ),
            'has_archive' => true,
            'rewrite' => array( 'slug' => 'instructors', 'with_front' => false ),
            'menu_icon' => 'dashicons-businessperson',
        ) );
    }

    public static function register_meta_box() {
        add_meta_box( 'academy-instructor-data', 'اطلاعات مدرس', array( __CLASS__, 'meta_box' ), self::POST_TYPE, 'normal', 'high' );
    }

    public static function meta_box( $post ) {
        wp_nonce_field( 'academy_instructor_save', 'academy_instructor_nonce' );
        $subtitle = get_post_meta( $post->ID, self::META_TITLE, true );
        echo '<p><label>زیرعنوان نام</label><br><input class="widefat" name="academy_instructor_subtitle" value="' . esc_attr( $subtitle ) . '"></p>';
        echo '<p class="description">نام مدرس از عنوان نوشته، توضیح از متن نوشته و عکس از تصویر شاخص گرفته می‌شود.</p>';
    }

    public static function save_post( $post_id, $post, $update ) {
        if ( ! isset( $_POST['academy_instructor_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['academy_instructor_nonce'] ) ), 'academy_instructor_save' ) ) return;
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) return;
        if ( isset( $_POST['academy_instructor_subtitle'] ) ) update_post_meta( $post_id, self::META_TITLE, sanitize_text_field( wp_unslash( $_POST['academy_instructor_subtitle'] ) ) );
        self::ensure_qr_token( $post_id );
    }

    public static function ensure_qr_token( $id ) {
        $token = get_post_meta( $id, self::META_QR, true );
        if ( ! $token ) {
            $token = wp_generate_password( 32, false, false );
            update_post_meta( $id, self::META_QR, $token );
        }
        return $token;
    }

    public static function get_instructor( $id ) {
        $id = absint( $id ); $post = get_post( $id );
        if ( ! $post || self::POST_TYPE !== $post->post_type ) return null;
        $token = self::ensure_qr_token( $id );
        $url = self::profile_url( $id );
        return array(
            'id' => $id,
            'name' => get_the_title( $id ),
            'subtitle' => get_post_meta( $id, self::META_TITLE, true ),
            'title' => get_post_meta( $id, self::META_TITLE, true ),
            'description' => $post->post_content,
            'image_url' => get_the_post_thumbnail_url( $id, 'full' ) ?: '',
            'url' => $url ?: '',
            'qr_url' => class_exists( 'Academy_Site_QR' ) ? Academy_Site_QR::image_url( self::profile_qr_url( $token ), 220 ) : '',
        );
    }

    public static function get_all() {
        // Return every published instructor. Instructors with a saved manual
        // order come first; instructors without an order are appended by date.
        // Do not use META_ORDER as WP_Query's meta_key here. That turns the
        // query into a meta-query and can exclude legacy instructors that do
        // not have an order yet. Fetch all published instructors once, then
        // sort the small result set in PHP.
        $posts = get_posts( array(
            'post_type'      => self::POST_TYPE,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'date',
            'order'          => 'ASC',
            'no_found_rows'  => true,
        ) );

        // WordPress' meta_value ordering can place missing meta values first.
        // Sort in PHP so a manual order is always respected and un-ordered
        // instructors remain visible at the end.
        usort( $posts, function( $a, $b ) {
            $ao = get_post_meta( $a->ID, self::META_ORDER, true );
            $bo = get_post_meta( $b->ID, self::META_ORDER, true );
            $ao = ( '' === $ao ) ? PHP_INT_MAX : (int) $ao;
            $bo = ( '' === $bo ) ? PHP_INT_MAX : (int) $bo;

            if ( $ao === $bo ) {
                return (int) $a->ID <=> (int) $b->ID;
            }
            return $ao <=> $bo;
        } );

        $out = array();
        foreach ( $posts as $post ) {
            $item = self::get_instructor( $post->ID );
            if ( $item ) $out[] = $item;
        }
        return $out;
    }

    /**
     * Elementor single-instructor page URL.
     *
     * One Elementor page is used for all instructors. The instructor ID is
     * passed in the query string and instructor-renderer.php resolves it.
     */
    public static function profile_url( $id ) {
        $id = absint( $id );
        if ( ! $id ) return '';

        static $page = null;
        static $page_loaded = false;
        if ( ! $page_loaded ) {
            $page_loaded = true;
            $page = get_page_by_path( 'instructor' );
            if ( ! $page ) {
                $page = get_page_by_path( 'instructors' );
            }
        }

        if ( $page && 'publish' === get_post_status( $page->ID ) ) {
            return add_query_arg( 'instructor', $id, get_permalink( $page->ID ) );
        }

        // Safe fallback to the instructor CPT URL if the Elementor page
        // has not been created yet.
        return (string) ( get_permalink( $id ) ?: '' );
    }

    public static function profile_qr_url( $token ) {
        $token = sanitize_text_field( $token );
        if ( ! $token ) return '';
        static $page = null;
        static $page_loaded = false;
        if ( ! $page_loaded ) {
            $page_loaded = true;
            $page = get_page_by_path( 'instructor' );
            if ( ! $page ) {
                $page = get_page_by_path( 'instructors' );
            }
        }

        $base = ( $page && 'publish' === get_post_status( $page->ID ) )
            ? get_permalink( $page->ID )
            : home_url( '/' );

        return add_query_arg( 'instructor', $token, $base );
    }

    public static function find_by_token( $token ) {
        $token = sanitize_text_field( $token );
        if ( ! $token ) return null;
        $ids = get_posts( array( 'post_type' => self::POST_TYPE, 'post_status' => 'publish', 'numberposts' => 1, 'fields' => 'ids', 'meta_key' => self::META_QR, 'meta_value' => $token ) );
        return $ids ? self::get_instructor( $ids[0] ) : null;
    }


    public static function admin_menu() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        add_submenu_page(
            'academy-site',
            'ترتیب نمایش مدرسین',
            'ترتیب نمایش مدرسین',
            'manage_options',
            'academy-instructors-order',
            array( __CLASS__, 'admin_order_page' )
        );
    }

    public static function admin_order_page() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'دسترسی غیرمجاز.' );
        $posts = get_posts( array(
            'post_type' => self::POST_TYPE,
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'meta_key' => self::META_ORDER,
            'orderby' => array( 'meta_value_num' => 'ASC', 'date' => 'ASC' ),
            'order' => 'ASC',
        ) );
        wp_enqueue_script( 'jquery-ui-sortable' );
        $nonce = wp_create_nonce( 'academy_instructors_order' );
        echo '<div class="wrap"><h1>ترتیب نمایش مدرسین</h1>';
        echo '<p>مدرس‌ها را با کشیدن و رها کردن مرتب کن. این ترتیب در کاروسل صفحه اصلی اعمال می‌شود.</p>';
        echo '<ul id="academy-instructors-order-list" style="max-width:760px;margin-top:20px;">';
        foreach ( $posts as $index => $post ) {
            $image = get_the_post_thumbnail_url( $post->ID, 'thumbnail' );
            echo '<li data-id="' . absint( $post->ID ) . '" style="display:flex;align-items:center;gap:12px;background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:10px 14px;margin:8px 0;cursor:move;">';
            if ( $image ) echo '<img src="' . esc_url( $image ) . '" style="width:50px;height:50px;object-fit:cover;border-radius:6px;">';
            echo '<strong>' . esc_html( get_the_title( $post->ID ) ) . '</strong>';
            echo '<span class="academy-order-number" style="margin-right:auto;color:#646970;">' . ( $index + 1 ) . '</span>';
            echo '</li>';
        }
        echo '</ul><button type="button" class="button button-primary" id="academy-save-instructors-order">ذخیره ترتیب</button> <span id="academy-instructors-order-status" style="margin-right:10px;"></span>';
        echo '</div>';
        ?>
        <script>
        jQuery(function($){
            var list = $('#academy-instructors-order-list');
            list.sortable({
                update:function(){
                    list.children('li').each(function(i){ $(this).find('.academy-order-number').text(i+1); });
                }
            });
            $('#academy-save-instructors-order').on('click', function(){
                var btn=$(this), status=$('#academy-instructors-order-status');
                var ids=list.children('li').map(function(){return $(this).data('id');}).get();
                btn.prop('disabled',true); status.text('در حال ذخیره...');
                $.post(ajaxurl,{
                    action:'academy_instructors_save_order',
                    nonce:'<?php echo esc_js( $nonce ); ?>',
                    ids:ids
                }).done(function(resp){
                    status.text(resp && resp.success ? 'ترتیب ذخیره شد.' : 'ذخیره انجام نشد.');
                }).fail(function(){status.text('خطا در ذخیره ترتیب.');})
                .always(function(){btn.prop('disabled',false);});
            });
        });
        </script>
        <?php
    }

    public static function ajax_save_order() {
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ), 403 );
        check_ajax_referer( 'academy_instructors_order', 'nonce' );
        $ids = isset( $_POST['ids'] ) && is_array( $_POST['ids'] ) ? array_map( 'absint', wp_unslash( $_POST['ids'] ) ) : array();
        $ids = array_values( array_filter( $ids ) );
        foreach ( $ids as $position => $id ) {
            $post = get_post( $id );
            if ( $post && self::POST_TYPE === $post->post_type && 'publish' === $post->post_status ) {
                update_post_meta( $id, self::META_ORDER, $position + 1 );
            }
        }
        wp_send_json_success();
    }

    public static function dynamic_data( $data, $context = array() ) {
        if ( is_array( $context ) && ! empty( $context['type'] ) && 'instructor' === $context['type'] ) {
            $d = self::get_instructor( $context['id'] );
            if ( $d ) $data['instructor'] = $d;
        }
        return $data;
    }

    public static function rest() {
        register_rest_route( 'academy-site/v1', '/instructors/(?P<id>\d+)', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => function( $request ) { return rest_ensure_response( self::get_instructor( absint( $request['id'] ) ) ); },
            'permission_callback' => '__return_true',
        ) );
    }
}
Academy_Site_Instructors::boot();
