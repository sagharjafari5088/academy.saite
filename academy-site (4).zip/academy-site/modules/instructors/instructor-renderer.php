<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Instructor-only Elementor marker renderer.
 * This file must remain independent from certificate/course/event renderers.
 */
final class Academy_Site_Instructor_Renderer {
    public static function boot() {
        add_filter( 'academy_site_render_map', array( __CLASS__, 'map' ), 20, 3 );
        add_filter( 'elementor/widget/render_content', array( __CLASS__, 'render_single' ), 30, 2 );
        add_filter( 'elementor/widget/render_content', array( __CLASS__, 'render_carousel' ), 31, 2 );
    }


    public static function map( $map, $type, $data ) {
        if ( 'instructor' !== $type ) return $map;

        $d = is_array( $data ) ? $data : (array) $data;
        $id = absint( $d['id'] ?? 0 );
        $name = (string) ( $d['name'] ?? ( $id ? get_the_title( $id ) : '' ) );
        $subtitle = (string) ( $d['subtitle'] ?? $d['title'] ?? '' );
        $description = (string) ( $d['description'] ?? $d['bio'] ?? '' );
        $image_url = (string) ( $d['image_url'] ?? '' );
        if ( ! $image_url && $id ) {
            $image_url = (string) ( get_the_post_thumbnail_url( $id, 'full' ) ?: '' );
        }
        $url = (string) ( $d['url'] ?? '' );
        if ( $id && class_exists( 'Academy_Site_Instructors' ) && method_exists( 'Academy_Site_Instructors', 'profile_url' ) ) {
            $profile_url = (string) Academy_Site_Instructors::profile_url( $id );
            if ( $profile_url ) $url = $profile_url;
        } elseif ( ! $url && $id ) {
            $url = (string) ( get_permalink( $id ) ?: '' );
        }

        $image_html = '';
        if ( $image_url ) {
            $image_html = '<img src="' . esc_url( $image_url ) . '" alt="' . esc_attr( $name ) . '" class="academy-instructor-image">';
        }

        $qr_url = (string) ( $d['qr_url'] ?? '' );
        if ( ! $qr_url && $url && class_exists( 'Academy_Site_QR' ) ) {
            $qr_url = (string) Academy_Site_QR::image_url( $url, 220 );
        }

        $m = array(
            'instructor_id'          => (string) $id,
            'instructor_name'        => esc_html( $name ),
            'instructor_title'       => esc_html( $subtitle ),
            'instructor_subtitle'   => esc_html( $subtitle ),
            'instructor_description' => wp_kses_post( $description ),
            'instructor_bio'         => wp_kses_post( $description ),
            'instructor_image'       => $image_html,
            'instructor_image_url'   => esc_url( $image_url ),
            'instructor_url'         => esc_url( $url ),
            'instructor_action_url'  => esc_url( $url ),
            'instructor_action'      => $url ? '<a class="academy-instructor-action" href="' . esc_url( $url ) . '">مشاهده پروفایل</a>' : '',
            'instructor_qr_url'      => esc_url( $qr_url ),
            'instructor_qr'          => ( $qr_url && class_exists( 'Academy_Site_QR' ) ) ? Academy_Site_QR::image_html( $url, 'academy-instructor-qr', 'QR مدرس', 220 ) : '',
        );

        return $m;
    }

    /**
     * Instructor-only homepage carousel loop.
     * Usage: {{#instructor_carousel}} ... {{/instructor_carousel}}
     * The supplied block is one Elementor-designed slide; this module repeats it.
     */
    public static function render_carousel( $content, $widget ) {
        if ( ! is_object( $widget ) || ! class_exists( 'Academy_Site_Instructors' ) || ! preg_match( '/\{\{\s*#instructor_carousel\s*\}\}/', $content ) ) return $content;
        $name = method_exists( $widget, 'get_name' ) ? (string) $widget->get_name() : '';
        if ( 'html' !== strtolower( $name ) ) return $content;

        $posts = Academy_Site_Instructors::get_all();
        if ( ! $posts ) return preg_replace( '/\{\{\s*#instructor_carousel\s*\}\}|\{\{\s*\/instructor_carousel\s*\}\}/', '', $content );

        /*
         * Elementor owns the complete carousel shell. The HTML Widget may
         * contain the carousel root, track, controls, CSS and inline JS.
         * Academy Site only repeats the instructor card template between
         * {{#instructor_carousel}} and {{/instructor_carousel}}.
         *
         * This keeps the entire visual/interactive implementation in one
         * Elementor HTML Widget and prevents the module from injecting its
         * own wrapper or external JS into the page.
         */
        return preg_replace_callback( '/\{\{\s*#instructor_carousel\s*\}\}(.*?)\{\{\s*\/instructor_carousel\s*\}\}/s', function( $m ) use ( $posts ) {
            $template = $m[1];
            $slides = '';
            foreach ( $posts as $data ) {
                $slides .= self::replace_markers( $template, $data );
            }
            return $slides;
        }, $content );
    }

    public static function render_single( $content, $widget ) {
        if ( ! is_object( $widget ) || strpos( $content, '{{' ) === false ) return $content;
        $name = method_exists( $widget, 'get_name' ) ? (string) $widget->get_name() : '';
        if ( 'html' !== strtolower( $name ) ) return $content;
        if ( ! isset( $_GET['instructor'] ) || ! class_exists( 'Academy_Site_Instructors' ) ) return $content;

        $raw = sanitize_text_field( wp_unslash( $_GET['instructor'] ) );
        $data = ctype_digit( $raw )
            ? Academy_Site_Instructors::get_instructor( absint( $raw ) )
            : Academy_Site_Instructors::find_by_token( $raw );
        if ( ! $data ) return $content;

        return self::replace_markers( $content, $data );
    }

    private static function replace_markers( $html, $d ) {
        $map = self::map( array(), 'instructor', $d );
        return preg_replace_callback('/\{\{\s*([a-zA-Z0-9_.:-]+)\s*\}\}/', function($m) use ($map) {
            $key = strtolower(trim($m[1]));
            $candidates = array_unique(array($key, str_replace('-', '_', $key), str_replace('_', '-', $key)));
            foreach ($candidates as $candidate) if (array_key_exists($candidate, $map)) return (string)$map[$candidate];
            return $m[0];
        }, $html);
    }
}
Academy_Site_Instructor_Renderer::boot();
