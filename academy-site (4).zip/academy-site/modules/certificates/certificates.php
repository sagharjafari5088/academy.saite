<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * =========================================================
 * ACADEMY SITE — CERTIFICATES
 * =========================================================
 *
 * Structure:
 *
 * 1. Certificate Templates
 * 2. Online Course → Certificate Template
 * 3. Manual Certificate Issuance
 * 4. Automatic Online Course Certificates
 * 5. Issued Certificates Archive
 *    - Course Certificates
 *    - Manual Certificates
 * 6. Public Verification
 *    - By Verification Code
 *    - By National ID
 * 7. Student Certificates
 *
 * IMPORTANT:
 *
 * - Manual certificates are NOT connected to WordPress users.
 * - Manual certificates are for any person, including people
 *   who are not Academy students.
 * - National ID is stored ONLY for manual certificates.
 * - Online course certificates do NOT use National ID.
 * - Teacher / speaker / event / seminar / workshop information
 *   is NOT entered during issuance.
 * - Such information can be written inside the template
 *   custom field and/or body HTML.
 * - The template body_html is the source for certificate
 *   output and verification text.
 *
 * =========================================================
 */

final class Academy_Site_Certificates {

    const TABLE            = 'academy_certificates';
    const TEMPLATES        = 'academy_certificate_templates';
    const REST_NAMESPACE   = 'academy-site/v1';
    const CODE_PREFIX      = 'AC';

    /**
     * =====================================================
     * BOOT
     * =====================================================
     */

    public static function boot() {

        /*
         * Automatic certificate issuance.
         *
         * This hook is expected to be fired by the Academy
         * course system when the student completes the course.
         */
        add_action(
            'academy_site_course_completed',
            array( __CLASS__, 'issue_on_completion' ),
            20,
            2
        );

        add_action(
            'rest_api_init',
            array( __CLASS__, 'register_routes' )
        );

        add_filter(
            'academy_site_dynamic_data',
            array( __CLASS__, 'dynamic_data' ),
            50,
            2
        );

        // The certificate admin screen is owned by Academy Site Admin Hub.
        // Do not register a second standalone certificate menu here.
    }


    /**
     * =====================================================
     * TABLE NAMES
     * =====================================================
     */

    public static function table_name() {

        global $wpdb;

        return $wpdb->prefix . self::TABLE;
    }


    public static function templates_table() {

        global $wpdb;

        return $wpdb->prefix . self::TEMPLATES;
    }


    /**
     * =====================================================
     * INSTALL / UPGRADE
     * =====================================================
     */

    public static function install() {

        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();


        /*
         * -------------------------------------------------
         * CERTIFICATES TABLE
         * -------------------------------------------------
         */

        dbDelta(
            "CREATE TABLE " . self::table_name() . " (

                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,

                user_id BIGINT UNSIGNED NULL,

                course_id BIGINT UNSIGNED NULL,

                template_id BIGINT UNSIGNED NULL,

                national_id VARCHAR(32) NULL,

                verification_code VARCHAR(64) NOT NULL,

                status VARCHAR(20) NOT NULL DEFAULT 'issued',

                issued_at DATETIME NOT NULL,

                revoked_at DATETIME NULL,

                metadata LONGTEXT NULL,

                PRIMARY KEY (id),

                UNIQUE KEY verification_code (verification_code),

                UNIQUE KEY user_course (user_id, course_id),

                KEY user_status (user_id, status),

                KEY course_status (course_id, status),

                KEY national_status (national_id, status),

                KEY template_id (template_id)

            ) {$charset};"
        );


        /*
         * -------------------------------------------------
         * TEMPLATES TABLE
         * -------------------------------------------------
         */

        dbDelta(
            "CREATE TABLE " . self::templates_table() . " (

                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,

                title VARCHAR(255) NOT NULL,

                certificate_type VARCHAR(40) NOT NULL DEFAULT 'course',

                mode VARCHAR(20) NOT NULL DEFAULT 'text',

                image_url TEXT NULL,

                body_html LONGTEXT NULL,

                custom_field LONGTEXT NULL,

                show_issue_date TINYINT(1) NOT NULL DEFAULT 0,

                show_issue_time TINYINT(1) NOT NULL DEFAULT 0,

                status VARCHAR(20) NOT NULL DEFAULT 'active',

                created_at DATETIME NOT NULL,

                updated_at DATETIME NOT NULL,

                PRIMARY KEY (id),

                KEY status (status),

                KEY certificate_type (certificate_type)

            ) {$charset};"
        );


        /*
         * -------------------------------------------------
         * SAFE UPGRADE FOR EXISTING INSTALLATIONS
         * -------------------------------------------------
         */

        $certificate_columns = array(
            'user_id'     => 'BIGINT UNSIGNED NULL',
            'course_id'   => 'BIGINT UNSIGNED NULL',
            'template_id' => 'BIGINT UNSIGNED NULL',
            'national_id' => 'VARCHAR(32) NULL',
            'metadata'    => 'LONGTEXT NULL',
        );


        foreach ( $certificate_columns as $column => $definition ) {

            $exists = $wpdb->get_var(
                $wpdb->prepare(
                    'SHOW COLUMNS FROM ' . self::table_name() . ' LIKE %s',
                    $column
                )
            );

            if ( ! $exists ) {

                $wpdb->query(
                    'ALTER TABLE ' .
                    self::table_name() .
                    ' ADD ' .
                    $column .
                    ' ' .
                    $definition
                );
            }
        }


        $template_columns = array(
            'custom_field'      => 'LONGTEXT NULL',
            'show_issue_date'  => 'TINYINT(1) NOT NULL DEFAULT 0',
            'show_issue_time'  => 'TINYINT(1) NOT NULL DEFAULT 0',
        );


        foreach ( $template_columns as $column => $definition ) {

            $exists = $wpdb->get_var(
                $wpdb->prepare(
                    'SHOW COLUMNS FROM ' . self::templates_table() . ' LIKE %s',
                    $column
                )
            );

            if ( ! $exists ) {

                $wpdb->query(
                    'ALTER TABLE ' .
                    self::templates_table() .
                    ' ADD ' .
                    $column .
                    ' ' .
                    $definition
                );
            }
        }
    }


    /**
     * =====================================================
     * NATIONAL ID NORMALIZER
     * =====================================================
     */

    public static function normalize_national_id( $value ) {

        $value = trim( (string) $value );

        $value = str_replace(
            array(
                '۰','۱','۲','۳','۴',
                '۵','۶','۷','۸','۹'
            ),
            array(
                '0','1','2','3','4',
                '5','6','7','8','9'
            ),
            $value
        );

        $value = preg_replace(
            '/\D+/',
            '',
            $value
        );

        return $value;
    }


    /**
     * =====================================================
     * TEMPLATE METHODS
     * =====================================================
     */

    /**
     * =====================================================
     * ADMIN TEMPLATE CRUD
     * =====================================================
     */
    public static function save_template( $data = array(), $id = 0 ) {
        global $wpdb;

        $data = is_array( $data ) ? $data : array();
        $id   = absint( $id );

        $title = sanitize_text_field( $data['title'] ?? '' );
        if ( '' === $title ) {
            return new WP_Error( 'template_title_required', 'عنوان قالب الزامی است.' );
        }

        $mode = sanitize_key( $data['mode'] ?? 'text' );
        if ( ! in_array( $mode, array( 'text', 'image', 'image_text' ), true ) ) {
            $mode = 'text';
        }

        $image_url = esc_url_raw( $data['image_url'] ?? '' );
        $body = isset( $data['body_html'] )
            ? (string) $data['body_html']
            : (string) ( $data['body_text'] ?? '' );

        $body = wp_kses_post( wp_unslash( $body ) );
        $custom_field = wp_kses_post( wp_unslash( (string) ( $data['custom_field'] ?? '' ) ) );
        $now = current_time( 'mysql' );

        $payload = array(
            'title'          => $title,
            'certificate_type'=> sanitize_key( $data['certificate_type'] ?? 'course' ),
            'mode'           => $mode,
            'image_url'      => $image_url,
            'body_html'      => $body,
            'custom_field'   => $custom_field,
            'show_issue_date'=> isset( $data['show_issue_date'] ) ? absint( $data['show_issue_date'] ) : 0,
            'show_issue_time'=> isset( $data['show_issue_time'] ) ? absint( $data['show_issue_time'] ) : 0,
            'status'         => sanitize_key( $data['status'] ?? 'active' ),
            'updated_at'     => $now,
        );

        if ( ! in_array( $payload['status'], array( 'active', 'inactive' ), true ) ) {
            $payload['status'] = 'active';
        }

        if ( $id ) {
            $ok = $wpdb->update(
                self::templates_table(),
                $payload,
                array( 'id' => $id ),
                array( '%s','%s','%s','%s','%s','%s','%d','%d','%s','%s' ),
                array( '%d' )
            );

            if ( false === $ok ) {
                return new WP_Error( 'template_update_failed', 'ویرایش قالب ناموفق بود.' );
            }

            return self::get_template( $id );
        }

        $payload['created_at'] = $now;
        $ok = $wpdb->insert(
            self::templates_table(),
            $payload,
            array( '%s','%s','%s','%s','%s','%s','%d','%d','%s','%s','%s' )
        );

        if ( false === $ok ) {
            return new WP_Error( 'template_insert_failed', 'ثبت قالب ناموفق بود.' );
        }

        return self::get_template( $wpdb->insert_id );
    }

    public static function delete_template( $id ) {
        global $wpdb;
        $id = absint( $id );

        if ( ! $id || ! self::get_template( $id ) ) {
            return new WP_Error( 'template_not_found', 'قالب پیدا نشد.' );
        }

        $used = $wpdb->get_var(
            $wpdb->prepare(
                'SELECT COUNT(*) FROM ' . self::table_name() . ' WHERE template_id=%d',
                $id
            )
        );

        if ( absint( $used ) > 0 ) {
            return new WP_Error(
                'template_in_use',
                'این قالب برای گواهینامه‌های صادرشده استفاده شده و قابل حذف نیست.'
            );
        }

        $ok = $wpdb->delete(
            self::templates_table(),
            array( 'id' => $id ),
            array( '%d' )
        );

        return false === $ok
            ? new WP_Error( 'template_delete_failed', 'حذف قالب ناموفق بود.' )
            : true;
    }

    public static function assign_course_template( $course_id, $template_id ) {
        $course_id  = absint( $course_id );
        $template_id = absint( $template_id );

        if ( ! $course_id || 'academy_course' !== get_post_type( $course_id ) ) {
            return new WP_Error( 'invalid_course', 'دوره معتبر نیست.' );
        }

        if ( $template_id ) {
            $template = self::get_template( $template_id );
            if ( ! $template || 'active' !== $template->status ) {
                return new WP_Error( 'invalid_template', 'قالب معتبر یا فعال نیست.' );
            }
            update_post_meta( $course_id, 'academy_certificate_template_id', $template_id );
        } else {
            delete_post_meta( $course_id, 'academy_certificate_template_id' );
        }

        return true;
    }

    public static function update_issued( $id, $data = array() ) {
        global $wpdb;

        $id = absint( $id );
        $certificate = self::get( $id );

        if ( ! $certificate ) {
            return new WP_Error( 'certificate_not_found', 'گواهینامه پیدا نشد.' );
        }

        $data = is_array( $data ) ? $data : array();
        $template_id = array_key_exists( 'template_id', $data )
            ? absint( $data['template_id'] )
            : absint( $certificate->template_id );

        $template = self::get_template( $template_id );
        if ( ! $template || 'active' !== $template->status ) {
            return new WP_Error( 'invalid_certificate_template', 'قالب معتبر یا فعال نیست.' );
        }

        $meta = self::get_metadata( $certificate );

        if ( array_key_exists( 'student_name', $data ) ) {
            $meta['student_name'] = sanitize_text_field( wp_unslash( $data['student_name'] ) );
        }
        if ( '' === trim( (string) ( $meta['student_name'] ?? '' ) ) ) {
            return new WP_Error( 'certificate_name_required', 'نام و نام خانوادگی الزامی است.' );
        }

        if ( array_key_exists( 'national_id', $data ) ) {
            $meta['national_id'] = self::normalize_national_id( wp_unslash( $data['national_id'] ) );
        }
        if ( array_key_exists( 'issue_date', $data ) ) {
            $meta['issue_date'] = sanitize_text_field( wp_unslash( $data['issue_date'] ) );
        }
        if ( array_key_exists( 'duration', $data ) ) {
            $meta['duration'] = sanitize_text_field( wp_unslash( $data['duration'] ) );
        }

        $meta['template_id'] = $template_id;
        $meta['certificate_title'] = $template->title;
        $meta['certificate_type'] = $template->certificate_type;
        $meta['custom_field'] = (string) $template->custom_field;

        $national = (string) ( $meta['national_id'] ?? '' );
        if ( ! $certificate->course_id ) {
            if ( '' === $national ) {
                return new WP_Error( 'national_id_required', 'کد ملی برای گواهینامه دستی الزامی است.' );
            }
        } else {
            $national = '';
            $meta['national_id'] = '';
        }

        $ok = $wpdb->update(
            self::table_name(),
            array(
                'template_id' => $template_id,
                'national_id' => $national ?: null,
                'metadata'    => wp_json_encode( $meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
            ),
            array( 'id' => $id ),
            array( '%d','%s','%s' ),
            array( '%d' )
        );

        if ( false === $ok ) {
            return new WP_Error( 'certificate_update_failed', 'ویرایش گواهینامه ناموفق بود.' );
        }

        return self::get( $id );
    }

    public static function delete_issued( $id ) {
        global $wpdb;
        $id = absint( $id );

        if ( ! self::get( $id ) ) {
            return new WP_Error( 'certificate_not_found', 'گواهینامه پیدا نشد.' );
        }

        $ok = $wpdb->delete(
            self::table_name(),
            array( 'id' => $id ),
            array( '%d' )
        );

        return false === $ok
            ? new WP_Error( 'certificate_delete_failed', 'حذف گواهینامه ناموفق بود.' )
            : true;
    }

    public static function get_user_certificates( $user_id ) {
        return self::user_certificates( absint( $user_id ) );
    }

    public static function qr_url( $code ) {
        $code = sanitize_text_field( $code );
        if ( '' === $code ) {
            return '';
        }

        if ( class_exists( 'Academy_Site_QR' ) ) {
            $target = Academy_Site_QR::certificate_url( $code );
            return Academy_Site_QR::image_url( $target, 180 );
        }

        return '';
    }

    public static function get_template( $id ) {

        global $wpdb;

        return $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' .
                self::templates_table() .
                ' WHERE id=%d LIMIT 1',
                absint( $id )
            )
        );
    }


    public static function get_templates() {
        global $wpdb;

        $table = self::templates_table();

        return $wpdb->get_results(
            "SELECT * FROM {$table} ORDER BY id DESC"
        );
    }

    public static function get_active_templates() {

        global $wpdb;

        return $wpdb->get_results(
            'SELECT * FROM ' .
            self::templates_table() .
            " WHERE status='active'
              ORDER BY id DESC"
        );
    }


    /**
     * =====================================================
     * GENERATE VERIFICATION CODE
     * =====================================================
     */

    public static function generate_code() {

        do {

            $code =
                self::CODE_PREFIX .
                '-' .
                strtoupper(
                    wp_generate_password(
                        12,
                        false,
                        false
                    )
                );

        } while ( self::get_by_code( $code ) );

        return $code;
    }


    /**
     * =====================================================
     * GET CERTIFICATE
     * =====================================================
     */

    public static function get( $id ) {

        global $wpdb;

        return $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' .
                self::table_name() .
                ' WHERE id=%d LIMIT 1',
                absint( $id )
            )
        );
    }


    /**
     * Return all issued certificates for the Academy HTML Loop.
     * Each row is passed through verify() so the renderer receives the
     * same stable certificate data contract as a public verification.
     */
    public static function all_issued( $limit = 0 ) {
        global $wpdb;

        $sql = 'SELECT * FROM ' . self::table_name() .
            " WHERE status='issued' ORDER BY issued_at DESC,id DESC";
        if ( absint( $limit ) > 0 ) {
            $sql .= ' LIMIT ' . absint( $limit );
        }

        $rows = $wpdb->get_results( $sql );

        foreach ( (array) $rows as $row ) {
            $meta = self::get_metadata( $row );
            $row->student_name = (string) ( $meta['student_name'] ?? '' );
            $row->first_name = (string) ( $meta['first_name'] ?? '' );
            $row->last_name = (string) ( $meta['last_name'] ?? '' );
            $row->national_id = (string) ( $meta['national_id'] ?? ( $row->national_id ?? '' ) );
            $row->issue_date = (string) ( $meta['issue_date'] ?? '' );
            $row->issue_time = (string) ( $meta['issue_time'] ?? '' );
            $row->duration = (string) ( $meta['duration'] ?? '' );
            $row->source = (string) ( $meta['source'] ?? '' );
            $row->course_name = (string) ( $meta['course_name'] ?? '' );
        }

        return (array) $rows;
    }


    public static function get_all( $limit = 0 ) {

        global $wpdb;

        $sql = 'SELECT * FROM ' . self::table_name() .
            " WHERE status='issued' ORDER BY issued_at DESC,id DESC";

        if ( absint( $limit ) > 0 ) {
            $sql .= ' LIMIT ' . absint( $limit );
        }

        $rows = $wpdb->get_results( $sql );
        $out  = array();

        foreach ( (array) $rows as $row ) {
            $verified = self::verify( $row->verification_code );
            if ( $verified ) {
                $out[] = $verified;
            }
        }

        return $out;
    }


    public static function get_by_code( $code ) {

        global $wpdb;

        return $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' .
                self::table_name() .
                ' WHERE verification_code=%s
                  LIMIT 1',
                sanitize_text_field( $code )
            )
        );
    }


    public static function get_by_user_course(
        $user_id,
        $course_id
    ) {

        global $wpdb;

        return $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' .
                self::table_name() .
                ' WHERE user_id=%d
                  AND course_id=%d
                  AND status="issued"
                  LIMIT 1',
                absint( $user_id ),
                absint( $course_id )
            )
        );
    }


    /**
     * =====================================================
     * USER CERTIFICATES
     * =====================================================
     */

    public static function user_certificates( $user_id ) {

        global $wpdb;

        if ( ! $user_id ) {
            return array();
        }

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT * FROM ' .
                self::table_name() .
                ' WHERE user_id=%d
                  AND status="issued"
                  ORDER BY issued_at DESC,id DESC',
                absint( $user_id )
            )
        );

        $out = array();

        foreach ( $rows as $row ) {

            $verified = self::verify(
                $row->verification_code
            );

            if ( $verified ) {
                $out[] = $verified;
            }
        }

        return $out;
    }


    /**
     * =====================================================
     * AUTOMATIC ONLINE COURSE CERTIFICATE
     * =====================================================
     */

    public static function issue_on_completion(
        $user_id,
        $course_id
    ) {

        $user_id   = absint( $user_id );
        $course_id = absint( $course_id );


        if ( ! $user_id || ! $course_id ) {

            return new WP_Error(
                'certificate_invalid_completion',
                'اطلاعات دانشجو یا دوره معتبر نیست.'
            );
        }


        /*
         * Only Academy courses.
         */

        if (
            'academy_course' !==
            get_post_type( $course_id )
        ) {

            return new WP_Error(
                'certificate_invalid_course',
                'دوره معتبر نیست.'
            );
        }


        /*
         * Find the template connected to this course.
         */

        $template_id = absint(
            get_post_meta(
                $course_id,
                'academy_certificate_template_id',
                true
            )
        );


        /*
         * No template = no automatic certificate.
         */

        if ( ! $template_id ) {

            return new WP_Error(
                'certificate_template_not_assigned',
                'برای این دوره قالب گواهینامه تعیین نشده است.'
            );
        }


        return self::issue(
            $user_id,
            $course_id,
            array(
                'template_id' => $template_id,
                'source'      => 'course',
            )
        );
    }


    /**
     * =====================================================
     * MAIN ISSUE METHOD
     * =====================================================
     *
     * Two modes:
     *
     * COURSE:
     * user_id + course_id
     *
     * MANUAL:
     * no user_id + no course_id
     *
     * Manual certificates are completely independent
     * from Academy users.
     */

    public static function issue(
        $user_id = 0,
        $course_id = 0,
        array $metadata = array()
    ) {

        global $wpdb;

        $user_id   = absint( $user_id );
        $course_id = absint( $course_id );


        /*
         * -------------------------------------------------
         * OWNER VALIDATION
         * -------------------------------------------------
         */

        if (
            $user_id &&
            ! get_user_by(
                'id',
                $user_id
            )
        ) {

            return new WP_Error(
                'invalid_certificate_owner',
                'دانشجوی انتخاب‌شده معتبر نیست.'
            );
        }


        /*
         * -------------------------------------------------
         * COURSE VALIDATION
         * -------------------------------------------------
         */

        if (
            $course_id &&
            'academy_course' !==
            get_post_type( $course_id )
        ) {

            return new WP_Error(
                'invalid_certificate_course',
                'دوره معتبر نیست.'
            );
        }


        /*
         * -------------------------------------------------
         * TEMPLATE
         * -------------------------------------------------
         */

        $template_id = absint(
            $metadata['template_id'] ?? 0
        );


        if (
            ! $template_id &&
            $course_id
        ) {

            $template_id = absint(
                get_post_meta(
                    $course_id,
                    'academy_certificate_template_id',
                    true
                )
            );
        }


        if ( ! $template_id ) {

            return new WP_Error(
                'certificate_template_required',
                'قالب گواهینامه انتخاب نشده است.'
            );
        }


        $template =
            self::get_template(
                $template_id
            );


        if (
            ! $template ||
            'active' !== $template->status
        ) {

            return new WP_Error(
                'invalid_certificate_template',
                'قالب گواهینامه معتبر یا فعال نیست.'
            );
        }


        /*
         * -------------------------------------------------
         * DUPLICATE ONLINE CERTIFICATE
         * -------------------------------------------------
         */

        if (
            $course_id &&
            $user_id
        ) {

            $existing =
                self::get_by_user_course(
                    $user_id,
                    $course_id
                );

            if ( $existing ) {
                return $existing;
            }
        }


        /*
         * -------------------------------------------------
         * NAME
         * -------------------------------------------------
         */

        $first = sanitize_text_field(
            $metadata['first_name'] ?? ''
        );

        $last = sanitize_text_field(
            $metadata['last_name'] ?? ''
        );

        $name = sanitize_text_field(
            $metadata['student_name'] ?? ''
        );


        /*
         * If this is an Academy student,
         * use account information as fallback.
         */

        if ( $user_id ) {

            $u = get_userdata(
                $user_id
            );

            if ( $u ) {

                $first =
                    $first ?: $u->first_name;

                $last =
                    $last ?: $u->last_name;

                $name =
                    $name ?: $u->display_name;
            }
        }


        if ( ! $name ) {

            $name = trim(
                $first . ' ' . $last
            );
        }


        if ( ! $name ) {

            return new WP_Error(
                'certificate_name_required',
                'نام و نام خانوادگی دریافت‌کننده الزامی است.'
            );
        }


        /*
         * -------------------------------------------------
         * NATIONAL ID
         * -------------------------------------------------
         *
         * IMPORTANT:
         *
         * Only manual certificates have
         * a national ID.
         */

        $national = '';

        if ( ! $course_id ) {

            $national =
                self::normalize_national_id(
                    $metadata['national_id'] ?? ''
                );


            if ( ! $national ) {

                return new WP_Error(
                    'national_id_required',
                    'کد ملی برای صدور دستی گواهینامه الزامی است.'
                );
            }
        }


        /*
         * -------------------------------------------------
         * METADATA
         * -------------------------------------------------
         */

        $metadata['student_name'] =
            $name;

        $metadata['first_name'] =
            $first;

        $metadata['last_name'] =
            $last;

        $metadata['national_id'] =
            $national;

        $metadata['template_id'] =
            $template_id;

        $metadata['certificate_title'] =
            $template->title;

        $metadata['certificate_type'] =
            $template->certificate_type;

        $metadata['custom_field'] =
            (string) $template->custom_field;


        /*
         * -------------------------------------------------
         * SOURCE
         * -------------------------------------------------
         */

        if ( $course_id ) {

            $metadata['course_name'] =
                get_the_title(
                    $course_id
                );

            $metadata['source'] =
                'course';

            /*
             * Online certificate:
             * no national ID.
             */

            $metadata['national_id'] = '';

            $national = '';

        } else {

            $metadata['source'] =
                'manual';
        }


        /*
         * -------------------------------------------------
         * OPTIONAL DATE / TIME
         * -------------------------------------------------
         */

        /*
         * Certificate date is an INSTANCE value.
         * If admin supplied a date, keep it exactly as entered.
         * Otherwise use today's WordPress-local date.
         */
        $metadata['issue_date'] =
            ! empty( $metadata['issue_date'] )
            ? sanitize_text_field( $metadata['issue_date'] )
            : wp_date(
                'Y-m-d',
                current_time( 'timestamp' )
            );

        $metadata['issue_time'] =
            ! empty(
                $template->show_issue_time
            )
            ? wp_date(
                'H:i',
                current_time( 'timestamp' )
            )
            : '';

        $metadata['issued_at'] =
            current_time(
                'mysql'
            );


        /*
         * -------------------------------------------------
         * VERIFICATION CODE
         * -------------------------------------------------
         */

        $code =
            self::generate_code();


        /*
         * -------------------------------------------------
         * INSERT
         * -------------------------------------------------
         */

        $payload = wp_json_encode(
            $metadata,
            JSON_UNESCAPED_UNICODE |
            JSON_UNESCAPED_SLASHES
        );


        $ok = $wpdb->insert(
            self::table_name(),
            array(
                'user_id' =>
                    $user_id ?: null,

                'course_id' =>
                    $course_id ?: null,

                'template_id' =>
                    $template_id,

                'national_id' =>
                    $national ?: null,

                'verification_code' =>
                    $code,

                'status' =>
                    'issued',

                'issued_at' =>
                    current_time(
                        'mysql',
                        true
                    ),

                'revoked_at' =>
                    null,

                'metadata' =>
                    $payload,
            ),
            array(
                '%d',
                '%d',
                '%d',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
            )
        );


        if ( false === $ok ) {

            /*
             * Online course duplicate fallback.
             */

            if (
                $course_id &&
                $user_id
            ) {

                $existing =
                    self::get_by_user_course(
                        $user_id,
                        $course_id
                    );

                if ( $existing ) {
                    return $existing;
                }
            }


            return new WP_Error(
                'certificate_insert_failed',
                'ثبت گواهینامه ناموفق بود.'
            );
        }


        $certificate =
            self::get(
                $wpdb->insert_id
            );


        do_action(
            'academy_site_certificate_issued',
            $certificate
        );


        return $certificate;
    }


    /**
     * =====================================================
     * GET METADATA
     * =====================================================
     */

    /**
     * Render one certificate using its stored template.
     * This is data/output generation only; Elementor remains responsible for page layout.
     */
    /**
     * Render the verification text from the selected certificate template.
     * This output is data-only and is intended for Elementor HTML widgets.
     */
    public static function render_verification_text( $certificate ) {
        if ( ! $certificate ) {
            return '';
        }

        if ( ! is_object( $certificate ) ) {
            $certificate = self::get( absint( $certificate ) );
        }

        if ( ! $certificate ) {
            return '';
        }

        $template = self::get_template( absint( $certificate->template_id ) );
        if ( ! $template || 'inactive' === $template->status ) {
            return '';
        }

        /*
         * The admin UI stores the template text in body_html. Some older
         * installations/versions may have used another field name. Keep the
         * renderer backward-compatible so a saved verification template can
         * never silently disappear just because its column name differs.
         */
        if ( empty( $template->body_html ) ) {
            if ( isset( $template->verification_text ) && '' !== (string) $template->verification_text ) {
                $template->body_html = $template->verification_text;
            } elseif ( isset( $template->body_text ) && '' !== (string) $template->body_text ) {
                $template->body_html = $template->body_text;
            }
        }

        return self::replace_variables( $template, $certificate );
    }


    public static function render_certificate( $certificate ) {
        if ( ! $certificate ) {
            return '';
        }

        if ( ! is_object( $certificate ) ) {
            $certificate = self::get( absint( $certificate ) );
        }

        if ( ! $certificate ) {
            return '';
        }

        $template = self::get_template( absint( $certificate->template_id ) );
        if ( ! $template ) {
            return '';
        }

        $body = self::replace_variables( $template, $certificate );
        $mode = sanitize_key( $template->mode ?? 'text' );
        $image = '';

        if ( ! empty( $template->image_url ) ) {
            $image = '<img class="academy-certificate-image" src="' .
                esc_url( $template->image_url ) .
                '" alt="' . esc_attr( $template->title ) . '">';
        }

        if ( 'image' === $mode ) {
            return $image;
        }

        if ( 'image_text' === $mode ) {
            return $image . '<div class="academy-certificate-text">' . $body . '</div>';
        }

        return '<div class="academy-certificate-text">' . $body . '</div>';
    }


    public static function get_metadata(
        $certificate
    ) {

        if ( ! $certificate ) {
            return array();
        }


        $meta = json_decode(
            $certificate->metadata,
            true
        );


        return is_array( $meta )
            ? $meta
            : array();
    }


    /**
     * =====================================================
     * TEMPLATE VARIABLES
     * =====================================================
     */

    private static function replace_variables(
        $template,
        $certificate
    ) {

        $meta =
            self::get_metadata(
                $certificate
            );


        
        $verification_url = class_exists( 'Academy_Site_QR' )
            ? Academy_Site_QR::certificate_url( $certificate->verification_code )
            : add_query_arg(
                'certificate',
                rawurlencode( $certificate->verification_code ),
                home_url( '/' )
            );


        /*
         * QR URL points to the same public
         * verification address.
         */

        $qr_url =
            $verification_url;


        $wrap = static function( $value ) {
            $value = (string) $value;
            return '' === $value
                ? ''
                : '<span class="academy-cert-variable">' . esc_html( $value ) . '</span>';
        };

        $values = array(
            '{{student_name}}'       => $wrap( $meta['student_name'] ?? '' ),
            '{{student-name}}'       => $wrap( $meta['student_name'] ?? '' ),
            '{{first_name}}'         => $wrap( $meta['first_name'] ?? '' ),
            '{{first-name}}'         => $wrap( $meta['first_name'] ?? '' ),
            '{{last_name}}'          => $wrap( $meta['last_name'] ?? '' ),
            '{{last-name}}'          => $wrap( $meta['last_name'] ?? '' ),
            '{{national_id}}'        => $wrap( $meta['national_id'] ?? '' ),
            '{{national-id}}'        => $wrap( $meta['national_id'] ?? '' ),
            '{{certificate_title}}'  => $wrap( $template->title ?? '' ),
            '{{template-title}}'     => $wrap( $template->title ?? '' ),
            '{{certificate_type}}'   => $wrap( $template->certificate_type ?? '' ),
            '{{verification_code}}'  => $wrap( $certificate->verification_code ),
            '{{verification-code}}'  => $wrap( $certificate->verification_code ),
            '{{certificate_number}}' => $wrap( $certificate->verification_code ),
            '{{certificate-number}}' => $wrap( $certificate->verification_code ),
            '{{course_name}}'        => $wrap( $meta['course_name'] ?? '' ),
            '{{course-name}}'        => $wrap( $meta['course_name'] ?? '' ),
            '{{custom_field}}'       => wp_kses_post( $template->custom_field ?? '' ),
            '{{custom-field}}'       => wp_kses_post( $template->custom_field ?? '' ),
            '{{issue_date}}'         => $wrap( $meta['issue_date'] ?? '' ),
            '{{date}}'               => $wrap( $meta['issue_date'] ?? '' ),
            '{{issue_time}}'         => $wrap( $meta['issue_time'] ?? '' ),
            '{{issued_at}}'          => $wrap( $meta['issued_at'] ?? '' ),
            '{{verification_url}}'   => esc_url( $verification_url ),
            '{{verification-url}}'   => esc_url( $verification_url ),
            '{{qr_url}}'             => esc_url( $qr_url ),
            '{{qr-url}}'             => esc_url( $qr_url ),
        );


        return strtr(
            (string) $template->body_html,
            $values
        );
    }


    /**
     * =====================================================
     * VERIFY ONE CERTIFICATE
     * =====================================================
     */

    public static function verify(
        $code
    ) {

        $certificate =
            self::get_by_code(
                $code
            );


        if ( ! $certificate ) {
            return null;
        }


        if (
            'issued' !==
            $certificate->status
        ) {

            return null;
        }


        $template =
            self::get_template(
                $certificate->template_id
            );


        if ( ! $template ) {
            return null;
        }


        $meta =
            self::get_metadata(
                $certificate
            );


        $body =
            self::replace_variables(
                $template,
                $certificate
            );


        
        $verification_url = class_exists( 'Academy_Site_QR' )
            ? Academy_Site_QR::certificate_url( $certificate->verification_code )
            : add_query_arg(
                'certificate',
                rawurlencode( $certificate->verification_code ),
                home_url( '/' )
            );


        return array(

            'id' =>
                (int) $certificate->id,

            'template_id' =>
                (int) $certificate->template_id,

            'duration' =>
                $meta['duration'] ?? '',

            'valid' =>
                true,

            'status' =>
                $certificate->status,

            'source' =>
                $meta['source'] ?? '',

            'certificate_title' =>
                $template->title,

            'certificate_type' =>
                $template->certificate_type,

            'student_name' =>
                $meta['student_name'] ?? '',

            'first_name' =>
                $meta['first_name'] ?? '',

            'last_name' =>
                $meta['last_name'] ?? '',

            /*
             * National ID is only returned when
             * the certificate is manual.
             */

            'national_id' =>
                $meta['national_id'] ?? (string) ( $certificate->national_id ?? '' ),

            'course_name' =>
                $meta['course_name'] ?? '',

            'verification_code' =>
                $certificate->verification_code,

            'certificate_number' =>
                $certificate->verification_code,

            'issue_date' =>
                ! empty( $meta['issue_date'] )
                    ? $meta['issue_date']
                    : ( ! empty( $meta['issued_at'] )
                        ? substr( (string) $meta['issued_at'], 0, 10 )
                        : ( ! empty( $certificate->issued_at )
                            ? substr( (string) $certificate->issued_at, 0, 10 )
                            : '' ) ),

            'issue_time' =>
                $meta['issue_time'] ?? '',

            'issued_at' =>
                $meta['issued_at'] ?? (string) ( $certificate->issued_at ?? '' ),

            /*
             * Main result text comes directly
             * from body_html.
             */

            'body_html' =>
                $body,

            'verification_text' =>
                $body,

            'custom_field' =>
                $template->custom_field ?? '',

            'verification_url' =>
                $verification_url,

            'qr_url' =>
                $verification_url,

            'image_url' =>
                $template->image_url ?? '',

            'mode' =>
                $template->mode,
        );
    }


    /**
     * =====================================================
     * VERIFY BY NATIONAL ID
     * =====================================================
     *
     * IMPORTANT:
     *
     * Only manual certificates contain national_id.
     *
     * Therefore online course certificates will NEVER
     * appear in this search.
     */

    public static function verify_by_national_id(
        $national_id
    ) {

        global $wpdb;

        $national_id =
            self::normalize_national_id(
                $national_id
            );


        if ( ! $national_id ) {
            return array();
        }


        $rows =
            $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT *
                     FROM " .
                    self::table_name() .
                    "
                     WHERE national_id=%s
                     AND status='issued'
                     ORDER BY issued_at DESC,id DESC",
                    $national_id
                )
            );


        $out = array();


        foreach ( $rows as $row ) {

            $verified =
                self::verify(
                    $row->verification_code
                );


            if ( $verified ) {
                $out[] = $verified;
            }
        }


        return $out;
    }


    /**
     * =====================================================
     * REVOKE
     * =====================================================
     */

    public static function revoke(
        $id
    ) {

        global $wpdb;


        $certificate =
            self::get(
                $id
            );


        if ( ! $certificate ) {

            return new WP_Error(
                'not_found',
                'گواهینامه پیدا نشد.'
            );
        }


        if (
            'revoked' ===
            $certificate->status
        ) {

            return $certificate;
        }


        $ok =
            $wpdb->update(
                self::table_name(),
                array(
                    'status' =>
                        'revoked',

                    'revoked_at' =>
                        current_time(
                            'mysql',
                            true
                        ),
                ),
                array(
                    'id' =>
                        absint( $id ),
                ),
                array(
                    '%s',
                    '%s',
                ),
                array(
                    '%d',
                )
            );


        if ( false === $ok ) {

            return new WP_Error(
                'update_failed',
                'لغو گواهینامه ناموفق بود.'
            );
        }


        return self::get(
            $id
        );
    }


    /**
     * =====================================================
     * REST API
     * =====================================================
     */

    public static function register_routes() {


        /*
         * -------------------------------------------------
         * SINGLE CERTIFICATE
         * -------------------------------------------------
         */

        register_rest_route(
            self::REST_NAMESPACE,
            '/certificates/verify/(?P<code>[A-Za-z0-9\-]+)',
            array(

                'methods' =>
                    WP_REST_Server::READABLE,

                'callback' =>
                    function(
                        $request
                    ) {

                        $payload =
                            self::verify(
                                $request['code']
                            );


                        if ( ! $payload ) {

                            return new WP_Error(
                                'invalid_certificate',
                                'گواهینامه معتبر نیست.',
                                array(
                                    'status' => 404,
                                )
                            );
                        }


                        return rest_ensure_response(
                            $payload
                        );
                    },

                'permission_callback' =>
                    '__return_true',
            )
        );


        /*
         * -------------------------------------------------
         * BY NATIONAL ID
         * -------------------------------------------------
         */

        register_rest_route(
            self::REST_NAMESPACE,
            '/certificates/by-national-id/(?P<national_id>[0-9]+)',
            array(

                'methods' =>
                    WP_REST_Server::READABLE,

                'callback' =>
                    function(
                        $request
                    ) {

                        return rest_ensure_response(
                            array(
                                'certificates' =>
                                    self::verify_by_national_id(
                                        $request['national_id']
                                    ),
                            )
                        );
                    },

                'permission_callback' =>
                    '__return_true',
            )
        );


        /*
         * -------------------------------------------------
         * CURRENT STUDENT CERTIFICATES
         * -------------------------------------------------
         */

        register_rest_route(
            self::REST_NAMESPACE,
            '/me/certificates',
            array(

                'methods' =>
                    WP_REST_Server::READABLE,

                'callback' =>
                    function() {

                        return rest_ensure_response(
                            self::user_certificates(
                                get_current_user_id()
                            )
                        );
                    },

                'permission_callback' =>
                    function() {

                        return is_user_logged_in();
                    },
            )
        );
    }


    /**
     * =====================================================
     * ELEMENTOR / DYNAMIC DATA
     * =====================================================
     */

    public static function dynamic_data(
        $data
    ) {


        /*
         * -------------------------------------------------
         * CURRENT STUDENT
         * -------------------------------------------------
         */

        if ( is_user_logged_in() ) {

            $data['my_certificates'] =
                self::user_certificates(
                    get_current_user_id()
                );


            if (
                is_singular(
                    'academy_course'
                )
            ) {

                $data['course_certificate'] =
                    self::get_by_user_course(
                        get_current_user_id(),
                        get_the_ID()
                    );
            }
        }


        /*
         * -------------------------------------------------
         * PUBLIC CERTIFICATE RESULT
         * -------------------------------------------------
         */

        if (
            isset(
                $_GET['certificate']
            )
        ) {

            $code =
                sanitize_text_field(
                    wp_unslash(
                        $_GET['certificate']
                    )
                );


            $data['verification_certificate'] =
                self::verify(
                    $code
                );
        }


        return $data;
    }


    /**
     * =====================================================
     * ADMIN MENU
     * =====================================================
     */

    public static function admin_menu() {

        add_submenu_page(
            'edit.php?post_type=academy_course',
            'گواهینامه‌ها',
            'گواهینامه‌ها',
            'manage_options',
            'academy-certificates',
            array(
                __CLASS__,
                'admin_page',
            )
        );
    }


    /**
     * =====================================================
     * ADMIN NOTICE
     * =====================================================
     */

    private static function admin_notice(
        $message,
        $type = 'success'
    ) {

        echo '<div class="notice notice-' .
            esc_attr( $type ) .
            '"><p>' .
            esc_html( $message ) .
            '</p></div>';
    }


    /**
     * =====================================================
     * ADMIN PAGE
     * =====================================================
     */

    public static function admin_page() {

        if (
            ! current_user_can(
                'manage_options'
            )
        ) {

            wp_die(
                'دسترسی غیرمجاز.'
            );
        }


        global $wpdb;


        /**
         * =================================================
         * SELF-HEAL: make sure the DB tables actually exist.
         * If a version bump was missed after these tables/
         * columns were introduced, academy_site_db_version
         * never triggers install() again — so we check and
         * (re)run it here defensively. dbDelta() is safe to
         * call repeatedly.
         * =================================================
         */

        $templates_table_exists = $wpdb->get_var(
            $wpdb->prepare( 'SHOW TABLES LIKE %s', self::templates_table() )
        );

        if ( ! $templates_table_exists && method_exists( __CLASS__, 'install' ) ) {
            self::install();
        }


        /**
         * =================================================
         * VERIFICATION PAGE URL
         * =================================================
         *
         * This is the real Elementor page used to display the
         * certificate verification text/detail. The generated
         * certificate link and QR code point here.
         */
        if ( isset( $_POST['save_certificate_verification_page'] ) ) {

            check_admin_referer( 'academy_certificate_verification_page' );

            $verification_page_url = esc_url_raw(
                wp_unslash(
                    $_POST['certificate_verification_page_url'] ?? ''
                )
            );

            if ( $verification_page_url ) {
                update_option(
                    'academy_certificate_verification_page_url',
                    $verification_page_url
                );
                self::admin_notice( 'صفحه استعلام گواهینامه ذخیره شد.' );
            } else {
                delete_option( 'academy_certificate_verification_page_url' );
                self::admin_notice( 'صفحه استعلام گواهینامه حذف شد.' );
            }
        }


        /**
         * =================================================
         * 1. SAVE TEMPLATE
         * =================================================
         */

        if (
            isset(
                $_POST['save_template']
            )
        ) {

            check_admin_referer(
                'academy_certificate_template'
            );


            $title =
                sanitize_text_field(
                    wp_unslash(
                        $_POST['title'] ?? ''
                    )
                );


            $type =
                sanitize_key(
                    $_POST['certificate_type']
                    ?? 'general'
                );


            $allowed_types = array(
                'course',
                'attendance',
                'seminar',
                'event',
                'workshop',
                'speaker',
                'general',
            );


            if (
                ! in_array(
                    $type,
                    $allowed_types,
                    true
                )
            ) {

                $type =
                    'general';
            }


            $mode =
                sanitize_key(
                    $_POST['mode']
                    ?? 'text'
                );


            if (
                ! in_array(
                    $mode,
                    array(
                        'text',
                        'image',
                        'image_text',
                    ),
                    true
                )
            ) {

                $mode =
                    'text';
            }


            $body_html =
                wp_kses_post(
                    wp_unslash(
                        $_POST['body_html']
                        ?? ''
                    )
                );


            $custom_field =
                wp_kses_post(
                    wp_unslash(
                        $_POST['custom_field']
                        ?? ''
                    )
                );


            $image_url =
                esc_url_raw(
                    wp_unslash(
                        $_POST['image_url']
                        ?? ''
                    )
                );


            $show_issue_date =
                ! empty(
                    $_POST['show_issue_date']
                )
                ? 1
                : 0;


            $show_issue_time =
                ! empty(
                    $_POST['show_issue_time']
                )
                ? 1
                : 0;


            if ( ! $title ) {

                self::admin_notice(
                    'عنوان قالب الزامی است.',
                    'error'
                );

            } elseif ( ! $body_html ) {

                self::admin_notice(
                    'متن / HTML قالب الزامی است.',
                    'error'
                );

            } else {

                $inserted = $wpdb->insert(
                    self::templates_table(),
                    array(

                        'title' =>
                            $title,

                        'certificate_type' =>
                            $type,

                        'mode' =>
                            $mode,

                        'image_url' =>
                            $image_url,

                        'body_html' =>
                            $body_html,

                        'custom_field' =>
                            $custom_field,

                        'show_issue_date' =>
                            $show_issue_date,

                        'show_issue_time' =>
                            $show_issue_time,

                        'status' =>
                            'active',

                        'created_at' =>
                            current_time(
                                'mysql',
                                true
                            ),

                        'updated_at' =>
                            current_time(
                                'mysql',
                                true
                            ),
                    ),
                    array(

                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%s',
                        '%d',
                        '%d',
                        '%s',
                        '%s',
                        '%s',
                    )
                );

                if ( false === $inserted ) {

                    self::admin_notice(
                        'خطا در ذخیره قالب: ' . $wpdb->last_error,
                        'error'
                    );

                } else {

                    self::admin_notice(
                        'قالب گواهینامه با موفقیت ذخیره شد.'
                    );
                }
            }
        }


        /**
         * =================================================
         * 2. CONNECT TEMPLATE TO COURSE
         * =================================================
         */

        if (
            isset(
                $_POST['assign_course_template']
            )
        ) {

            check_admin_referer(
                'academy_certificate_course_template'
            );


            $course_id =
                absint(
                    $_POST['course_id']
                    ?? 0
                );


            $template_id =
                absint(
                    $_POST['course_template_id']
                    ?? 0
                );


            if (
                ! $course_id ||
                'academy_course' !==
                get_post_type(
                    $course_id
                )
            ) {

                self::admin_notice(
                    'دوره معتبر نیست.',
                    'error'
                );

            } elseif (
                $template_id &&
                ! self::get_template(
                    $template_id
                )
            ) {

                self::admin_notice(
                    'قالب انتخاب‌شده معتبر نیست.',
                    'error'
                );

            } else {

                if ( $template_id ) {

                    update_post_meta(
                        $course_id,
                        'academy_certificate_template_id',
                        $template_id
                    );

                } else {

                    delete_post_meta(
                        $course_id,
                        'academy_certificate_template_id'
                    );
                }


                self::admin_notice(
                    'اتصال قالب به دوره ذخیره شد.'
                );
            }
        }


        /**
         * =================================================
         * 3. MANUAL ISSUE
         * =================================================
         *
         * NO USER ID.
         * NO COURSE.
         * NO TEACHER.
         * NO SPEAKER.
         * NO EVENT.
         *
         * Only:
         * first name
         * last name
         * national ID
         * template
         */

        if (
            isset(
                $_POST['issue_manual_certificate']
            )
        ) {

            check_admin_referer(
                'academy_certificate_manual_issue'
            );


            $first =
                sanitize_text_field(
                    wp_unslash(
                        $_POST['first_name']
                        ?? ''
                    )
                );


            $last =
                sanitize_text_field(
                    wp_unslash(
                        $_POST['last_name']
                        ?? ''
                    )
                );


            $national =
                self::normalize_national_id(
                    wp_unslash(
                        $_POST['national_id']
                        ?? ''
                    )
                );


            $template_id =
                absint(
                    $_POST['template_id']
                    ?? 0
                );

            /*
             * The issue date belongs to the certificate instance,
             * not to the template. Store exactly the date entered by admin.
             * Persian/Arabic digits are normalized to ASCII digits while
             * separators are preserved.
             */
            $issue_date =
                sanitize_text_field(
                    wp_unslash(
                        $_POST['issue_date']
                        ?? ''
                    )
                );

            $issue_date = strtr(
                $issue_date,
                array(
                    '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4',
                    '۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
                    '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4',
                    '٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
                )
            );


            if ( ! $first ) {

                self::admin_notice(
                    'نام الزامی است.',
                    'error'
                );

            } elseif ( ! $last ) {

                self::admin_notice(
                    'نام خانوادگی الزامی است.',
                    'error'
                );

            } elseif ( ! $national ) {

                self::admin_notice(
                    'کد ملی الزامی است.',
                    'error'
                );

            } elseif ( ! $template_id ) {

                self::admin_notice(
                    'قالب گواهینامه را انتخاب کنید.',
                    'error'
                );

            } else {

                $result =
                    self::issue(
                        0,
                        0,
                        array(

                            'template_id' =>
                                $template_id,

                            'first_name' =>
                                $first,

                            'last_name' =>
                                $last,

                            'student_name' =>
                                trim(
                                    $first .
                                    ' ' .
                                    $last
                                ),

                            'national_id' =>
                                $national,

                            'issue_date' =>
                                $issue_date,

                            'source' =>
                                'manual',
                        )
                    );


                if (
                    is_wp_error(
                        $result
                    )
                ) {

                    self::admin_notice(
                        $result->get_error_message(),
                        'error'
                    );

                } else {

                    self::admin_notice(
                        'گواهینامه دستی صادر شد. کد استعلام: ' .
                        $result->verification_code
                    );
                }
            }
        }


        /**
         * =================================================
         * DATA
         * =================================================
         */

        $templates =
            self::get_active_templates();


        $courses =
            get_posts(
                array(
                    'post_type' =>
                        'academy_course',

                    'post_status' =>
                        array(
                            'publish',
                            'draft',
                        ),

                    'numberposts' =>
                        500,

                    'orderby' =>
                        'title',

                    'order' =>
                        'ASC',
                )
            );


        $type_labels = array(

            'course' =>
                'دوره',

            'attendance' =>
                'حضور',

            'seminar' =>
                'همایش',

            'event' =>
                'رویداد',

            'workshop' =>
                'کارگاه',

            'speaker' =>
                'سخنرانی',

            'general' =>
                'عمومی / متفرقه',
        );


        echo '<div class="wrap">';

        echo '<h1>مدیریت گواهینامه‌ها</h1>';


        /**
         * =================================================
         * 1. TEMPLATE
         * =================================================
         */

        echo '<h2>صفحه استعلام گواهینامه</h2>';

        echo '<p>
            لینک «مشاهده گواهینامه» و QR هر گواهینامه به این صفحه می‌رود.
            صفحه باید همان صفحه Elementor شما برای نمایش متن استعلام باشد.
        </p>';

        echo '<form method="post">';

        wp_nonce_field(
            'academy_certificate_verification_page'
        );

        echo '<table class="form-table">
            <tr>
                <th>آدرس صفحه استعلام</th>
                <td>
                    <input
                        type="url"
                        class="large-text"
                        name="certificate_verification_page_url"
                        value="' . esc_attr(
                            get_option(
                                'academy_certificate_verification_page_url',
                                ''
                            )
                        ) . '"
                        placeholder="https://example.com/استعلام-گواهینامه/"
                    >
                    <p class="description">
                        آدرس دقیق برگه Elementor را وارد کنید.
                    </p>
                </td>
            </tr>
        </table>

        <p>
            <button
                class="button button-primary"
                name="save_certificate_verification_page"
                value="1"
            >
                ذخیره صفحه استعلام
            </button>
        </p>

        </form>';

        echo '<hr>';

        echo '<h2>۱. ثبت قالب گواهینامه</h2>';

        echo '<form method="post">';

        wp_nonce_field(
            'academy_certificate_template'
        );


        echo '<table class="form-table">';


        /*
         * TITLE
         */

        echo '<tr>
            <th>عنوان قالب</th>
            <td>
                <input
                    class="regular-text"
                    name="title"
                    required
                >
                <p class="description">
                    این عنوان در نتیجه استعلام نیز نمایش داده می‌شود.
                </p>
            </td>
        </tr>';


        /*
         * TYPE
         */

        echo '<tr>
            <th>نوع گواهینامه</th>
            <td>
                <select
                    name="certificate_type"
                    required
                >';

        foreach (
            $type_labels
            as $key => $label
        ) {

            echo '<option value="' .
                esc_attr( $key ) .
                '">' .
                esc_html( $label ) .
                '</option>';
        }

        echo '</select>
            </td>
        </tr>';


        /*
         * MODE
         */

        echo '<tr>
            <th>ساختار قالب</th>
            <td>

                <select name="mode">

                    <option value="text">
                        فقط متن
                    </option>

                    <option value="image">
                        فقط تصویر
                    </option>

                    <option value="image_text">
                        تصویر + متن
                    </option>

                </select>

            </td>
        </tr>';


        /*
         * IMAGE
         */

        echo '<tr>
            <th>تصویر قالب</th>
            <td>

                <input
                    class="large-text"
                    name="image_url"
                    type="url"
                >

                <p class="description">
                    در صورت استفاده از ساختار تصویری، آدرس تصویر قالب را وارد کنید.
                </p>

            </td>
        </tr>';


        /*
         * BODY HTML
         */

        echo '<tr>
            <th>متن / HTML قالب</th>
            <td>

                <textarea
                    class="large-text"
                    rows="12"
                    name="body_html"
                    required
                ></textarea>

                <p class="description">
                    این فیلد منبع اصلی محتوای گواهینامه و نتیجه استعلام است.
                </p>

                <p class="description">
                    متغیرهای قابل استفاده:
                </p>

                <code>
                    {{student_name}}
                    {{first_name}}
                    {{last_name}}
                    {{national_id}}
                    {{certificate_title}}
                    {{certificate_type}}
                    {{verification_code}}
                    {{certificate_number}}
                    {{course_name}}
                    {{custom_field}}
                    {{issue_date}}
                    {{issue_time}}
                    {{issued_at}}
                    {{verification_url}}
                    {{qr_url}}
                </code>

                <p class="description">
                    <strong>{{national_id}}</strong>
                    فقط در گواهینامه‌های دستی مقدار دارد.
                </p>

                <p class="description">
                    <strong>{{course_name}}</strong>
                    فقط در گواهینامه‌های دوره مقدار دارد.
                </p>

            </td>
        </tr>';


        /*
         * CUSTOM FIELD
         */

        echo '<tr>
            <th>فیلد آزاد</th>
            <td>

                <textarea
                    class="large-text"
                    rows="5"
                    name="custom_field"
                ></textarea>

                <p class="description">
                    این فیلد کاملاً آزاد است.
                    می‌توانید هر اطلاعاتی مثل نام مدرس، سخنران، همایش،
                    رویداد یا هر متن دیگری را اینجا قرار دهید.
                </p>

                <p class="description">
                    برای نمایش آن در قالب از
                    <strong>{{custom_field}}</strong>
                    استفاده کنید.
                </p>

            </td>
        </tr>';


        /*
         * OPTIONAL DATE
         */

        echo '<tr>
            <th>تاریخ صدور</th>
            <td>

                <label>

                    <input
                        type="checkbox"
                        name="show_issue_date"
                        value="1"
                    >

                    نمایش تاریخ صدور

                </label>

                <p class="description">
                    اختیاری است.
                </p>

            </td>
        </tr>';


        /*
         * OPTIONAL TIME
         */

        echo '<tr>
            <th>ساعت صدور</th>
            <td>

                <label>

                    <input
                        type="checkbox"
                        name="show_issue_time"
                        value="1"
                    >

                    نمایش ساعت صدور

                </label>

                <p class="description">
                    اختیاری است.
                </p>

            </td>
        </tr>';


        echo '</table>';


        echo '<p>

            <button
                class="button button-primary"
                name="save_template"
                value="1"
            >
                ذخیره قالب
            </button>

        </p>';


        echo '</form>';


        /**
         * =================================================
         * TEMPLATE ARCHIVE
         * =================================================
         */

        echo '<hr>';

        echo '<h2>آرشیو قالب‌های گواهینامه</h2>';

        echo '<table class="widefat striped">';

        echo '<thead>
            <tr>
                <th>ID</th>
                <th>عنوان قالب</th>
                <th>نوع</th>
                <th>ساختار</th>
                <th>تاریخ</th>
                <th>ساعت</th>
                <th>وضعیت</th>
            </tr>
        </thead>';

        echo '<tbody>';


        foreach (
            $templates
            as $template
        ) {

            echo '<tr>';

            echo '<td>' .
                absint(
                    $template->id
                ) .
                '</td>';

            echo '<td>' .
                esc_html(
                    $template->title
                ) .
                '</td>';

            echo '<td>' .
                esc_html(
                    $type_labels[
                        $template->certificate_type
                    ]
                    ??
                    $template->certificate_type
                ) .
                '</td>';

            echo '<td>' .
                esc_html(
                    $template->mode
                ) .
                '</td>';

            echo '<td>' .
                (
                    ! empty(
                        $template->show_issue_date
                    )
                    ? 'فعال'
                    : 'غیرفعال'
                ) .
                '</td>';

            echo '<td>' .
                (
                    ! empty(
                        $template->show_issue_time
                    )
                    ? 'فعال'
                    : 'غیرفعال'
                ) .
                '</td>';

            echo '<td>' .
                esc_html(
                    $template->status
                ) .
                '</td>';

            echo '</tr>';
        }


        if ( ! $templates ) {

            echo '<tr>
                <td colspan="7">
                    هنوز قالبی ثبت نشده است.
                </td>
            </tr>';
        }


        echo '</tbody>';

        echo '</table>';


        /**
         * =================================================
         * 2. COURSE TEMPLATE ASSIGNMENT
         * =================================================
         */

        echo '<hr>';

        echo '<h2>۲. اتصال قالب به دوره آنلاین</h2>';

        echo '<p>
            هر دوره‌ای که قالب داشته باشد، هنگام تکمیل دوره توسط دانشجو،
            گواهینامه آن به‌صورت خودکار صادر می‌شود.
        </p>';


        echo '<form method="post">';

        wp_nonce_field(
            'academy_certificate_course_template'
        );


        echo '<table class="form-table">';


        echo '<tr>
            <th>دوره</th>
            <td>

                <select
                    name="course_id"
                    required
                >

                    <option value="">
                        انتخاب دوره
                    </option>';


        foreach (
            $courses
            as $course
        ) {

            $assigned =
                absint(
                    get_post_meta(
                        $course->ID,
                        'academy_certificate_template_id',
                        true
                    )
                );


            echo '<option value="' .
                absint(
                    $course->ID
                ) .
                '">' .
                esc_html(
                    $course->post_title
                ) .
                (
                    $assigned
                    ? ' — قالب متصل است'
                    : ' — بدون قالب'
                ) .
                '</option>';
        }


        echo '</select>

            </td>
        </tr>';


        echo '<tr>
            <th>قالب گواهینامه</th>
            <td>

                <select
                    name="course_template_id"
                >

                    <option value="0">
                        بدون گواهینامه خودکار
                    </option>';


        foreach (
            $templates
            as $template
        ) {

            echo '<option value="' .
                absint(
                    $template->id
                ) .
                '">' .
                esc_html(
                    $template->title
                ) .
                '</option>';
        }


        echo '</select>

            </td>
        </tr>';


        echo '</table>';


        echo '<p>

            <button
                class="button button-primary"
                name="assign_course_template"
                value="1"
            >
                ذخیره اتصال دوره
            </button>

        </p>';


        echo '</form>';


        /**
         * =================================================
         * 3. MANUAL ISSUE
         * =================================================
         */

        echo '<hr>';

        echo '<h2>۳. صدور دستی گواهینامه</h2>';

        echo '<p>
            این بخش برای هر فردی قابل استفاده است؛
            فرد لازم نیست دانشجوی آکادمی باشد.
        </p>';


        echo '<form method="post">';

        wp_nonce_field(
            'academy_certificate_manual_issue'
        );


        echo '<table class="form-table">';


        echo '<tr>
            <th>نام</th>
            <td>

                <input
                    class="regular-text"
                    name="first_name"
                    required
                >

            </td>
        </tr>';


        echo '<tr>
            <th>نام خانوادگی</th>
            <td>

                <input
                    class="regular-text"
                    name="last_name"
                    required
                >

            </td>
        </tr>';


        echo '<tr>
            <th>کد ملی</th>
            <td>

                <input
                    class="regular-text"
                    name="national_id"
                    inputmode="numeric"
                    required
                >

            </td>
        </tr>';


        echo '<tr>
            <th>تاریخ صدور</th>
            <td>

                <input
                    class="regular-text"
                    name="issue_date"
                    placeholder="مثلاً ۱۴۰۴/۱۲/۰۱"
                    value="' . esc_attr( wp_date( 'Y/m/d', current_time( 'timestamp' ) ) ) . '"
                    required
                >

                <p class="description">
                    تاریخ مربوط به همین گواهینامه است و در متغیر {{date}} نمایش داده می‌شود.
                </p>

            </td>
        </tr>';


        echo '<tr>
            <th>قالب</th>
            <td>

                <select
                    name="template_id"
                    required
                >

                    <option value="">
                        انتخاب قالب
                    </option>';


        foreach (
            $templates
            as $template
        ) {

            echo '<option value="' .
                absint(
                    $template->id
                ) .
                '">' .
                esc_html(
                    $template->title
                ) .
                '</option>';
        }


        echo '</select>

            </td>
        </tr>';


        echo '</table>';


        echo '<p>

            <button
                class="button button-primary"
                name="issue_manual_certificate"
                value="1"
            >
                صدور گواهینامه
            </button>

        </p>';


        echo '</form>';


        /**
         * =================================================
         * 4. ISSUED CERTIFICATES ARCHIVE
         * =================================================
         */

        echo '<hr>';

        echo '<h2>۴. آرشیو گواهینامه‌های صادرشده</h2>';


        /*
         * -------------------------------------------------
         * COURSE CERTIFICATES
         * -------------------------------------------------
         */

        echo '<h3>گواهینامه‌های دوره‌ها</h3>';


        $course_rows =
            $wpdb->get_results(
                "SELECT *
                 FROM " .
                self::table_name() .
                "
                 WHERE course_id IS NOT NULL
                 AND status='issued'
                 ORDER BY issued_at DESC,id DESC
                 LIMIT 500"
            );


        echo '<table class="widefat striped">';

        echo '<thead>
            <tr>
                <th>ID</th>
                <th>دارنده</th>
                <th>دوره</th>
                <th>قالب</th>
                <th>کد استعلام</th>
                <th>تاریخ صدور</th>
            </tr>
        </thead>';

        echo '<tbody>';


        foreach (
            $course_rows
            as $row
        ) {

            $meta =
                self::get_metadata(
                    $row
                );


            echo '<tr>';

            echo '<td>' .
                absint(
                    $row->id
                ) .
                '</td>';

            echo '<td>' .
                esc_html(
                    $meta['student_name']
                    ?? '-'
                ) .
                '</td>';

            echo '<td>' .
                esc_html(
                    $meta['course_name']
                    ??
                    (
                        $row->course_id
                        ? get_the_title(
                            $row->course_id
                        )
                        : '-'
                    )
                ) .
                '</td>';

            echo '<td>' .
                esc_html(
                    $meta['certificate_title']
                    ??
                    '-'
                ) .
                '</td>';

            echo '<td>' .
                esc_html(
                    $row->verification_code
                ) .
                '</td>';

            echo '<td>' .
                esc_html(
                    $row->issued_at
                ) .
                '</td>';

            echo '</tr>';
        }


        if ( ! $course_rows ) {

            echo '<tr>
                <td colspan="6">
                    هنوز گواهینامه دوره‌ای صادر نشده است.
                </td>
            </tr>';
        }


        echo '</tbody>';

        echo '</table>';


        /*
         * -------------------------------------------------
         * MANUAL CERTIFICATES
         * -------------------------------------------------
         */

        echo '<h3 style="margin-top:30px;">
            گواهینامه‌های دستی
        </h3>';


        $manual_rows =
            $wpdb->get_results(
                "SELECT *
                 FROM " .
                self::table_name() .
                "
                 WHERE course_id IS NULL
                 AND status='issued'
                 ORDER BY issued_at DESC,id DESC
                 LIMIT 500"
            );


        echo '<table class="widefat striped">';

        echo '<thead>
            <tr>
                <th>ID</th>
                <th>دارنده</th>
                <th>کد ملی</th>
                <th>قالب</th>
                <th>کد استعلام</th>
                <th>تاریخ صدور</th>
            </tr>
        </thead>';

        echo '<tbody>';


        foreach (
            $manual_rows
            as $row
        ) {

            $meta =
                self::get_metadata(
                    $row
                );


            echo '<tr>';

            echo '<td>' .
                absint(
                    $row->id
                ) .
                '</td>';

            echo '<td>' .
                esc_html(
                    $meta['student_name']
                    ??
                    '-'
                ) .
                '</td>';

            echo '<td>' .
                esc_html(
                    $row->national_id
                    ??
                    '-'
                ) .
                '</td>';

            echo '<td>' .
                esc_html(
                    $meta['certificate_title']
                    ??
                    '-'
                ) .
                '</td>';

            echo '<td>' .
                esc_html(
                    $row->verification_code
                ) .
                '</td>';

            echo '<td>' .
                esc_html(
                    $row->issued_at
                ) .
                '</td>';

            echo '</tr>';
        }


        if ( ! $manual_rows ) {

            echo '<tr>
                <td colspan="6">
                    هنوز گواهینامه دستی صادر نشده است.
                </td>
            </tr>';
        }


        echo '</tbody>';

        echo '</table>';


        echo '</div>';
    }
}


/**
 * =========================================================
 * BOOT
 * =========================================================
 */

Academy_Site_Certificates::boot();