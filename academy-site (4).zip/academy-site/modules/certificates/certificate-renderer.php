<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Academy_Site_Certificate_Renderer {
    public static function boot() {
        add_filter( 'academy_site_render_map', array( __CLASS__, 'map' ), 10, 3 );
    }
    public static function map( $map, $type, $data ) {
        if ( 'certificate' !== $type ) return $map;
$d = is_array( $data ) ? $data : (array) $data;
        $id = absint( $d['id'] ?? 0 );
        $code = sanitize_text_field( $d['verification_code'] ?? '' );
        $template_title = sanitize_text_field( $d['certificate_title'] ?? '' );
        $student_name = sanitize_text_field( $d['student_name'] ?? '' );
        $national_id = sanitize_text_field( $d['national_id'] ?? '' );
        $issued_at = sanitize_text_field( $d['issued_at'] ?? '' );
        $duration = sanitize_text_field( $d['duration'] ?? '' );
        $date = sanitize_text_field( $d['date'] ?? ( $d['issue_date'] ?? '' ) );
        if ( '' === $date && ! empty( $d['issued_at'] ) ) {
            $date = substr( sanitize_text_field( $d['issued_at'] ), 0, 10 );
        }
        $custom_field = wp_kses_post( $d['custom_field'] ?? '' );
        $template_id = absint( $d['template_id'] ?? 0 );
        $certificate_output = wp_kses_post( $d['certificate-output'] ?? $d['certificate_output'] ?? '' );

        /*
         * Metadata contains the exact issuance values. Do not derive display
         * fields from the course/user because manual certificates may not
         * belong to a WordPress user or course.
         */
        if ( $id && class_exists( 'Academy_Site_Certificates' ) ) {
            $row = Academy_Site_Certificates::get( $id );
            if ( $row ) {
                $meta = Academy_Site_Certificates::get_metadata( $row );
                $student_name = sanitize_text_field( $meta['student_name'] ?? $student_name );
                $national_id  = sanitize_text_field( $meta['national_id'] ?? $national_id );
                $issued_at    = sanitize_text_field( $meta['issued_at'] ?? $issued_at );
                $duration     = sanitize_text_field( $meta['duration'] ?? $duration );
                $date         = sanitize_text_field( $meta['issue_date'] ?? $date );
                $template_id  = absint( $row->template_id ?: $template_id );
            }
        }

        /* The certificate template supplies the stable title/custom field. */
        $template = $template_id && class_exists( 'Academy_Site_Certificates' )
            ? Academy_Site_Certificates::get_template( $template_id )
            : null;

        if ( $template ) {
            $template_title = (string) $template->title;
            $custom_field = (string) $template->custom_field;
        }

        // Render the stored verification text for this exact certificate.
        if ( $id && class_exists( 'Academy_Site_Certificates' ) ) {
            $row = Academy_Site_Certificates::get( $id );
            if ( $row && method_exists( 'Academy_Site_Certificates', 'render_verification_text' ) ) {
                $certificate_output = Academy_Site_Certificates::render_verification_text( $row );

                /*
                 * Final safety fallback: older template records may expose
                 * their text under body_text/verification_text instead of
                 * body_html. The certificate module performs the variable
                 * replacement; this branch only prevents a silent blank.
                 */
                if ( '' === trim( wp_strip_all_tags( (string) $certificate_output ) ) ) {
                    $tpl = $template;
                    if ( $tpl ) {
                        $raw = '';
                        if ( ! empty( $tpl->body_html ) ) {
                            $raw = $tpl->body_html;
                        } elseif ( isset( $tpl->verification_text ) && '' !== (string) $tpl->verification_text ) {
                            $raw = $tpl->verification_text;
                        } elseif ( isset( $tpl->body_text ) && '' !== (string) $tpl->body_text ) {
                            $raw = $tpl->body_text;
                        }

                        if ( '' !== $raw && method_exists( 'Academy_Site_Certificates', 'render_certificate' ) ) {
                            $full = Academy_Site_Certificates::render_certificate( $row );
                            $certificate_output = is_string( $full ) ? $full : $certificate_output;
                        }
                    }
                }
            }
        }

        $verify_url = $code
            ? ( class_exists( 'Academy_Site_QR' )
                ? Academy_Site_QR::certificate_url( $code )
                : add_query_arg( 'certificate', rawurlencode( $code ), home_url( '/' ) ) )
            : '';

        $qr_url = $verify_url && class_exists( 'Academy_Site_QR' )
            ? Academy_Site_QR::image_url( $verify_url, 220 )
            : '';

        $qr_html = $verify_url && class_exists( 'Academy_Site_QR' )
            ? Academy_Site_QR::image_html( $verify_url, 'academy-certificate-qr', 'QR گواهینامه', 220 )
            : '';

        return array(
            'student-name'   => esc_html( $student_name ),
            'national-id'    => esc_html( $national_id ),
            'date'           => esc_html( $date ?: $issued_at ),
            'duration'       => esc_html( $duration ),
            'template-title' => esc_html( $template_title ),
            'custom-field'   => wp_kses_post( $custom_field ),
            'certificate-output' => $certificate_output,
            'certificate_output' => $certificate_output,
            'verification-text' => $certificate_output,
            'verification_text' => $certificate_output,
            'certificate-qr' => $qr_html,
            'certificate-qr-url' => esc_url( $qr_url ),
            'certificate-url' => esc_url( $verify_url ),
            'certificate-code' => esc_html( $code ),
            'certificate-id' => (string) $id,
        );
    }
}
Academy_Site_Certificate_Renderer::boot();
