<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Academy Commerce — independent order/payment layer.
 * ZarinPal is an adapter; Courses/Events never call the gateway directly.
 */
final class Academy_Site_Commerce {
    const ORDERS = 'academy_orders';
    const TRANSACTIONS = 'academy_payment_transactions';
    const SETTINGS = 'academy_commerce_';

    public static function boot() {
        add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ), 40 );
        add_action( 'template_redirect', array( __CLASS__, 'maybe_handle_checkout' ), 1 );
        add_filter( 'academy_site_dynamic_data', array( __CLASS__, 'dynamic_data' ), 60, 2 );
        add_action( 'academy_site_payment_success', array( __CLASS__, 'after_paid' ), 10, 1 );
    }

    public static function install() {
        global $wpdb; require_once ABSPATH . 'wp-admin/includes/upgrade.php'; $c=$wpdb->get_charset_collate();
        dbDelta( "CREATE TABLE {$wpdb->prefix}" . self::ORDERS . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, user_id BIGINT UNSIGNED NOT NULL, item_type VARCHAR(30) NOT NULL,
            item_id BIGINT UNSIGNED NOT NULL, quantity INT UNSIGNED NOT NULL DEFAULT 1, amount DECIMAL(20,2) NOT NULL,
            currency VARCHAR(10) NOT NULL DEFAULT 'IRT', status VARCHAR(20) NOT NULL DEFAULT 'pending', authority VARCHAR(100) NULL,
            reference_id VARCHAR(190) NULL, metadata LONGTEXT NULL, created_at DATETIME NOT NULL, paid_at DATETIME NULL,
            PRIMARY KEY(id), UNIQUE KEY authority(authority), KEY user_status(user_id,status), KEY item(item_type,item_id), KEY created_at(created_at)
        ) {$c};" );
        dbDelta( "CREATE TABLE {$wpdb->prefix}" . self::TRANSACTIONS . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, order_id BIGINT UNSIGNED NOT NULL, gateway VARCHAR(40) NOT NULL,
            authority VARCHAR(100) NULL, reference_id VARCHAR(190) NULL, status VARCHAR(20) NOT NULL DEFAULT 'initiated',
            response_code VARCHAR(50) NULL, response_message TEXT NULL, raw_response LONGTEXT NULL, created_at DATETIME NOT NULL,
            verified_at DATETIME NULL, PRIMARY KEY(id), KEY order_status(order_id,status), KEY authority(authority), KEY created_at(created_at)
        ) {$c};" );
    }

    public static function settings() {
        return array(
            'merchant_id' => trim( (string) get_option( self::SETTINGS . 'merchant_id', '' ) ),
            'sandbox' => (bool) get_option( self::SETTINGS . 'sandbox', false ),
            'currency' => strtoupper( sanitize_text_field( get_option( self::SETTINGS . 'currency', 'IRT' ) ) ),
        );
    }

    public static function admin_menu() {
        add_options_page( 'Academy Payment', 'Academy Payment', 'manage_options', 'academy-site-payment', array( __CLASS__, 'settings_page' ) );
    }

    public static function settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        if ( isset( $_POST['academy_payment_save'] ) ) {
            check_admin_referer( 'academy_payment_settings' );
            update_option( self::SETTINGS . 'merchant_id', sanitize_text_field( wp_unslash( $_POST['merchant_id'] ?? '' ) ) );
            update_option( self::SETTINGS . 'sandbox', ! empty( $_POST['sandbox'] ) ? 1 : 0 );
            update_option( self::SETTINGS . 'currency', sanitize_key( $_POST['currency'] ?? 'IRT' ) );
            echo '<div class="notice notice-success"><p>تنظیمات پرداخت ذخیره شد.</p></div>';
        }
        $s=self::settings();
        echo '<div class="wrap"><h1>پرداخت Academy</h1><p>درگاه مستقل از دوره و همایش است. Merchant ID فقط اینجا نگهداری می‌شود.</p><form method="post">'; wp_nonce_field('academy_payment_settings');
        echo '<table class="form-table"><tr><th>Merchant ID زرین‌پال</th><td><input class="regular-text" name="merchant_id" value="'.esc_attr($s['merchant_id']).'" autocomplete="off"></td></tr><tr><th>حالت تست</th><td><label><input type="checkbox" name="sandbox" value="1" '.checked($s['sandbox'],true,false).'> Sandbox</label></td></tr><tr><th>واحد داخلی</th><td><select name="currency"><option value="IRT" '.selected($s['currency'],'IRT',false).'>تومان</option><option value="IRR" '.selected($s['currency'],'IRR',false).'>ریال</option></select></td></tr></table><p><button class="button button-primary" name="academy_payment_save" value="1">ذخیره</button></p></form></div>';
    }

    public static function purchase_url( $type, $id ) {
        return add_query_arg( array( 'academy_checkout' => 1, 'item_type' => sanitize_key($type), 'item_id' => absint($id) ), home_url('/') );
    }

    public static function amount_for( $type, $id ) {
        if ( 'course' === $type ) {
            if ( class_exists('Academy_Site_WooCommerce') && function_exists('wc_get_product') ) {
                foreach ( Academy_Site_WooCommerce::get_products_for_course($id) as $pid ) { $p=wc_get_product($pid); if($p) return max(0,(float)$p->get_price()); }
            }
            return (float)get_post_meta($id,'_academy_course_price',true);
        }
        if ( 'event_ticket' === $type && class_exists('Academy_Site_Events') ) { $t=Academy_Site_Events::get_ticket($id); return $t?(float)$t->price:0; }
        return 0;
    }

    public static function create_order( $user_id, $type, $id, $amount, $metadata=array() ) {
        global $wpdb; $user_id=absint($user_id);$type=sanitize_key($type);$id=absint($id);$amount=(float)$amount;
        if(!$user_id||!get_userdata($user_id)||!$id||$amount<0)return new WP_Error('invalid_order','اطلاعات سفارش معتبر نیست.');
        $ok=$wpdb->insert($wpdb->prefix.self::ORDERS,array('user_id'=>$user_id,'item_type'=>$type,'item_id'=>$id,'amount'=>number_format($amount,2,'.',''),'currency'=>self::settings()['currency'],'status'=>'pending','metadata'=>wp_json_encode($metadata,JSON_UNESCAPED_UNICODE),'created_at'=>current_time('mysql',true)),array('%d','%s','%d','%s','%s','%s','%s','%s'));
        return false===$ok?new WP_Error('order_create_failed','ثبت سفارش ناموفق بود.'):(int)$wpdb->insert_id;
    }

    private static function rial_amount( $amount ) { return 'IRT'===self::settings()['currency'] ? (int)round($amount*10) : (int)round($amount); }

    public static function request_zarinpal( $order_id ) {
        global $wpdb; $order=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.$wpdb->prefix.self::ORDERS.' WHERE id=%d LIMIT 1',absint($order_id))); if(!$order)return new WP_Error('order_not_found','سفارش پیدا نشد.');
        $merchant=self::settings()['merchant_id']; if(!$merchant)return new WP_Error('merchant_missing','Merchant ID زرین‌پال در تنظیمات وارد نشده است.');
        $callback=add_query_arg(array('academy_payment_callback'=>1),home_url('/'));
        $body=array('merchant_id'=>$merchant,'amount'=>self::rial_amount($order->amount),'description'=>'Academy Order #'.$order->id,'callback_url'=>$callback,'metadata'=>array('mobile'=>get_user_meta($order->user_id,'academy_phone',true),'order_id'=>(string)$order->id));
        $endpoint='https://payment.zarinpal.com/pg/v4/payment/request.json';
        $response=wp_remote_post($endpoint,array('timeout'=>25,'headers'=>array('Content-Type'=>'application/json','Accept'=>'application/json'),'body'=>wp_json_encode($body,JSON_UNESCAPED_UNICODE)));
        if(is_wp_error($response))return new WP_Error('zarinpal_http',$response->get_error_message());
        $raw=wp_remote_retrieve_body($response);$data=json_decode($raw,true);$code=(string)($data['data']['code']??'');
        if('100'!==$code)return new WP_Error('zarinpal_request_failed','زرین‌پال درخواست پرداخت را نپذیرفت.',array('response'=>$data));
        $authority=sanitize_text_field($data['data']['authority']??''); if(!$authority)return new WP_Error('zarinpal_no_authority','زرین‌پال Authority برنگرداند.');
        $wpdb->update($wpdb->prefix.self::ORDERS,array('authority'=>$authority),array('id'=>$order->id),array('%s'),array('%d'));
        $wpdb->insert($wpdb->prefix.self::TRANSACTIONS,array('order_id'=>$order->id,'gateway'=>'zarinpal','authority'=>$authority,'status'=>'initiated','response_code'=>$code,'raw_response'=>$raw,'created_at'=>current_time('mysql',true)),array('%d','%s','%s','%s','%s','%s'));
        return 'https://www.zarinpal.com/pg/StartPay/'.$authority;
    }

    public static function verify_zarinpal( $authority, $status ) {
        global $wpdb; $authority=sanitize_text_field($authority);$order=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.$wpdb->prefix.self::ORDERS.' WHERE authority=%s LIMIT 1',$authority));
        if(!$order)return new WP_Error('order_not_found','سفارش پرداخت پیدا نشد.');
        if('paid'===$order->status)return $order;
        if('OK'!==strtoupper($status))return new WP_Error('payment_cancelled','پرداخت توسط کاربر لغو شد.');
        $merchant=self::settings()['merchant_id']; if(!$merchant)return new WP_Error('merchant_missing','Merchant ID تنظیم نشده است.');
        $body=array('merchant_id'=>$merchant,'amount'=>self::rial_amount($order->amount),'authority'=>$authority);
        $response=wp_remote_post('https://payment.zarinpal.com/pg/v4/payment/verify.json',array('timeout'=>25,'headers'=>array('Content-Type'=>'application/json','Accept'=>'application/json'),'body'=>wp_json_encode($body)));
        if(is_wp_error($response))return new WP_Error('zarinpal_verify_http',$response->get_error_message());
        $raw=wp_remote_retrieve_body($response);$data=json_decode($raw,true);$code=(string)($data['data']['code']??'');
        if(!in_array($code,array('100','101'),true))return new WP_Error('zarinpal_verify_failed','تأیید پرداخت توسط زرین‌پال ناموفق بود.',array('response'=>$data));
        $ref=sanitize_text_field((string)($data['data']['ref_id']??$data['data']['card_pan']??''));
        $wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}".self::ORDERS." SET status='paid', reference_id=%s, paid_at=%s WHERE id=%d AND status<>'paid'",$ref,current_time('mysql',true),$order->id));
        $wpdb->update($wpdb->prefix.self::TRANSACTIONS,array('status'=>'verified','reference_id'=>$ref,'response_code'=>$code,'raw_response'=>$raw,'verified_at'=>current_time('mysql',true)),array('authority'=>$authority),array('%s','%s','%s','%s','%s'),array('%s'));
        $fresh=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.$wpdb->prefix.self::ORDERS.' WHERE id=%d',$order->id)); do_action('academy_site_payment_success',$fresh); return $fresh;
    }

    public static function after_paid( $order ) {
        if(!$order)return; $uid=absint($order->user_id);$type=$order->item_type;$id=absint($order->item_id);
        if('course'===$type && class_exists('Academy_Site_Enrollment')) Academy_Site_Enrollment::grant_from_payment($uid,$id,(string)$order->id,'academy_commerce');
        if('event_ticket'===$type && class_exists('Academy_Site_Events')) Academy_Site_Events::create_registration_from_commerce($uid,$id,$order->id,$order->metadata);
        do_action('academy_site_commerce_order_paid',$order);
    }

    public static function maybe_handle_checkout() {
        if(isset($_GET['academy_payment_callback'])) { $result=self::verify_zarinpal($_GET['Authority']??'',$_GET['Status']??''); $url=home_url('/'); $url=add_query_arg('academy_payment',is_wp_error($result)?'failed':'success',$url); wp_safe_redirect($url); exit; }
        $is_checkout = ! empty( $_GET['academy_checkout'] ) || ! empty( $_POST['academy_checkout'] );
        if ( ! $is_checkout ) return;
        if ( ! is_user_logged_in() ) { $login = get_option( 'academy_site_login_url', home_url('/login/') ); $login = add_query_arg( 'academy_return_to', rawurlencode( home_url( wp_unslash( $_SERVER['REQUEST_URI'] ?? '/' ) ) ), $login ); wp_safe_redirect( $login ); exit; }
        $type = sanitize_key( $_REQUEST['item_type'] ?? '' );
        $id = absint( $_REQUEST['item_id'] ?? 0 );
        $amount = self::amount_for( $type, $id );
        if ( ! $amount ) wp_die( 'مبلغ سفارش معتبر نیست.' );
        if ( 'course' === $type && class_exists('Academy_Site_Enrollment') && Academy_Site_Enrollment::has_access( get_current_user_id(), $id ) ) wp_die( 'این دوره قبلاً برای شما فعال شده است.' );
        $metadata = array();
        if ( 'event_ticket' === $type ) {
            $metadata = array(
                'first_name' => sanitize_text_field( wp_unslash( $_POST['first_name'] ?? '' ) ),
                'last_name' => sanitize_text_field( wp_unslash( $_POST['last_name'] ?? '' ) ),
                'national_id' => sanitize_text_field( wp_unslash( $_POST['national_id'] ?? '' ) ),
                'mobile' => sanitize_text_field( wp_unslash( $_POST['mobile'] ?? '' ) ),
                'organization' => sanitize_text_field( wp_unslash( $_POST['organization'] ?? '' ) ),
            );
            if ( ! $metadata['first_name'] || ! $metadata['last_name'] || ! $metadata['national_id'] || ! $metadata['mobile'] ) wp_die( 'اطلاعات اجباری بلیت را کامل کنید.' );
        }
        $order = self::create_order( get_current_user_id(), $type, $id, $amount, $metadata ); if ( is_wp_error($order) ) wp_die( esc_html($order->get_error_message()) );
        $url=self::request_zarinpal($order);if(is_wp_error($url))wp_die(esc_html($url->get_error_message()));wp_safe_redirect($url);exit;
    }

    public static function dynamic_data($data) {
        if(is_user_logged_in()&&class_exists('Academy_Site_Wallet')){
            $data['academy_payment_url']=self::purchase_url('course',get_the_ID());
            $data['student_orders']=self::user_orders(get_current_user_id());
        }
        return $data;
    }

    public static function user_orders($uid){global $wpdb;return $wpdb->get_results($wpdb->prepare('SELECT * FROM '.$wpdb->prefix.self::ORDERS.' WHERE user_id=%d ORDER BY id DESC LIMIT 100',absint($uid)));}
}
Academy_Site_Commerce::boot();
