<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
require_once __DIR__ . '/class-commerce.php';
Academy_Site_Commerce::boot();
