<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Central SMS gateway. All Academy modules call this class; no module talks to
 * the provider directly. Current adapter: SMS.ir verify/template API.
 */
final class Academy_Site_SMS {
    const LOG_TABLE = 'academy_sms_logs';
    const SETTINGS_PREFIX = 'academy_sms_';

    const TEMPLATES = array(
        'login_otp'           => 'کد یکبارمصرف ورود',
        'register_otp'        => 'کد یکبارمصرف ثبت‌نام',
        'welcome_student'    => 'خوش‌آمدگویی دانشجو',
        'recovery_otp'        => 'کد بازیابی / تغییر رمز',
        'birthday'            => 'تبریک تولد',
        'consultation'        => 'ثبت درخواست مشاوره',
        'consultation_admin' => 'اعلام درخواست مشاوره به مشاور',
        'support'             => 'ثبت درخواست پشتیبانی',
        'event_registration'  => 'ثبت‌نام همایش',
        'course_purchase'     => 'خرید دوره',
        'course_completed'    => 'تکمیل دوره',
        'certificate'         => 'صدور گواهینامه',
        'crm_campaign'        => 'کمپین CRM',
        'custom'              => 'قالب سفارشی',
    );

    /**
     * Parameters allowed for each SMS.ir template.
     * Keeping the payload limited to the template's expected variables prevents
     * provider rejection caused by unrelated parameters.
     */
    /**
     * SMS.ir template variables supported by Academy.
     *
     * IMPORTANT:
     * We do not bind a fixed variable list to each Template ID. The admin only
     * enters the Template ID. Academy builds the values it actually knows and
     * sends every non-empty supported variable, so changing the text/template
     * does not require editing PHP.
     *
     * These names match the variable names shown by SMS.ir (without #...#).
     */
    /*
     * Universal SMS.ir variable dictionary.
     *
     * The gateway itself does not know what variables exist inside a Template ID.
     * Academy therefore keeps a broad, reusable dictionary and supplies values
     * only when they are actually available. Template-specific values can be
     * passed by any module without changing this gateway.
     */
    const TEMPLATE_VARIABLES = array(
        'CODE','OTP','TOKEN','VERIFICATIONCODE',
        'NAME','FULLNAME','FIRSTNAME','LASTNAME','USERNAME','PHONE',
        'GENDER','PROVINCE','CITY','BIRTHDATE','AGE',
        'DATE','TIME','DATETIME','YEAR','MONTH','DAY',
        'TITLE','SUBJECT','STATUS','MESSAGE','DESCRIPTION',
        'LINK','URL',
        'AMOUNT','PRICE','BALANCE','WALLETBALANCE','DISCOUNT','TOTAL',
        'ORDERID','ORDERNUMBER','ORDER_NUMBER','TRANSACTIONID','TRACKINGCODE',
        'ITEMSCOUNT','ITEMS_COUNT',
        'COURSENAME','COURSEID','COURSESTATUS',
        'EVENTNAME','EVENTID','EVENTDATE','EVENTTIME','EVENTLOCATION',
        'TICKETTYPE','TICKETNAME','TICKETCODE','ENTRYCODE','CAPACITY',
        'CERTIFICATENUMBER','CERTIFICATEID','CERTIFICATENAME',
        'CONSULTATIONTYPE','CONSULTANTNAME','REQUESTTYPE','REQUESTID',
        'SUPPORTTYPE','TICKETID',
        'CAMPAIGN','CAMPAIGNID',
        'WALLETAMOUNT','WALLETEXPIRY','EXPIRYDATE','EXPIRESAT',
        'QUANTITY','REFERENCE','PAYMENTSTATUS'
    );

    /*
     * Accept the names developers naturally use and normalize them to the
     * names used by the SMS.ir template. The important OTP mapping is:
     * Code/OTP/Token -> VERIFICATIONCODE.
     */
    const VARIABLE_ALIASES = array(
        'Code'=>'CODE','CODE'=>'CODE',
        'Otp'=>'OTP','OTP'=>'OTP',
        'Token'=>'TOKEN','TOKEN'=>'TOKEN',
        'VerificationCode'=>'VERIFICATIONCODE','VERIFICATIONCODE'=>'VERIFICATIONCODE',

        'Name'=>'NAME','NAME'=>'NAME',
        'FullName'=>'FULLNAME','FULLNAME'=>'FULLNAME',
        'FirstName'=>'FIRSTNAME','FIRSTNAME'=>'FIRSTNAME',
        'LastName'=>'LASTNAME','LASTNAME'=>'LASTNAME',
        'Username'=>'USERNAME','USERNAME'=>'USERNAME',
        'Phone'=>'PHONE','PHONE'=>'PHONE',

        'Gender'=>'GENDER','GENDER'=>'GENDER',
        'Province'=>'PROVINCE','PROVINCE'=>'PROVINCE',
        'City'=>'CITY','CITY'=>'CITY',
        'BirthDate'=>'BIRTHDATE','BIRTHDATE'=>'BIRTHDATE',
        'Age'=>'AGE','AGE'=>'AGE',

        'Date'=>'DATE','DATE'=>'DATE',
        'Time'=>'TIME','TIME'=>'TIME',
        'DateTime'=>'DATETIME','DATETIME'=>'DATETIME',
        'Year'=>'YEAR','YEAR'=>'YEAR',
        'Month'=>'MONTH','MONTH'=>'MONTH',
        'Day'=>'DAY','DAY'=>'DAY',

        'Title'=>'TITLE','TITLE'=>'TITLE',
        'Subject'=>'SUBJECT','SUBJECT'=>'SUBJECT',
        'Status'=>'STATUS','STATUS'=>'STATUS',
        'Message'=>'MESSAGE','MESSAGE'=>'MESSAGE',
        'Description'=>'DESCRIPTION','DESCRIPTION'=>'DESCRIPTION',

        'Link'=>'LINK','LINK'=>'LINK',
        'Url'=>'URL','URL'=>'URL',

        'Amount'=>'AMOUNT','AMOUNT'=>'AMOUNT',
        'Price'=>'PRICE','PRICE'=>'PRICE',
        'Balance'=>'BALANCE','BALANCE'=>'BALANCE',
        'WalletBalance'=>'WALLETBALANCE','WALLETBALANCE'=>'WALLETBALANCE',
        'Discount'=>'DISCOUNT','DISCOUNT'=>'DISCOUNT',
        'Total'=>'TOTAL','TOTAL'=>'TOTAL',

        'OrderId'=>'ORDERID','ORDERID'=>'ORDERID',
        'OrderNumber'=>'ORDERNUMBER','ORDERNUMBER'=>'ORDERNUMBER',
        'ORDER_NUMBER'=>'ORDER_NUMBER',
        'TransactionId'=>'TRANSACTIONID','TRANSACTIONID'=>'TRANSACTIONID',
        'TrackingCode'=>'TRACKINGCODE','TRACKINGCODE'=>'TRACKINGCODE',
        'ItemsCount'=>'ITEMSCOUNT','ITEMSCOUNT'=>'ITEMSCOUNT',
        'ITEMS_COUNT'=>'ITEMS_COUNT',

        'CourseName'=>'COURSENAME','COURSENAME'=>'COURSENAME',
        'CourseId'=>'COURSEID','COURSEID'=>'COURSEID',
        'CourseStatus'=>'COURSESTATUS','COURSESTATUS'=>'COURSESTATUS',

        'EventName'=>'EVENTNAME','EVENTNAME'=>'EVENTNAME',
        'EventId'=>'EVENTID','EVENTID'=>'EVENTID',
        'EventDate'=>'EVENTDATE','EVENTDATE'=>'EVENTDATE',
        'EventTime'=>'EVENTTIME','EVENTTIME'=>'EVENTTIME',
        'EventLocation'=>'EVENTLOCATION','EVENTLOCATION'=>'EVENTLOCATION',
        'TicketType'=>'TICKETTYPE','TICKETTYPE'=>'TICKETTYPE',
        'TicketName'=>'TICKETNAME','TICKETNAME'=>'TICKETNAME',
        'TicketCode'=>'TICKETCODE','TICKETCODE'=>'TICKETCODE',
        'EntryCode'=>'ENTRYCODE','ENTRYCODE'=>'ENTRYCODE',
        'Capacity'=>'CAPACITY','CAPACITY'=>'CAPACITY',

        'CertificateNumber'=>'CERTIFICATENUMBER','CERTIFICATENUMBER'=>'CERTIFICATENUMBER',
        'CertificateId'=>'CERTIFICATEID','CERTIFICATEID'=>'CERTIFICATEID',
        'CertificateName'=>'CERTIFICATENAME','CERTIFICATENAME'=>'CERTIFICATENAME',

        'ConsultationType'=>'CONSULTATIONTYPE','CONSULTATIONTYPE'=>'CONSULTATIONTYPE',
        'ConsultantName'=>'CONSULTANTNAME','CONSULTANTNAME'=>'CONSULTANTNAME',
        'RequestType'=>'REQUESTTYPE','REQUESTTYPE'=>'REQUESTTYPE',
        'RequestId'=>'REQUESTID','REQUESTID'=>'REQUESTID',
        'SupportType'=>'SUPPORTTYPE','SUPPORTTYPE'=>'SUPPORTTYPE',
        'TicketId'=>'TICKETID','TICKETID'=>'TICKETID',

        'Campaign'=>'CAMPAIGN','CAMPAIGN'=>'CAMPAIGN',
        'CampaignId'=>'CAMPAIGNID','CAMPAIGNID'=>'CAMPAIGNID',

        'WalletAmount'=>'WALLETAMOUNT','WALLETAMOUNT'=>'WALLETAMOUNT',
        'WalletExpiry'=>'WALLETEXPIRY','WALLETEXPIRY'=>'WALLETEXPIRY',
        'ExpiryDate'=>'EXPIRYDATE','EXPIRYDATE'=>'EXPIRYDATE',
        'ExpiresAt'=>'EXPIRESAT','EXPIRESAT'=>'EXPIRESAT',

        'Quantity'=>'QUANTITY','QUANTITY'=>'QUANTITY',
        'Reference'=>'REFERENCE','REFERENCE'=>'REFERENCE',
        'PaymentStatus'=>'PAYMENTSTATUS','PAYMENTSTATUS'=>'PAYMENTSTATUS',
    );

    public static function boot() {
        add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ), 30 );
        add_action( 'admin_post_academy_sms_test', array( __CLASS__, 'handle_test' ) );
        add_action( 'academy_site_birthday_scheduler', array( __CLASS__, 'send_birthday_messages' ) );
        add_action( 'academy_site_student_registered', array( __CLASS__, 'on_student_registered' ), 20, 1 );
        add_action( 'academy_site_course_completed', array( __CLASS__, 'on_course_completed' ), 20, 2 );
        add_action( 'academy_site_certificate_issued', array( __CLASS__, 'on_certificate_issued' ), 20, 1 );
        add_action( 'academy_site_event_registration_created', array( __CLASS__, 'on_event_registration' ), 20, 2 );
        add_action( 'woocommerce_payment_complete', array( __CLASS__, 'on_payment_complete' ), 30 );
        add_action( 'woocommerce_order_status_processing', array( __CLASS__, 'on_payment_complete' ), 30 );
        add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'on_payment_complete' ), 30 );
        if ( ! wp_next_scheduled( 'academy_site_birthday_scheduler' ) ) { wp_schedule_event( time() + 600, 'daily', 'academy_site_birthday_scheduler' ); }
    }

    public static function table() {
        global $wpdb;
        return $wpdb->prefix . self::LOG_TABLE;
    }

    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        dbDelta( "CREATE TABLE " . self::table() . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NULL,
            campaign_id BIGINT UNSIGNED NULL,
            phone VARCHAR(32) NOT NULL,
            purpose VARCHAR(50) NOT NULL DEFAULT 'custom',
            template_key VARCHAR(80) NULL,
            template_id VARCHAR(80) NULL,
            idempotency_key VARCHAR(190) NULL,
            provider VARCHAR(50) NOT NULL DEFAULT 'sms_ir',
            status VARCHAR(20) NOT NULL DEFAULT 'queued',
            provider_message_id VARCHAR(190) NULL,
            provider_status_code VARCHAR(50) NULL,
            error_code VARCHAR(100) NULL,
            error_message TEXT NULL,
            metadata LONGTEXT NULL,
            sent_at DATETIME NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY user_created (user_id,created_at),
            KEY campaign_status (campaign_id,status),
            KEY phone_created (phone,created_at),
            KEY template_status (template_key,status), KEY idempotency_key (idempotency_key)
        ) $charset;" );
    }

    public static function normalize_phone( $phone ) {
        $phone = trim( (string) $phone );
        $phone = str_replace( array( ' ', '-', '(', ')' ), '', $phone );
        if ( strpos( $phone, '00' ) === 0 ) {
            $phone = '+' . substr( $phone, 2 );
        }
        // Iranian mobile numbers: 09xxxxxxxxx -> +989xxxxxxxxx.
        if ( preg_match( '/^09\d{9}$/', $phone ) ) {
            $phone = '+98' . substr( $phone, 1 );
        } elseif ( preg_match( '/^9\d{9}$/', $phone ) ) {
            $phone = '+98' . $phone;
        } elseif ( preg_match( '/^98\d{10}$/', ltrim( $phone, '+' ) ) ) {
            $phone = '+' . ltrim( $phone, '+' );
        }
        return preg_replace( '/[^0-9+]/', '', $phone );
    }

    public static function get_api_key() { return trim( (string) get_option( self::SETTINGS_PREFIX . 'api_key', '' ) ); }
    public static function get_template_id( $key ) { return trim( (string) get_option( self::SETTINGS_PREFIX . 'template_' . sanitize_key( $key ), '' ) ); }
    public static function enabled() { return (bool) self::get_api_key(); }

    public static function template_key_for_purpose( $purpose ) {
        $map = array(
            'login_otp' => 'login_otp', 'register_otp' => 'register_otp', 'welcome_student' => 'welcome_student', 'otp' => 'login_otp',
            'recovery_otp' => 'recovery_otp', 'birthday' => 'birthday', 'consultation' => 'consultation',
            'support' => 'support', 'event_registration' => 'event_registration', 'course_purchase' => 'course_purchase',
            'course_completed' => 'course_completed', 'certificate' => 'certificate', 'crm_campaign' => 'crm_campaign',
        );
        return $map[ sanitize_key( $purpose ) ] ?? 'custom';
    }

    /** Send a configured template. $parameters = array('Code'=>'1234'). */
    public static function send_template( $user_id, $template_key, $parameters = array(), $args = array() ) {
        $user_id = absint( $user_id );
        $user = $user_id ? get_user_by( 'id', $user_id ) : false;
        $phone = self::normalize_phone( $args['phone'] ?? ( $user ? ( get_user_meta( $user_id, 'academy_phone', true ) ?: get_user_meta( $user_id, 'mobile', true ) ) : '' ) );
        if ( ! $phone ) return new WP_Error( 'sms_no_phone', 'شماره موبایل موجود نیست.' );
        $template_key = sanitize_key( $template_key );
        if ( ! isset( self::TEMPLATES[ $template_key ] ) ) return new WP_Error( 'sms_template_invalid', 'نوع قالب پیامک معتبر نیست.' );
        $template_id = ! empty( $args['template_id'] ) ? preg_replace( '/[^0-9]/', '', (string) $args['template_id'] ) : self::get_template_id( $template_key );
        if ( '' === $template_id ) return new WP_Error( 'sms_template_missing', 'شناسه قالب پیامک برای «' . self::TEMPLATES[ $template_key ] . '» در تنظیمات وارد نشده است.' );
        // Merge the caller's values with the universal values available from the
        // student/order/event context. Empty values are omitted, so a template
        // that only contains #CODE# receives only CODE.
        $parameters = self::build_universal_parameters( $user_id, $parameters );

        // OTP compatibility: SMS.ir template variables are defined by the
        // template itself. Different templates may use #CODE#, #OTP#,
        // #TOKEN# or #VERIFICATIONCODE#. When a module supplies one OTP value,
        // expose the same value under all supported OTP variable names.
        // This keeps the login/register code independent from the exact
        // variable name chosen inside the SMS.ir template.
        $otp_value = '';
        foreach ( array( 'VERIFICATIONCODE', 'VerificationCode', 'CODE', 'Code', 'OTP', 'Token', 'TOKEN' ) as $otp_key ) {
            if ( isset( $parameters[ $otp_key ] ) && '' !== trim( (string) $parameters[ $otp_key ] ) ) {
                $otp_value = (string) $parameters[ $otp_key ];
                break;
            }
        }
        if ( '' !== $otp_value ) {
            $parameters['VERIFICATIONCODE'] = $otp_value;
            $parameters['CODE'] = $otp_value;
            $parameters['OTP'] = $otp_value;
            $parameters['TOKEN'] = $otp_value;
        }

        $parameters = self::sanitize_parameters( $parameters );
        if ( ! empty( $args['idempotency_key'] ) ) { global $wpdb; $exists = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::table() . " WHERE idempotency_key=%s AND status='sent' LIMIT 1", sanitize_text_field( $args['idempotency_key'] ) ) ); if ( $exists ) return array( 'message_id' => '', 'provider' => 'sms_ir', 'template_id' => $template_id, 'duplicate' => true ); }
        return self::dispatch( $user_id, $phone, $template_key, $template_id, $parameters, $args );
    }

    public static function send_phone( $phone, $message, $args = array() ) {
        // Kept for backwards compatibility. New code should use send_template().
        $template_key = self::template_key_for_purpose( $args['purpose'] ?? 'custom' );
        $params = array();
        if ( ! empty( $args['code'] ) ) $params['Code'] = (string) $args['code'];
        if ( ! empty( $args['parameters'] ) && is_array( $args['parameters'] ) ) $params = array_merge( $params, $args['parameters'] );
        return self::send_template( absint( $args['user_id'] ?? 0 ), $template_key, $params, array_merge( $args, array( 'phone' => $phone ) ) );
    }

    public static function send( $user_id, $message, $args = array() ) {
        // Backwards compatibility for campaigns. The configured CRM template is used;
        // arbitrary message text is never sent to SMS.ir's template endpoint.
        $params = array();
        if ( ! empty( $args['parameters'] ) && is_array( $args['parameters'] ) ) $params = $args['parameters'];
        // SMS.ir verify/template messages do not accept arbitrary message text.
        // The actual text lives inside the configured Template ID.
        return self::send_template( absint( $user_id ), $args['template_key'] ?? 'crm_campaign', $params, $args );
    }

    /**
     * Build a universal parameter bag from user data + explicit event values.
     * Explicit values win. This means modules can add a value such as LINK,
     * EVENTNAME or ORDERID without touching the SMS gateway code.
     */
    private static function build_universal_parameters( $user_id, $parameters = array() ) {
        $out = array();
        $user_id = absint( $user_id );
        $u = $user_id ? get_userdata( $user_id ) : false;

        if ( $u ) {
            $first = trim( (string) ( $u->first_name ?: $u->display_name ) );
            $last  = trim( (string) $u->last_name );
            $full  = trim( (string) ( $u->display_name ?: trim( $first . ' ' . $last ) ) );
            $phone = self::normalize_phone(
                get_user_meta( $user_id, 'academy_phone', true ) ?: get_user_meta( $user_id, 'mobile', true )
            );

            $out = array(
                'FIRSTNAME' => $first,
                'LASTNAME' => $last,
                'NAME' => $full,
                'FULLNAME' => $full,
                'USERNAME' => (string) $u->user_login,
                'PHONE' => $phone,
                'GENDER' => (string) get_user_meta( $user_id, 'gender', true ),
                'PROVINCE' => (string) get_user_meta( $user_id, 'province', true ),
                'CITY' => (string) get_user_meta( $user_id, 'city', true ),
                'BIRTHDATE' => (string) get_user_meta( $user_id, 'birth_date', true ),
                'DATE' => current_time( 'Y-m-d' ),
                'TIME' => current_time( 'H:i' ),
                'DATETIME' => current_time( 'Y-m-d H:i:s' ),
            );

            $birth = get_user_meta( $user_id, 'birth_date', true );
            $age = self::calculate_age( $birth );
            if ( null !== $age ) $out['AGE'] = (string) $age;
        }

        // Explicit module values override generic user values.
        if ( is_array( $parameters ) ) {
            foreach ( $parameters as $name => $value ) {
                $canonical = self::canonical_variable_name( $name );
                if ( '' === $canonical ) continue;
                $out[ $canonical ] = $value;
            }
        }

        return $out;
    }

    private static function calculate_age( $birth_date ) {
        $birth_date = trim( (string) $birth_date );
        if ( '' === $birth_date ) return null;

        if ( preg_match( '/^((?:13|14)\\d{2})[\\/\\-](\\d{1,2})[\\/\\-](\\d{1,2})$/', $birth_date, $m ) ) {
            $gy = (int) $m[1] - 621;
            $birthday = sprintf( '%04d-%02d-%02d', $gy, (int) $m[2], (int) $m[3] );
        } else {
            $birthday = str_replace( '/', '-', $birth_date );
        }

        $ts = strtotime( $birthday );
        if ( ! $ts ) return null;
        $now = current_time( 'timestamp' );
        return max( 0, (int) floor( ( $now - $ts ) / YEAR_IN_SECONDS ) );
    }

    private static function canonical_variable_name( $name ) {
        $name = trim( (string) $name );
        if ( '' === $name ) return '';
        $name = trim( $name, " #\\t\\r\\n" );

        if ( isset( self::VARIABLE_ALIASES[ $name ] ) ) {
            return self::VARIABLE_ALIASES[ $name ];
        }

        $upper = strtoupper( preg_replace( '/[^A-Za-z0-9_]/', '', $name ) );
        if ( in_array( $upper, self::TEMPLATE_VARIABLES, true ) ) return $upper;

        return '';
    }

    /**
     * Convert the parameter bag to SMS.ir's name/value format.
     *
     * We deliberately do NOT maintain a per-template whitelist. The Template
     * ID is the only template-specific setting. Empty values are removed.
     */
    private static function sanitize_parameters( $parameters ) {
        $out = array();
        if ( ! is_array( $parameters ) ) return $out;

        foreach ( $parameters as $name => $value ) {
            $name = self::canonical_variable_name( $name );
            if ( '' === $name ) continue;

            $value = trim( wp_strip_all_tags( (string) $value ) );
            if ( '' === $value ) continue;

            $out[] = array(
                'name'  => $name,
                'value' => $value,
            );
        }
        return $out;
    }

    private static function dispatch( $user_id, $phone, $template_key, $template_id, $parameters, $args ) {
        $payload = array(
            'user_id' => $user_id,
            'phone' => $phone,
            'purpose' => $template_key,
            'template_key' => $template_key,
            'template_id' => $template_id,
            'parameters' => $parameters,
            'campaign_id' => absint( $args['campaign_id'] ?? 0 ),
            'idempotency_key' => sanitize_text_field( $args['idempotency_key'] ?? '' ),
            'provider' => 'sms_ir',
        );
        $result = self::sms_ir_request( $template_id, $phone, $parameters );
        if ( is_wp_error( $result ) ) {
            self::log( $payload, 'failed', $result->get_error_message(), '', $result->get_error_code() );
            return $result;
        }
        $message_id = is_array( $result ) ? (string) ( $result['message_id'] ?? $result['id'] ?? '' ) : '';
        self::log( $payload, 'sent', '', $message_id, '', is_array( $result ) ? $result : array() );
        return array( 'message_id' => $message_id, 'provider' => 'sms_ir', 'template_id' => $template_id );
    }

    private static function sms_ir_request( $template_id, $phone, $parameters ) {
        $api = self::get_api_key();
        if ( '' === $api ) return new WP_Error( 'sms_api_missing', 'API Key پیامک در تنظیمات Academy وارد نشده است.' );
        $endpoint = 'https://api.sms.ir/v1/send/verify';
        $body = array( 'Mobile' => ltrim( $phone, '+' ), 'TemplateId' => (int) $template_id, 'Parameters' => $parameters );
        $response = wp_remote_post( $endpoint, array(
            'timeout' => 20,
            'headers' => array( 'Content-Type' => 'application/json', 'Accept' => 'application/json', 'X-API-KEY' => $api ),
            'body' => wp_json_encode( $body, JSON_UNESCAPED_UNICODE ),
        ) );
        if ( is_wp_error( $response ) ) return new WP_Error( 'sms_http_error', 'ارتباط با SMS.ir برقرار نشد: ' . $response->get_error_message() );
        $code = wp_remote_retrieve_response_code( $response );
        $raw = wp_remote_retrieve_body( $response );
        $data = json_decode( $raw, true );
        if ( $code < 200 || $code >= 300 ) {
            $msg = is_array( $data ) ? ( $data['message'] ?? $data['Message'] ?? 'خطای نامشخص SMS.ir' ) : 'HTTP ' . $code;
            return new WP_Error( 'sms_provider_' . $code, 'SMS.ir: ' . $msg, array( 'http_code' => $code, 'response' => $data ) );
        }
        if ( is_array( $data ) && isset( $data['status'] ) && false === (bool) $data['status'] ) {
            return new WP_Error( 'sms_provider_rejected', 'SMS.ir درخواست را رد کرد.', $data );
        }
        return is_array( $data ) ? $data : array( 'raw' => $raw );
    }

    private static function log( $payload, $status, $error = '', $message_id = '', $error_code = '', $provider_response = array() ) {
        global $wpdb;
        $wpdb->insert( self::table(), array(
            'user_id' => absint( $payload['user_id'] ?? 0 ) ?: null,
            'campaign_id' => absint( $payload['campaign_id'] ?? 0 ) ?: null,
            'phone' => $payload['phone'],
            'purpose' => $payload['purpose'] ?? 'custom',
            'template_key' => $payload['template_key'] ?? null,
            'template_id' => $payload['template_id'] ?? null,
            'idempotency_key' => $payload['idempotency_key'] ?? null,
            'provider' => 'sms_ir',
            'status' => $status,
            'provider_message_id' => $message_id ?: null,
            'provider_status_code' => null,
            'error_code' => $error_code ?: null,
            'error_message' => $error ?: null,
            'metadata' => wp_json_encode( array( 'parameters' => $payload['parameters'] ?? array(), 'provider_response' => $provider_response ), JSON_UNESCAPED_UNICODE ),
            'sent_at' => 'sent' === $status ? current_time( 'mysql', true ) : null,
            'created_at' => current_time( 'mysql', true ),
        ), array( '%d','%d','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s' ) );
    }

    public static function on_course_completed( $user_id, $course_id ) {
        $title = get_the_title( $course_id );
        self::send_template( $user_id, 'course_completed', array( 'FirstName' => get_user_meta($user_id,'first_name',true), 'CourseName' => $title, 'Name' => get_userdata($user_id)->display_name ?? '' ), array( 'idempotency_key' => 'course_completed:' . absint($user_id) . ':' . absint($course_id) ) );
    }

    public static function on_certificate_issued( $certificate ) {
        if ( ! is_object($certificate) ) return;
        $u = get_userdata((int)$certificate->user_id);
        self::send_template( (int)$certificate->user_id, 'certificate', array( 'FirstName' => $u ? ($u->first_name ?: $u->display_name) : '', 'CertificateNumber' => $certificate->verification_code ?? '', 'CourseName' => get_the_title((int)$certificate->course_id) ), array( 'idempotency_key' => 'certificate:' . (int)$certificate->id ) );
    }

    public static function on_event_registration( $registration_id, $event_id ) {
        global $wpdb; $table=$wpdb->prefix.'academy_event_registrations'; $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d",absint($registration_id))); if(!$r)return; $u=get_userdata((int)$r->user_id); if(!$u)return;
        self::send_template((int)$r->user_id,'event_registration',array('FirstName'=>$u->first_name?:$u->display_name,'EventName'=>get_the_title($event_id),'TicketCode'=>$r->ticket_code ?? '','EntryCode'=>$r->entry_code ?? ''),array('idempotency_key'=>'event_registration:'.absint($registration_id)));
    }

    public static function on_payment_complete( $order_id ) {
        if ( ! function_exists('wc_get_order') ) return; $order=wc_get_order($order_id); if(!$order)return; $uid=(int)$order->get_user_id(); if(!$uid)return;
        foreach($order->get_items('line_item') as $item){ $product_id=(int)$item->get_product_id(); $variation_id=(int)$item->get_variation_id(); $course_id=class_exists('Academy_Site_WooCommerce')?Academy_Site_WooCommerce::get_course_for_product($product_id):0; if(!$course_id&&$variation_id&&class_exists('Academy_Site_WooCommerce'))$course_id=Academy_Site_WooCommerce::get_course_for_product($variation_id); if(!$course_id)continue; $u=get_userdata($uid); self::send_template($uid,'course_purchase',array('FirstName'=>$u->first_name?:$u->display_name,'CourseName'=>get_the_title($course_id),'OrderId'=>$order->get_id(),'Amount'=>$order->get_total()),array('idempotency_key'=>'course_purchase:'.$order->get_id().':'.$course_id)); }
    }

    public static function on_student_registered( $user_id ) {
        $u = get_userdata( absint( $user_id ) );
        if ( ! $u ) return;
        self::send_template( $user_id, 'welcome_student', array(
            'FirstName' => $u->first_name ?: $u->display_name,
            'LastName' => $u->last_name,
            'FullName' => $u->display_name,
            'Name' => $u->display_name,
        ), array( 'idempotency_key' => 'welcome:' . $u->ID ) );
    }

    private static function birth_month_day( $value ) {
        $value = trim( (string) $value );
        if ( preg_match( '/^(?:13|14)\d{2}[\/-](\d{1,2})[\/-](\d{1,2})$/', $value, $m ) ) return sprintf( '%02d-%02d', absint( $m[1] ), absint( $m[2] ) );
        if ( preg_match( '/^\d{4}[\/-](\d{1,2})[\/-](\d{1,2})$/', $value, $m ) ) return sprintf( '%02d-%02d', absint( $m[1] ), absint( $m[2] ) );
        $ts = strtotime( $value );
        return $ts ? wp_date( 'm-d', $ts, wp_timezone() ) : '';
    }

    public static function send_birthday_messages() {
        global $wpdb;
        $today = current_time( 'Y-m-d' );
        $month_day = wp_date( 'm-d', current_time( 'timestamp' ), wp_timezone() );
        if ( '' === self::get_api_key() || '' === self::get_template_id( 'birthday' ) ) return;
        $users = get_users( array( 'number' => -1, 'fields' => array( 'ID', 'display_name', 'first_name' ), 'meta_query' => array( array( 'key' => 'birth_date', 'compare' => 'EXISTS' ) ) ) );
        $reward = max( 0, (float) get_option( 'academy_birthday_wallet_amount', 0 ) );
        $hours = max( 1, min( 168, absint( get_option( 'academy_birthday_wallet_hours', 24 ) ) ) );
        foreach ( $users as $u ) {
            if ( self::birth_month_day( get_user_meta( $u->ID, 'birth_date', true ) ) !== $month_day ) continue;
            $already = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM " . self::table() . " WHERE user_id=%d AND template_key=%s AND status='sent' AND created_at >= %s", $u->ID, 'birthday', $today . ' 00:00:00' ) );
            if ( $already ) continue;
            $first = $u->first_name ?: $u->display_name;
            // SMS and wallet gift are independent idempotent actions: a provider outage must not
            // silently remove the student's birthday benefit.
            self::send_template( $u->ID, 'birthday', array( 'FirstName' => $first, 'Name' => $u->display_name ), array( 'idempotency_key' => 'birthday:' . $u->ID . ':' . $today ) );
            if ( $reward > 0 && class_exists( 'Academy_Site_Wallet' ) ) {
                $expires = gmdate( 'Y-m-d H:i:s', time() + ( $hours * HOUR_IN_SECONDS ) );
                Academy_Site_Wallet::gift( $u->ID, $reward, array( 'reference' => 'birthday-gift:' . $u->ID . ':' . $today, 'description' => 'هدیه تولد دانشجو', 'expires_at' => $expires, 'metadata' => array( 'birthday' => $today, 'valid_hours' => $hours ) ) );
            }
        }
    }

    public static function admin_menu() {
        add_options_page( 'Academy SMS', 'Academy SMS', 'manage_options', 'academy-site-sms', array( __CLASS__, 'settings_page' ) );
    }

    private static function test_parameters( $key, $code ) {
        $base = array(
            'Code' => $code,
            'FirstName' => 'تست',
            'LastName' => 'آزمایشی',
            'Name' => 'کاربر تست',
            'Gender' => 'female',
            'Province' => 'تهران',
            'City' => 'تهران',
            'BirthDate' => '1382/01/01',
            'Age' => '23',
            'TrackingCode' => 'TEST-123456',
            'ConsultationType' => 'مشاوره عمومی',
            'Subject' => 'تست سیستم',
            'RequestType' => 'general',
            'TicketId' => 'TEST-1',
            'EventName' => 'همایش تست',
            'TicketCode' => 'TICKET-TEST',
            'EntryCode' => 'ENTRY-TEST',
            'CourseName' => 'دوره تست',
            'OrderId' => 'TEST-ORDER',
            'Amount' => '100000',
            'CertificateNumber' => 'AC-TEST',
            'Campaign' => 'کمپین تست',
        );
        return $base;
    }

    public static function handle_test() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'دسترسی غیرمجاز.' );
        check_admin_referer( 'academy_sms_test' );
        $phone = self::normalize_phone( wp_unslash( $_POST['test_phone'] ?? '' ) );
        $key = sanitize_key( $_POST['test_template'] ?? 'crm_campaign' );
        $code = sanitize_text_field( wp_unslash( $_POST['test_code'] ?? '123456' ) );
        $r = self::send_template( 0, $key, self::test_parameters( $key, $code ), array( 'phone' => $phone ) );
        $url = admin_url( 'options-general.php?page=academy-site-sms' );
        $url = add_query_arg( array( 'sms_test' => is_wp_error( $r ) ? '0' : '1', 'sms_message' => rawurlencode( is_wp_error( $r ) ? $r->get_error_message() : 'پیام تست با موفقیت به API ارسال شد.' ) ), $url );
        wp_safe_redirect( $url ); exit;
    }

    public static function settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        if ( isset( $_POST['academy_sms_save'] ) ) {
            check_admin_referer( 'academy_sms_settings' );
            update_option( self::SETTINGS_PREFIX . 'api_key', sanitize_text_field( wp_unslash( $_POST['api_key'] ?? '' ) ) );
            update_option( 'academy_birthday_wallet_amount', max( 0, (float) ($_POST['birthday_wallet_amount'] ?? 0) ) );
            update_option( 'academy_birthday_wallet_hours', max( 1, min( 168, absint( $_POST['birthday_wallet_hours'] ?? 24 ) ) ) );
            foreach ( self::TEMPLATES as $key => $label ) update_option( self::SETTINGS_PREFIX . 'template_' . $key, preg_replace( '/[^0-9]/', '', (string) ( $_POST['template_' . $key] ?? '' ) ) );
            echo '<div class="notice notice-success"><p>تنظیمات پیامک ذخیره شد.</p></div>';
        }
        if ( isset( $_GET['sms_test'] ) ) echo '<div class="notice ' . ( '1' === $_GET['sms_test'] ? 'notice-success' : 'notice-error' ) . '"><p>' . esc_html( rawurldecode( $_GET['sms_message'] ?? '' ) ) . '</p></div>';
        echo '<div class="wrap"><h1>تنظیمات پیامک Academy</h1><p>API Key و Template IDها فقط در اینجا نگهداری می‌شوند. ماژول‌های Academy مستقیماً به SMS.ir متصل نیستند.</p><form method="post">'; wp_nonce_field( 'academy_sms_settings' );
        echo '<table class="form-table"><tr><th><label for="academy_sms_api">SMS.ir API Key</label></th><td><input id="academy_sms_api" type="password" name="api_key" value="' . esc_attr( self::get_api_key() ) . '" class="regular-text" autocomplete="off"><p class="description">کلید API حساب SMS.ir را وارد کنید.</p></td></tr>';
        echo '<tr><th>هدیه تولد</th><td><input type="number" min="0" step="1" name="birthday_wallet_amount" value="' . esc_attr( get_option( 'academy_birthday_wallet_amount', 0 ) ) . '" class="regular-text"> تومان، اعتبار: <input type="number" min="1" max="168" name="birthday_wallet_hours" value="' . esc_attr( get_option( 'academy_birthday_wallet_hours', 24 ) ) . '" style="width:100px"> ساعت</td></tr>';
        foreach ( self::TEMPLATES as $key => $label ) {
            $param_names = implode( ', ', self::TEMPLATE_VARIABLES );
            echo '<tr><th><label for="tpl_' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td><input id="tpl_' . esc_attr( $key ) . '" type="text" inputmode="numeric" name="template_' . esc_attr( $key ) . '" value="' . esc_attr( self::get_template_id( $key ) ) . '" class="regular-text"><p class="description">Template ID قالب تأییدشده در SMS.ir.' . ( $param_names ? ' متغیرهای قابل استفاده: <code>' . esc_html( $param_names ) . '</code> (هر قالب فقط متغیرهای غیرخالی را دریافت می‌کند.)' : '' ) . '</p></td></tr>';
        }
        echo '</table><p><button class="button button-primary" name="academy_sms_save" value="1">ذخیره تنظیمات</button></p></form><hr><h2>تست ارسال</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        echo '<input type="hidden" name="action" value="academy_sms_test">'; wp_nonce_field( 'academy_sms_test' );
        echo '<table class="form-table"><tr><th>شماره موبایل</th><td><input name="test_phone" class="regular-text" placeholder="0912..." required></td></tr><tr><th>قالب</th><td><select name="test_template">'; foreach ( self::TEMPLATES as $key=>$label ) echo '<option value="' . esc_attr($key) . '">' . esc_html($label) . '</option>'; echo '</select></td></tr><tr><th>کد تست</th><td><input name="test_code" value="123456" class="regular-text"></td></tr></table><p><button class="button">ارسال تست</button></p></form></div>';
    }
}
Academy_Site_SMS::boot();
