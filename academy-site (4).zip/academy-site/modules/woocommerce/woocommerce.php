<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Academy Site — WooCommerce Integration.
 *
 * WooCommerce owns products, cart, checkout, orders and payments.
 * Academy Site owns Course and Enrollment/Access.
 */
final class Academy_Site_WooCommerce {
    const COURSE_META = '_academy_course_id';

    public static function boot() {
        if ( ! class_exists( 'WooCommerce' ) ) { return; }

        add_action( 'add_meta_boxes', array( __CLASS__, 'add_product_meta_box' ) );
        add_action( 'save_post_product', array( __CLASS__, 'save_product_meta' ), 10, 3 );

        add_action( 'woocommerce_payment_complete', array( __CLASS__, 'handle_paid_order' ) );
        add_action( 'woocommerce_order_status_processing', array( __CLASS__, 'handle_paid_order' ) );
        add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'handle_paid_order' ) );
        add_action( 'woocommerce_order_status_refunded', array( __CLASS__, 'handle_refunded_order' ) );
    }

    public static function add_product_meta_box() {
        add_meta_box(
            'academy-product-course',
            'Academy Course',
            array( __CLASS__, 'render_product_meta_box' ),
            'product',
            'side',
            'default'
        );
    }

    public static function render_product_meta_box( $post ) {
        if ( ! current_user_can( 'edit_post', $post->ID ) ) { return; }

        wp_nonce_field( 'academy_product_course_save', 'academy_product_course_nonce' );
        $selected = absint( get_post_meta( $post->ID, self::COURSE_META, true ) );

        $courses = get_posts(
            array(
                'post_type'      => 'academy_course',
                'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
                'posts_per_page' => 100,
                'orderby'        => 'title',
                'order'          => 'ASC',
            )
        );

        echo '<p><label for="academy_product_course_id">دوره مرتبط</label></p>';
        echo '<select style="width:100%" id="academy_product_course_id" name="academy_product_course_id">';
        echo '<option value="0">— بدون دوره —</option>';
        foreach ( $courses as $course ) {
            printf(
                '<option value="%d" %s>%s</option>',
                (int) $course->ID,
                selected( $selected, $course->ID, false ),
                esc_html( $course->post_title )
            );
        }
        echo '</select>';
        echo '<p class="description">Product فقط لایه Commerce است؛ دسترسی توسط Enrollment کنترل می‌شود.</p>';
    }

    public static function save_product_meta( $post_id, $post, $update ) {
        if ( ! isset( $_POST['academy_product_course_nonce'] ) ) { return; }
        if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['academy_product_course_nonce'] ) ), 'academy_product_course_save' ) ) { return; }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) { return; }
        if ( wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) { return; }

        $course_id = absint( $_POST['academy_product_course_id'] ?? 0 );
        if ( $course_id && 'academy_course' !== get_post_type( $course_id ) ) { $course_id = 0; }

        if ( $course_id ) {
            update_post_meta( $post_id, self::COURSE_META, $course_id );
        } else {
            delete_post_meta( $post_id, self::COURSE_META );
        }
    }

    public static function handle_paid_order( $order_id ) {
        if ( ! function_exists( 'wc_get_order' ) ) { return; }
        $order = wc_get_order( $order_id );
        if ( ! $order ) { return; }

        $user_id = (int) $order->get_user_id();
        if ( ! $user_id ) {
            $order->add_order_note( 'Academy: enrollment برای سفارش بدون حساب کاربری ایجاد نشد.' );
            return;
        }

        foreach ( $order->get_items( 'line_item' ) as $item ) {
            $product_id = (int) $item->get_product_id();
            $variation_id = (int) $item->get_variation_id();
            $course_id = $product_id ? self::get_course_for_product( $product_id ) : 0;

            if ( ! $course_id && $variation_id ) {
                $course_id = self::get_course_for_product( $variation_id );
            }
            if ( ! $course_id ) { continue; }

            $result = Academy_Site_Enrollment::grant_from_payment(
                $user_id,
                $course_id,
                (string) $order->get_id(),
                'woocommerce'
            );

            if ( is_wp_error( $result ) ) {
                $order->add_order_note( sprintf( 'Academy: ایجاد Enrollment برای دوره %d ناموفق بود: %s', $course_id, $result->get_error_message() ) );
            }
        }
    }

    public static function handle_refunded_order( $order_id ) {
        if ( ! function_exists( 'wc_get_order' ) ) { return; }
        $order = wc_get_order( $order_id );
        if ( ! $order ) { return; }

        $user_id = (int) $order->get_user_id();
        if ( ! $user_id ) { return; }

        foreach ( $order->get_items( 'line_item' ) as $item ) {
            $product_id = (int) $item->get_product_id();
            $variation_id = (int) $item->get_variation_id();
            $course_id = $product_id ? self::get_course_for_product( $product_id ) : 0;
            if ( ! $course_id && $variation_id ) { $course_id = self::get_course_for_product( $variation_id ); }
            if ( ! $course_id ) { continue; }

            $result = Academy_Site_Enrollment::revoke( $user_id, $course_id, 'woocommerce:refund:' . $order->get_id() );
            if ( is_wp_error( $result ) ) {
                $order->add_order_note( sprintf( 'Academy: لغو Enrollment دوره %d ناموفق بود: %s', $course_id, $result->get_error_message() ) );
            }
        }
    }

    public static function get_course_for_product( $product_id ) {
        return absint( get_post_meta( absint( $product_id ), self::COURSE_META, true ) );
    }

    public static function get_products_for_course( $course_id ) {
        $query = new WP_Query(
            array(
                'post_type'      => 'product',
                'post_status'    => 'publish',
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'no_found_rows'  => true,
                'meta_query'     => array(
                    array(
                        'key'     => self::COURSE_META,
                        'value'   => absint( $course_id ),
                        'compare' => '=',
                        'type'    => 'NUMERIC',
                    ),
                ),
            )
        );
        return array_map( 'absint', $query->posts );
    }
}

Academy_Site_WooCommerce::boot();
