<?php
if(!defined('ABSPATH'))exit;
final class Academy_Site_Dynamic {
 public static function boot(){add_filter('academy_site_dynamic_data',array(__CLASS__,'data'),90,2);}
 public static function data($data,$context=array()){if(!is_user_logged_in())return $data;$uid=get_current_user_id();$data['academy_user_id']=$uid;$data['academy_user']=get_userdata($uid);$data['academy_wallet_balance']=class_exists('Academy_Site_Wallet')?Academy_Site_Wallet::get_balance($uid):0;$data['academy_my_courses']=class_exists('Academy_Site_My_Courses')?Academy_Site_My_Courses::get_my_courses($uid):array();$data['academy_my_events']=class_exists('Academy_Site_Events')?Academy_Site_Events::get_user_registrations($uid):array();$data['academy_certificates']=class_exists('Academy_Site_Certificates')?Academy_Site_Certificates::get_user_certificates($uid):array();return $data;}
}
Academy_Site_Dynamic::boot();
