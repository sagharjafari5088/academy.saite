<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
// REST API is used for event operations; no unauthenticated AJAX mutators are exposed.
