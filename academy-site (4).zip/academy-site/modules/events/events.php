<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Academy Site — Events & Tickets.
 *
 * Event is an Academy entity (CPT), not a WooCommerce Product.
 * Ticket Types and Registrations are normalized custom tables.
 * WooCommerce is only the commerce/payment layer.
 */
final class Academy_Site_Events {

	const POST_TYPE       = 'academy_event';
	const TAXONOMY        = 'academy_event_type';
	const TICKETS_TABLE   = 'academy_event_tickets';
	const REG_TABLE       = 'academy_event_registrations';
	const SEQ_TABLE       = 'academy_event_sequences';
	const PRODUCT_META    = '_academy_event_ticket_type_id';
	const EVENT_STATUS    = array( 'coming_soon', 'open', 'closed', 'full', 'cancelled' );
	const TICKET_TYPES    = array( 'cip', 'vip', 'regular' );
	const REG_STATUSES    = array( 'confirmed', 'cancelled' );
	const PAYMENT_STATUSES= array( 'unpaid', 'paid', 'refunded' );

	public static function boot() {
		add_action( 'init', array( __CLASS__, 'register_content_types' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'register_meta_boxes' ) );
		add_action( 'save_post_' . self::POST_TYPE, array( __CLASS__, 'save_event_meta' ), 10, 2 );

		add_action( 'admin_post_academy_event_add_ticket', array( __CLASS__, 'admin_add_ticket' ) );
		add_action( 'admin_post_academy_event_update_ticket', array( __CLASS__, 'admin_update_ticket' ) );
		add_action( 'admin_post_academy_event_delete_ticket', array( __CLASS__, 'admin_delete_ticket' ) );

		add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );
		add_filter( 'academy_site_dynamic_data', array( __CLASS__, 'dynamic_data' ), 50, 2 );

		// Commerce mapping is intentionally kept in this module.
		add_action( 'add_meta_boxes', array( __CLASS__, 'register_product_ticket_box' ) );
		add_action( 'save_post_product', array( __CLASS__, 'save_product_ticket_meta' ), 20, 3 );
		add_action( 'woocommerce_payment_complete', array( __CLASS__, 'handle_paid_order' ), 20 );
		add_action( 'woocommerce_order_status_processing', array( __CLASS__, 'handle_paid_order' ), 20 );
		add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'handle_paid_order' ), 20 );
		add_action( 'woocommerce_order_status_refunded', array( __CLASS__, 'handle_refunded_order' ), 20 );

		// Keep event status synchronized when an event reaches capacity.
		add_action( 'academy_site_event_registration_created', array( __CLASS__, 'sync_event_status' ), 10, 2 );
		add_action( 'academy_site_event_registration_cancelled', array( __CLASS__, 'sync_event_status' ), 10, 2 );
	}

	public static function table( $name ) {
		global $wpdb;
		return $wpdb->prefix . $name;
	}

	public static function tickets_table() { return self::table( self::TICKETS_TABLE ); }
	public static function registrations_table() { return self::table( self::REG_TABLE ); }
	public static function sequences_table() { return self::table( self::SEQ_TABLE ); }

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();

		dbDelta( "CREATE TABLE " . self::tickets_table() . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			event_id BIGINT UNSIGNED NOT NULL,
			ticket_key VARCHAR(30) NOT NULL,
			name VARCHAR(100) NOT NULL,
			price DECIMAL(20,6) NOT NULL DEFAULT 0,
			capacity INT UNSIGNED NULL,
			sort_order INT UNSIGNED NOT NULL DEFAULT 0,
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			product_id BIGINT UNSIGNED NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY event_ticket_key (event_id, ticket_key),
			KEY event_status (event_id, status),
			KEY product_id (product_id)
		) $charset;" );

		dbDelta( "CREATE TABLE " . self::registrations_table() . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			event_id BIGINT UNSIGNED NOT NULL,
			ticket_type_id BIGINT UNSIGNED NOT NULL,
			user_id BIGINT UNSIGNED NOT NULL,
			order_id BIGINT UNSIGNED NULL,
			order_item_id BIGINT UNSIGNED NULL,
			order_item_index SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			status VARCHAR(20) NOT NULL DEFAULT 'confirmed',
			payment_status VARCHAR(20) NOT NULL DEFAULT 'paid',
			ticket_code VARCHAR(80) NOT NULL,
			entry_code VARCHAR(80) NOT NULL,
			entry_number BIGINT UNSIGNED NULL,
			invitation_token CHAR(64) NOT NULL,
			qr_payload TEXT NULL,
			registered_at DATETIME NOT NULL,
			cancelled_at DATETIME NULL,
			metadata LONGTEXT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY ticket_code (ticket_code),
			UNIQUE KEY entry_code (entry_code),
			UNIQUE KEY invitation_token (invitation_token),
			KEY event_status (event_id, status),
			KEY user_event (user_id, event_id),
			KEY ticket_type_status (ticket_type_id, status),
			KEY order_item (order_id, order_item_id, order_item_index),
			KEY payment_status (payment_status)
		) $charset;" );

		dbDelta( "CREATE TABLE " . self::sequences_table() . " (
			event_id BIGINT UNSIGNED NOT NULL,
			next_number BIGINT UNSIGNED NOT NULL DEFAULT 1,
			PRIMARY KEY (event_id)
		) $charset;" );
	}

	public static function register_content_types() {
		register_post_type(
			self::POST_TYPE,
			array(
				'labels' => array(
					'name'          => 'همایش‌ها و رویدادها',
					'singular_name' => 'رویداد',
					'add_new_item'  => 'افزودن رویداد',
					'edit_item'     => 'ویرایش رویداد',
				),
				'public'       => true,
				'show_in_rest' => true,
				'menu_icon'    => 'dashicons-calendar-alt',
				'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail' ),
				'has_archive'  => true,
				'rewrite'      => array( 'slug' => 'events' ),
			)
		);

		register_taxonomy(
			self::TAXONOMY,
			self::POST_TYPE,
			array(
				'labels' => array(
					'name'          => 'نوع رویداد',
					'singular_name' => 'نوع رویداد',
				),
				'public'       => true,
				'show_in_rest' => true,
				'hierarchical' => true,
				'rewrite'      => array( 'slug' => 'event-type' ),
			)
		);
	}

	public static function register_meta_boxes() {
		add_meta_box(
			'academy-event-settings',
			'اطلاعات رویداد',
			array( __CLASS__, 'render_event_settings' ),
			self::POST_TYPE,
			'normal',
			'high'
		);

		add_meta_box(
			'academy-event-tickets',
			'انواع بلیت',
			array( __CLASS__, 'render_ticket_manager' ),
			self::POST_TYPE,
			'normal',
			'default'
		);
	}

	public static function render_event_settings( $post ) {
		wp_nonce_field( 'academy_event_save', 'academy_event_nonce' );

		$status   = get_post_meta( $post->ID, '_academy_event_status', true ) ?: 'coming_soon';
		$capacity = absint( get_post_meta( $post->ID, '_academy_event_capacity', true ) );
		$date     = get_post_meta( $post->ID, '_academy_event_date', true );
		$time     = get_post_meta( $post->ID, '_academy_event_time', true );
		$location = get_post_meta( $post->ID, '_academy_event_location', true );
		$speakers = get_post_meta( $post->ID, '_academy_event_speakers', true );
		$prefix   = get_post_meta( $post->ID, '_academy_event_entry_prefix', true );
		$start    = get_post_meta( $post->ID, '_academy_event_entry_start', true );
		$invite   = get_post_meta( $post->ID, '_academy_event_invitation_enabled', true );

		?>
		<table class="form-table">
			<tr>
				<th>وضعیت ثبت‌نام</th>
				<td>
					<select name="academy_event_status">
						<?php foreach ( self::EVENT_STATUS as $value ) : ?>
							<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $status, $value ); ?>>
								<?php echo esc_html( self::status_label( $value ) ); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
			<tr><th>ظرفیت کل</th><td><input type="number" min="0" name="academy_event_capacity" value="<?php echo esc_attr( $capacity ); ?>"><p class="description">۰ یعنی بدون ظرفیت کل.</p></td></tr>
			<tr><th>تاریخ</th><td><input type="date" name="academy_event_date" value="<?php echo esc_attr( $date ); ?>"></td></tr>
			<tr><th>ساعت</th><td><input type="time" name="academy_event_time" value="<?php echo esc_attr( $time ); ?>"></td></tr>
			<tr><th>محل برگزاری</th><td><input class="regular-text" type="text" name="academy_event_location" value="<?php echo esc_attr( $location ); ?>"></td></tr>
			<tr><th>سخنران‌ها</th><td><textarea class="large-text" rows="5" name="academy_event_speakers" placeholder="هر سخنران در یک خط"><?php echo esc_textarea( $speakers ); ?></textarea></td></tr>
			<tr><th>Prefix کد ورود</th><td><input class="regular-text" type="text" name="academy_event_entry_prefix" value="<?php echo esc_attr( $prefix ); ?>"><p class="description">مثلاً ACADEMY-</p></td></tr>
			<tr><th>شماره شروع کد ورود</th><td><input type="number" min="1" name="academy_event_entry_start" value="<?php echo esc_attr( $start ?: 111 ); ?>"></td></tr>
			<tr><th>دعوتنامه</th><td><label><input type="checkbox" name="academy_event_invitation_enabled" value="1" <?php checked( $invite, '1' ); ?>> فعال</label></td></tr>
		</table>
		<p>Banner و محتوای اصلی رویداد از تصویر شاخص و محتوای خود WordPress می‌آید تا Elementor بتواند آن‌ها را Dynamic مصرف کند.</p>
		<?php
	}

	public static function render_ticket_manager( $post ) {
		$tickets = self::get_ticket_types( $post->ID, false );
		?>
		<p>حداکثر سه نوع بلیت قابل تعریف است: CIP، VIP و عادی. هرکدام اختیاری است.</p>
		<table class="widefat striped">
			<thead><tr><th>نوع</th><th>عنوان</th><th>قیمت</th><th>ظرفیت</th><th>وضعیت</th><th>Product</th><th>عملیات</th></tr></thead>
			<tbody>
			<?php foreach ( $tickets as $ticket ) : ?>
				<tr>
					<td><?php echo esc_html( self::ticket_key_label( $ticket->ticket_key ) ); ?></td>
					<td><?php echo esc_html( $ticket->name ); ?></td>
					<td><?php echo esc_html( $ticket->price ); ?></td>
					<td><?php echo esc_html( $ticket->capacity ?: 'بدون محدودیت' ); ?></td>
					<td><?php echo esc_html( $ticket->status ); ?></td>
					<td><?php echo esc_html( $ticket->product_id ?: '—' ); ?></td>
					<td>
						<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=academy_event_delete_ticket&event_id=' . $post->ID . '&ticket_id=' . absint( $ticket->id ) ), 'academy_event_delete_ticket_' . $ticket->id ) ); ?>">حذف</a>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>

		<?php if ( count( $tickets ) < 3 ) : ?>
			<hr><h4>افزودن نوع بلیت</h4>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="academy_event_add_ticket">
				<input type="hidden" name="event_id" value="<?php echo absint( $post->ID ); ?>">
				<?php wp_nonce_field( 'academy_event_add_ticket_' . $post->ID ); ?>
				<p>
					<select name="ticket_key" required>
						<?php foreach ( self::TICKET_TYPES as $key ) : ?>
							<?php if ( ! self::get_ticket_by_key( $post->ID, $key ) ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( self::ticket_key_label( $key ) ); ?></option>
							<?php endif; ?>
						<?php endforeach; ?>
					</select>
				</p>
				<p><input required class="regular-text" type="text" name="name" placeholder="عنوان بلیت"></p>
				<p><input required type="number" min="0" step="0.01" name="price" placeholder="قیمت"></p>
				<p><input type="number" min="0" name="capacity" placeholder="ظرفیت — خالی یعنی بدون محدودیت"></p>
				<p><input type="number" min="0" name="sort_order" value="0" placeholder="ترتیب"></p>
				<p><select name="status"><option value="active">فعال</option><option value="inactive">غیرفعال</option></select></p>
				<p><input type="number" min="0" name="product_id" placeholder="WooCommerce Product ID"></p>
				<p><button class="button button-primary">افزودن بلیت</button></p>
			</form>
		<?php endif; ?>
		<?php
	}

	public static function save_event_meta( $post_id, $post ) {
		if ( ! isset( $_POST['academy_event_nonce'] ) ) return;
		$nonce = sanitize_text_field( wp_unslash( $_POST['academy_event_nonce'] ) );
		if ( ! wp_verify_nonce( $nonce, 'academy_event_save' ) ) return;
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
		if ( wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) return;

		$status = sanitize_key( $_POST['academy_event_status'] ?? 'coming_soon' );
		if ( ! in_array( $status, self::EVENT_STATUS, true ) ) $status = 'coming_soon';

		$values = array(
			'_academy_event_status'             => $status,
			'_academy_event_capacity'           => absint( $_POST['academy_event_capacity'] ?? 0 ),
			'_academy_event_date'               => self::sanitize_date( $_POST['academy_event_date'] ?? '' ),
			'_academy_event_time'               => self::sanitize_time( $_POST['academy_event_time'] ?? '' ),
			'_academy_event_location'           => sanitize_text_field( wp_unslash( $_POST['academy_event_location'] ?? '' ) ),
			'_academy_event_entry_prefix'       => sanitize_text_field( wp_unslash( $_POST['academy_event_entry_prefix'] ?? '' ) ),
			'_academy_event_entry_start'        => max( 1, absint( $_POST['academy_event_entry_start'] ?? 111 ) ),
			'_academy_event_invitation_enabled' => isset( $_POST['academy_event_invitation_enabled'] ) ? '1' : '0',
		);

		foreach ( $values as $key => $value ) update_post_meta( $post_id, $key, $value );
	}

	public static function add_ticket_type( $event_id, array $args ) {
		global $wpdb;

		$event_id = absint( $event_id );
		if ( self::POST_TYPE !== get_post_type( $event_id ) ) return new WP_Error( 'invalid_event', 'رویداد معتبر نیست.' );

		$key = sanitize_key( $args['ticket_key'] ?? '' );
		if ( ! in_array( $key, self::TICKET_TYPES, true ) ) return new WP_Error( 'invalid_ticket_type', 'نوع بلیت معتبر نیست.' );
		if ( self::get_ticket_by_key( $event_id, $key ) ) return new WP_Error( 'duplicate_ticket_type', 'این نوع بلیت قبلاً برای رویداد تعریف شده است.' );
		if ( count( self::get_ticket_types( $event_id, false ) ) >= 3 ) return new WP_Error( 'ticket_limit', 'هر رویداد حداکثر سه نوع بلیت دارد.' );

		$name = sanitize_text_field( $args['name'] ?? '' );
		if ( '' === $name ) return new WP_Error( 'empty_name', 'عنوان بلیت الزامی است.' );

		$price = max( 0, (float) ( $args['price'] ?? 0 ) );
		$capacity = null;
		if ( '' !== (string) ( $args['capacity'] ?? '' ) ) $capacity = max( 0, absint( $args['capacity'] ) );

		$product_id = absint( $args['product_id'] ?? 0 );
		if ( $product_id && 'product' !== get_post_type( $product_id ) ) $product_id = 0;

		$now = current_time( 'mysql', true );
		$ok = $wpdb->insert(
			self::tickets_table(),
			array(
				'event_id' => $event_id, 'ticket_key' => $key, 'name' => $name,
				'price' => $price, 'capacity' => $capacity, 'sort_order' => absint( $args['sort_order'] ?? 0 ),
				'status' => in_array( $args['status'] ?? 'active', array( 'active', 'inactive' ), true ) ? $args['status'] : 'active',
				'product_id' => $product_id ?: null, 'created_at' => $now, 'updated_at' => $now,
			),
			array( '%d','%s','%s','%f','%s','%d','%s','%d','%s','%s' )
		);

		return false === $ok ? new WP_Error( 'db_error', 'ایجاد نوع بلیت ناموفق بود.' ) : (int) $wpdb->insert_id;
	}

	public static function update_ticket_type( $ticket_id, array $args ) {
		global $wpdb;
		$row = self::get_ticket( $ticket_id );
		if ( ! $row ) return new WP_Error( 'not_found', 'بلیت پیدا نشد.' );

		$data = array(
			'name'       => sanitize_text_field( $args['name'] ?? $row->name ),
			'price'      => max( 0, (float) ( $args['price'] ?? $row->price ) ),
			'capacity'   => '' === (string) ( $args['capacity'] ?? $row->capacity ) ? null : max( 0, absint( $args['capacity'] ) ),
			'sort_order' => absint( $args['sort_order'] ?? $row->sort_order ),
			'status'     => in_array( $args['status'] ?? $row->status, array( 'active', 'inactive' ), true ) ? $args['status'] : $row->status,
			'product_id' => absint( $args['product_id'] ?? $row->product_id ) ?: null,
			'updated_at' => current_time( 'mysql', true ),
		);

		$ok = $wpdb->update(
			self::tickets_table(), $data, array( 'id' => (int) $row->id ),
			array( '%s','%f','%s','%d','%s','%s','%s' ), array( '%d' )
		);

		return false === $ok ? new WP_Error( 'db_error', 'ویرایش بلیت ناموفق بود.' ) : true;
	}

	public static function delete_ticket_type( $ticket_id ) {
		global $wpdb;
		$row = self::get_ticket( $ticket_id );
		if ( ! $row ) return false;
		if ( self::count_registrations_for_ticket( $ticket_id ) > 0 ) return new WP_Error( 'ticket_in_use', 'این بلیت ثبت‌نام دارد و حذف آن مجاز نیست؛ آن را غیرفعال کنید.' );
		return (bool) $wpdb->delete( self::tickets_table(), array( 'id' => (int) $ticket_id ), array( '%d' ) );
	}

	public static function get_ticket( $ticket_id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::tickets_table() . ' WHERE id = %d LIMIT 1', absint( $ticket_id ) ) );
	}

	public static function get_ticket_by_key( $event_id, $key ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::tickets_table() . ' WHERE event_id = %d AND ticket_key = %s LIMIT 1', absint( $event_id ), sanitize_key( $key ) ) );
	}

	public static function get_ticket_types( $event_id, $active_only = true ) {
		global $wpdb;
		$sql = 'SELECT * FROM ' . self::tickets_table() . ' WHERE event_id = %d';
		$args = array( absint( $event_id ) );
		if ( $active_only ) { $sql .= " AND status = 'active'"; }
		$sql .= ' ORDER BY sort_order ASC, id ASC';
		return $wpdb->get_results( $wpdb->prepare( $sql, $args ) );
	}

	public static function get_event( $event_id ) {
		$post = get_post( absint( $event_id ) );
		if ( ! $post || self::POST_TYPE !== $post->post_type ) return null;

		$terms = wp_get_post_terms( $post->ID, self::TAXONOMY );
		$types = array();
		foreach ( $terms as $term ) {
			$types[] = array( 'id' => (int) $term->term_id, 'name' => $term->name, 'slug' => $term->slug );
		}

		return array(
			'id'                    => (int) $post->ID,
			'title'                 => get_the_title( $post ),
			'description'           => $post->post_content,
			'excerpt'               => get_the_excerpt( $post ),
			'image_id'              => (int) get_post_thumbnail_id( $post ),
			'banner_id'             => (int) get_post_meta( $post->ID, '_academy_event_banner_id', true ),
			'trailer_url'           => esc_url( get_post_meta( $post->ID, '_academy_event_trailer_url', true ) ),
			'status'                => sanitize_key( get_post_meta( $post->ID, '_academy_event_status', true ) ?: 'coming_soon' ),
			'capacity'              => absint( get_post_meta( $post->ID, '_academy_event_capacity', true ) ),
			'date'                  => get_post_meta( $post->ID, '_academy_event_date', true ),
			'time'                  => get_post_meta( $post->ID, '_academy_event_time', true ),
			'location'              => get_post_meta( $post->ID, '_academy_event_location', true ),
			'speakers'              => get_post_meta( $post->ID, '_academy_event_speakers', true ),
			'event_types'           => $types,
			'ticket_types'          => self::get_ticket_types( $post->ID, true ),
			'registered_count'      => self::count_event_registrations( $post->ID ),
			'available'             => self::event_has_capacity( $post->ID ),
			'invitation_enabled'    => '1' === get_post_meta( $post->ID, '_academy_event_invitation_enabled', true ),
		);
	}

	public static function count_event_registrations( $event_id ) {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM " . self::registrations_table() . " WHERE event_id = %d AND status = 'confirmed'",
			absint( $event_id )
		) );
	}

	public static function count_ticket_registrations( $ticket_type_id ) {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM " . self::registrations_table() . " WHERE ticket_type_id = %d AND status = 'confirmed'",
			absint( $ticket_type_id )
		) );
	}

	public static function count_registrations_for_ticket( $ticket_type_id ) {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM " . self::registrations_table() . " WHERE ticket_type_id = %d",
			absint( $ticket_type_id )
		) );
	}

	public static function event_has_capacity( $event_id ) {
		$event = self::get_event( $event_id );
		if ( ! $event ) return false;
		if ( 'open' !== $event['status'] ) return false;
		if ( $event['capacity'] > 0 && self::count_event_registrations( $event_id ) >= $event['capacity'] ) return false;
		return true;
	}

	public static function ticket_has_capacity( $ticket_id ) {
		$ticket = self::get_ticket( $ticket_id );
		if ( ! $ticket || 'active' !== $ticket->status ) return false;
		if ( null !== $ticket->capacity && (int) $ticket->capacity > 0 && self::count_ticket_registrations( $ticket_id ) >= (int) $ticket->capacity ) return false;
		return true;
	}

	public static function create_registration( $user_id, $ticket_type_id, array $args = array() ) {
		global $wpdb;

		$user_id = absint( $user_id );
		$ticket  = self::get_ticket( $ticket_type_id );

		if ( ! $user_id || ! get_user_by( 'id', $user_id ) ) return new WP_Error( 'invalid_user', 'کاربر معتبر نیست.' );
		if ( ! $ticket || 'active' !== $ticket->status ) return new WP_Error( 'invalid_ticket', 'نوع بلیت فعال نیست.' );

		$event = self::get_event( $ticket->event_id );
		if ( ! $event ) return new WP_Error( 'invalid_event', 'رویداد معتبر نیست.' );
		if ( ! in_array( $event['status'], array( 'open', 'full' ), true ) ) return new WP_Error( 'event_closed', 'ثبت‌نام این رویداد باز نیست.' );
		if ( 'full' === $event['status'] ) return new WP_Error( 'event_full', 'ظرفیت رویداد تکمیل شده است.' );

		$lock_name = 'academy_event_' . absint( $event['id'] );
		$locked = false;

		// Named DB lock prevents two simultaneous paid callbacks from
		// passing the capacity check at the same time.
		$lock_result = $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $lock_name ) );
		$locked = ( '1' === (string) $lock_result );

		try {
			if ( ! self::event_has_capacity( $event['id'] ) || ! self::ticket_has_capacity( $ticket->id ) ) {
				return new WP_Error( 'capacity_full', 'ظرفیت این رویداد یا این نوع بلیت تکمیل شده است.' );
			}

			$order_id      = absint( $args['order_id'] ?? 0 ) ?: null;
			$order_item_id = absint( $args['order_item_id'] ?? 0 ) ?: null;

			if ( $order_item_id ) {
				$existing = self::get_registration_by_order_item( $order_id, $order_item_id, absint( $args['order_item_index'] ?? 0 ) );
				if ( $existing ) return (int) $existing->id;
			}

			$entry_number = self::next_entry_number( $event['id'] );
			$prefix       = sanitize_text_field( get_post_meta( $event['id'], '_academy_event_entry_prefix', true ) );
			$entry_code   = $prefix . $entry_number;
			$ticket_code  = self::make_ticket_code( $event['id'], $ticket->id );
			$invitation   = hash( 'sha256', wp_generate_uuid4() . '|' . wp_salt( 'auth' ) );
			$qr_payload   = self::make_qr_payload( $event['id'], $ticket_code );

			$now = current_time( 'mysql', true );
			$metadata = array(
				'ticket_name' => $ticket->name,
				'event_title' => get_the_title( $event['id'] ),
				'created_by'  => 'academy',
				'customer'    => is_array( $args['metadata'] ?? null ) ? $args['metadata'] : array(),
			);

			$ok = $wpdb->insert(
				self::registrations_table(),
				array(
					'event_id' => $event['id'], 'ticket_type_id' => $ticket->id, 'user_id' => $user_id,
					'order_id' => $order_id, 'order_item_id' => $order_item_id,
					'order_item_index' => absint( $args['order_item_index'] ?? 0 ),
					'status' => 'confirmed', 'payment_status' => 'paid',
					'ticket_code' => $ticket_code, 'entry_code' => $entry_code, 'entry_number' => $entry_number,
					'invitation_token' => $invitation, 'qr_payload' => $qr_payload,
					'registered_at' => $now, 'cancelled_at' => null,
					'metadata' => wp_json_encode( $metadata ),
				),
				array( '%d','%d','%d','%d','%d','%d','%s','%s','%s','%s','%d','%s','%s','%s','%s','%s' )
			);

			if ( false === $ok ) return new WP_Error( 'registration_failed', 'ثبت‌نام رویداد ناموفق بود.' );

			$id = (int) $wpdb->insert_id;
			do_action( 'academy_site_event_registration_created', $id, $event['id'] );
			return $id;
		} finally {
			if ( $locked ) $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_name ) );
		}
	}

	public static function next_entry_number( $event_id ) {
		global $wpdb;
		$event_id = absint( $event_id );
		$start = max( 1, absint( get_post_meta( $event_id, '_academy_event_entry_start', true ) ?: 111 ) );

		$wpdb->query(
			$wpdb->prepare(
				'INSERT IGNORE INTO ' . self::sequences_table() . ' (event_id, next_number) VALUES (%d, %d)',
				$event_id, $start
			)
		);

		$wpdb->query(
			$wpdb->prepare(
				'UPDATE ' . self::sequences_table() . ' SET next_number = LAST_INSERT_ID(next_number + 1) WHERE event_id = %d',
				$event_id
			)
		);

		$number = (int) $wpdb->get_var( 'SELECT LAST_INSERT_ID()' );
		return max( $start, $number - 1 );
	}

	public static function make_ticket_code( $event_id, $ticket_id ) {
		return 'TKT-' . strtoupper( wp_generate_password( 12, false, false ) ) . '-' . absint( $event_id ) . '-' . absint( $ticket_id );
	}

	public static function make_qr_payload( $event_id, $ticket_code ) {
		return add_query_arg(
			array(
				'event' => absint( $event_id ),
				'ticket' => rawurlencode( $ticket_code ),
			),
			home_url( '/academy-ticket-check/' )
		);
	}

	public static function create_registration_from_commerce( $user_id, $ticket_type_id, $order_id = 0, $metadata = array() ) {
        global $wpdb;
        if ( $order_id ) {
            $existing = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::registrations_table() . ' WHERE order_id=%d LIMIT 1', absint( $order_id ) ) );
            if ( $existing ) return (int) $existing;
        }
		$metadata = is_string( $metadata ) ? (array) json_decode( $metadata, true ) : (array) $metadata;
		return self::create_registration( $user_id, $ticket_type_id, array(
			'order_id' => absint( $order_id ),
			'metadata' => $metadata,
		) );
	}

	public static function get_registration( $registration_id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::registrations_table() . ' WHERE id = %d LIMIT 1', absint( $registration_id ) ) );
	}

	public static function get_registration_by_order_item( $order_id, $order_item_id, $order_item_index = 0 ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::registrations_table() . ' WHERE order_id = %d AND order_item_id = %d AND order_item_index = %d LIMIT 1', absint( $order_id ), absint( $order_item_id ), absint( $order_item_index ) ) );
	}

	public static function get_user_registrations( $user_id, $status = 'confirmed' ) {
		global $wpdb;
		$sql = 'SELECT * FROM ' . self::registrations_table() . ' WHERE user_id = %d';
		$args = array( absint( $user_id ) );
		if ( $status ) { $sql .= ' AND status = %s'; $args[] = sanitize_key( $status ); }
		$sql .= ' ORDER BY registered_at DESC';
		return $wpdb->get_results( $wpdb->prepare( $sql, $args ) );
	}

	public static function get_public_ticket( $code ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT r.*, e.post_title AS event_title, t.name AS ticket_name
			FROM " . self::registrations_table() . " r
			INNER JOIN {$wpdb->posts} e ON e.ID = r.event_id
			INNER JOIN " . self::tickets_table() . " t ON t.id = r.ticket_type_id
			WHERE r.ticket_code = %s AND r.status = 'confirmed'
			LIMIT 1",
			sanitize_text_field( $code )
		) );
	}

	public static function cancel_registration( $registration_id, $reason = 'manual' ) {
		global $wpdb;
		$row = self::get_registration( $registration_id );
		if ( ! $row ) return new WP_Error( 'not_found', 'ثبت‌نام پیدا نشد.' );
		if ( 'cancelled' === $row->status ) return true;

		$ok = $wpdb->update(
			self::registrations_table(),
			array(
				'status' => 'cancelled',
				'payment_status' => 'refunded',
				'cancelled_at' => current_time( 'mysql', true ),
			),
			array( 'id' => (int) $row->id ),
			array( '%s','%s','%s' ),
			array( '%d' )
		);

		if ( false === $ok ) return new WP_Error( 'db_error', 'لغو ثبت‌نام ناموفق بود.' );

		do_action( 'academy_site_event_registration_cancelled', (int) $row->id, (int) $row->event_id, sanitize_text_field( $reason ) );
		return true;
	}

	public static function sync_event_status( $registration_id, $event_id ) {
		$event = self::get_event( $event_id );
		if ( ! $event || ! $event['capacity'] ) return;

		$count = self::count_event_registrations( $event_id );
		$current = get_post_meta( $event_id, '_academy_event_status', true );

		if ( $count >= $event['capacity'] && 'open' === $current ) {
			update_post_meta( $event_id, '_academy_event_status', 'full' );
		} elseif ( $count < $event['capacity'] && 'full' === $current ) {
			update_post_meta( $event_id, '_academy_event_status', 'open' );
		}
	}

	public static function handle_paid_order( $order_id ) {
		if ( ! function_exists( 'wc_get_order' ) ) return;
		$order = wc_get_order( $order_id );
		if ( ! $order ) return;

		$user_id = (int) $order->get_user_id();
		if ( ! $user_id ) {
			$order->add_order_note( 'Academy Events: ثبت‌نام رویداد برای سفارش بدون حساب کاربری ایجاد نشد.' );
			return;
		}

		foreach ( $order->get_items( 'line_item' ) as $item_id => $item ) {
			$product_id  = (int) $item->get_product_id();
			$variation_id = (int) $item->get_variation_id();
			$ticket_id   = $variation_id ? absint( get_post_meta( $variation_id, self::PRODUCT_META, true ) ) : 0;
			if ( ! $ticket_id && $product_id ) $ticket_id = absint( get_post_meta( $product_id, self::PRODUCT_META, true ) );
			if ( ! $ticket_id ) continue;

			$ticket = self::get_ticket( $ticket_id );
			if ( ! $ticket ) {
				$order->add_order_note( 'Academy Events: نوع بلیت مرتبط پیدا نشد.' );
				continue;
			}

			$quantity = max( 1, (int) $item->get_quantity() );
			for ( $i = 0; $i < $quantity; $i++ ) {
				$result = self::create_registration(
					$user_id,
					$ticket_id,
					array(
						'order_id'         => $order->get_id(),
						'order_item_id'   => $item_id,
						'order_item_index'=> $i,
					)
				);

				if ( is_wp_error( $result ) ) {
					$order->add_order_note( sprintf( 'Academy Events: ایجاد ثبت‌نام ناموفق بود: %s', $result->get_error_message() ) );
				}
			}
		}
	}

	public static function handle_refunded_order( $order_id ) {
		global $wpdb;
		if ( ! function_exists( 'wc_get_order' ) ) return;
		$order = wc_get_order( $order_id );
		if ( ! $order ) return;

		$registrations = $wpdb->get_results(
			$wpdb->prepare( 'SELECT id FROM ' . self::registrations_table() . ' WHERE order_id = %d AND status = "confirmed"', $order->get_id() )
		);

		foreach ( $registrations as $registration ) {
			self::cancel_registration( (int) $registration->id, 'woocommerce_refund:' . $order->get_id() );
		}
	}

	public static function register_product_ticket_box() {
		if ( ! class_exists( 'WooCommerce' ) ) return;
		add_meta_box(
			'academy-product-event-ticket',
			'Academy Event Ticket',
			array( __CLASS__, 'render_product_ticket_box' ),
			'product',
			'side',
			'default'
		);
	}

	public static function render_product_ticket_box( $post ) {
		if ( ! current_user_can( 'edit_post', $post->ID ) ) return;
		wp_nonce_field( 'academy_product_event_ticket_save', 'academy_product_event_ticket_nonce' );
		$selected = absint( get_post_meta( $post->ID, self::PRODUCT_META, true ) );
		$tickets = self::get_all_ticket_types();

		echo '<p><label for="academy_event_ticket_type_id">نوع بلیت مرتبط</label></p>';
		echo '<select style="width:100%" id="academy_event_ticket_type_id" name="academy_event_ticket_type_id">';
		echo '<option value="0">— بدون بلیت رویداد —</option>';
		foreach ( $tickets as $ticket ) {
			printf(
				'<option value="%d" %s>%s — %s</option>',
				(int) $ticket->id,
				selected( $selected, $ticket->id, false ),
				esc_html( get_the_title( $ticket->event_id ) ),
				esc_html( $ticket->name )
			);
		}
		echo '</select>';
		echo '<p class="description">این Product فقط لایه فروش/پرداخت است؛ Registration توسط Academy Events ساخته می‌شود.</p>';
	}

	public static function save_product_ticket_meta( $post_id, $post, $update ) {
		if ( ! isset( $_POST['academy_product_event_ticket_nonce'] ) ) return;
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['academy_product_event_ticket_nonce'] ) ), 'academy_product_event_ticket_save' ) ) return;
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
		if ( wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) return;

		$ticket_id = absint( $_POST['academy_event_ticket_type_id'] ?? 0 );
		if ( $ticket_id && ! self::get_ticket( $ticket_id ) ) $ticket_id = 0;

		if ( $ticket_id ) update_post_meta( $post_id, self::PRODUCT_META, $ticket_id );
		else delete_post_meta( $post_id, self::PRODUCT_META );
	}

	public static function get_all_ticket_types() {
		global $wpdb;
		return $wpdb->get_results( 'SELECT * FROM ' . self::tickets_table() . ' ORDER BY event_id DESC, sort_order ASC, id ASC LIMIT 500' );
	}

	public static function register_rest_routes() {
		register_rest_route(
			'academy-site/v1',
			'/events/(?P<id>\d+)',
			array(
				'methods' => WP_REST_Server::READABLE,
				'callback' => function( WP_REST_Request $request ) {
					$event_id = absint( $request['id'] );
					if ( 'publish' !== get_post_status( $event_id ) ) return new WP_Error( 'not_found', 'رویداد پیدا نشد.', array( 'status' => 404 ) );
					$event = self::get_event( $event_id );
					if ( ! $event ) return new WP_Error( 'not_found', 'رویداد پیدا نشد.', array( 'status' => 404 ) );
					return rest_ensure_response( $event );
				},
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'academy-site/v1',
			'/me/events',
			array(
				'methods' => WP_REST_Server::READABLE,
				'callback' => function() {
					if ( ! is_user_logged_in() ) return new WP_Error( 'unauthorized', 'ورود الزامی است.', array( 'status' => 401 ) );
					return rest_ensure_response( self::get_user_event_cards( get_current_user_id() ) );
				},
				'permission_callback' => function() { return is_user_logged_in(); },
			)
		);

		register_rest_route(
			'academy-site/v1',
			'/me/events/(?P<id>\d+)',
			array(
				'methods' => WP_REST_Server::READABLE,
				'callback' => function( WP_REST_Request $request ) {
					if ( ! is_user_logged_in() ) return new WP_Error( 'unauthorized', 'ورود الزامی است.', array( 'status' => 401 ) );
					$row = self::get_registration( absint( $request['id'] ) );
					if ( ! $row || (int) $row->user_id !== get_current_user_id() ) return new WP_Error( 'forbidden', 'دسترسی غیرمجاز.', array( 'status' => 403 ) );
					return rest_ensure_response( self::registration_view( $row ) );
				},
				'permission_callback' => function() { return is_user_logged_in(); },
			)
		);

		register_rest_route(
			'academy-site/v1',
			'/tickets/verify/(?P<code>[A-Za-z0-9\-_]+)',
			array(
				'methods' => WP_REST_Server::READABLE,
				'callback' => function( WP_REST_Request $request ) {
					$row = self::get_public_ticket( $request['code'] );
					if ( ! $row ) return new WP_Error( 'invalid_ticket', 'بلیط معتبر نیست.', array( 'status' => 404 ) );
					return rest_ensure_response(
						array(
							'valid'       => true,
							'ticket_code' => $row->ticket_code,
							'entry_code'  => $row->entry_code,
							'event'       => $row->event_title,
							'ticket_type' => $row->ticket_name,
							'status'      => $row->status,
						)
					);
				},
				'permission_callback' => '__return_true',
			)
		);
	}

	public static function get_user_event_cards( $user_id ) {
		$rows = self::get_user_registrations( $user_id, '' );
		$out  = array();
		foreach ( $rows as $row ) $out[] = self::registration_view( $row );
		return $out;
	}

	public static function registration_view( $row ) {
		$event = self::get_event( $row->event_id );
		$ticket = self::get_ticket( $row->ticket_type_id );
		$user = get_user_by( 'id', $row->user_id );

		$first = $user ? get_user_meta( $row->user_id, 'first_name', true ) : '';
		$last  = $user ? get_user_meta( $row->user_id, 'last_name', true ) : '';

		return array(
			'id'            => (int) $row->id,
			'event_id'      => (int) $row->event_id,
			'event_title'   => $event ? $event['title'] : '',
			'event_date'    => $event ? $event['date'] : '',
			'event_time'    => $event ? $event['time'] : '',
			'location'      => $event ? $event['location'] : '',
			'ticket_type'   => $ticket ? $ticket->name : '',
			'ticket_key'    => $ticket ? $ticket->ticket_key : '',
			'status'        => $row->status,
			'payment_status' => $row->payment_status,
			'ticket_code'   => $row->ticket_code,
			'entry_code'    => $row->entry_code,
			'entry_number'  => (int) $row->entry_number,
			'qr_payload'    => $row->qr_payload,
			'invitation'    => array(
				'enabled' => $event ? $event['invitation_enabled'] : false,
				'token'   => $row->invitation_token,
				'name'    => trim( $first . ' ' . $last ),
			),
			'registered_at' => $row->registered_at,
		);
	}

	public static function dynamic_data( $data, $context ) {
		if ( is_singular( self::POST_TYPE ) ) {
			$data['event'] = self::get_event( get_the_ID() );
		}

		if ( is_user_logged_in() ) {
			$data['my_events'] = self::get_user_event_cards( get_current_user_id() );
		}

		return $data;
	}

	public static function status_label( $status ) {
		$map = array(
			'coming_soon' => 'به‌زودی',
			'open'        => 'ثبت‌نام باز',
			'closed'      => 'بسته',
			'full'        => 'تکمیل ظرفیت',
			'cancelled'   => 'لغوشده',
		);
		return $map[ $status ] ?? $status;
	}

	public static function ticket_key_label( $key ) {
		$map = array( 'cip' => 'CIP', 'vip' => 'VIP', 'regular' => 'عادی' );
		return $map[ $key ] ?? $key;
	}

	private static function sanitize_date( $value ) {
		$value = sanitize_text_field( wp_unslash( $value ) );
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ? $value : '';
	}

	private static function sanitize_time( $value ) {
		$value = sanitize_text_field( wp_unslash( $value ) );
		return preg_match( '/^\d{2}:\d{2}$/', $value ) ? $value : '';
	}
}

Academy_Site_Events::boot();
