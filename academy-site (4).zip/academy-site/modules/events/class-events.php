<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
// Event domain logic is intentionally centralized in events.php to preserve one module boundary.
