<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Academy_Site_Ticket_Renderer {
    public static function boot() {
        add_filter( 'academy_site_render_map', array( __CLASS__, 'map' ), 20, 3 );
    }
    public static function map( $map, $type, $data ) {
        if ( 'ticket' !== $type ) return $map;
        $d = is_array( $data ) ? $data : (array) $data;
        $id = absint( $d['id'] ?? 0 );
        $url = $id ? get_permalink( $id ) : '#';
        $m = array();
        $obj = is_object( $d ) ? $d : (object) $d;
            $m = array(
                'ticket_id'       => (string) ( $obj->id ?? 0 ),
                'ticket_key'      => esc_html( $obj->ticket_key ?? '' ),
                'ticket_name'    => esc_html( $obj->name ?? '' ),
                'ticket_type'    => esc_html( $obj->ticket_key ?? '' ),
                'ticket_price'   => esc_html( Academy_Site_HTML_Renderer::money( $obj->price ?? 0 ) ),
                'ticket_capacity'=> ( $obj->capacity ?? null ) !== null ? (string) $obj->capacity : '',
                'ticket_status'  => esc_html( $obj->status ?? '' ),
                'ticket_class'   => 'academy-ticket--' . sanitize_html_class( sanitize_key( $obj->ticket_key ?? '' ) ),
                'ticket_is_vip'  => in_array( sanitize_key( $obj->ticket_key ?? '' ), array( 'vip','cip' ), true ) ? '1' : '0',
                'ticket_checkout_url' => class_exists('Academy_Site_Commerce') ? esc_url( Academy_Site_Commerce::purchase_url('event_ticket', absint($obj->id ?? 0)) ) : '',
                'ticket_action'  => class_exists('Academy_Site_Commerce') ? '<a class="academy-ticket-action" href="'.esc_url(Academy_Site_Commerce::purchase_url('event_ticket',absint($obj->id ?? 0))).'">خرید بلیت</a>' : '',
            );
        return $m;
    }
}
Academy_Site_Ticket_Renderer::boot();
