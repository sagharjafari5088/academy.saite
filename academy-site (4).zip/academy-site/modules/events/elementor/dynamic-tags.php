<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
// Dynamic data is exposed through the Academy Site dynamic-data contract.
// Elementor-specific tags can consume the event/my_events payload without
// embedding business logic in templates.
