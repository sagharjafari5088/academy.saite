<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Academy_Site_Event_Renderer {
    public static function boot() {
        add_filter( 'academy_site_render_map', array( __CLASS__, 'map' ), 20, 3 );
    }
    public static function map( $map, $type, $data ) {
        if ( 'seminar' !== $type ) return $map;
        $d = is_array( $data ) ? $data : (array) $data;
        $id = absint( $d['id'] ?? 0 );
        $url = $id ? get_permalink( $id ) : '#';
        $m = array();
        $status = $d['status'] ?? 'coming_soon';
            $label = class_exists( 'Academy_Site_Events' ) ? Academy_Site_Events::status_label( $status ) : $status;
            $tickets = $d['ticket_types'] ?? array();
            $first_ticket = ! empty( $tickets ) ? ( is_object( $tickets[0] ) ? absint( $tickets[0]->id ) : absint( $tickets[0]['id'] ?? 0 ) ) : 0;
            $ticket_checkout = ( $first_ticket && class_exists( 'Academy_Site_Commerce' ) ) ? Academy_Site_Commerce::purchase_url( 'event_ticket', $first_ticket ) : $url;
            $action = 'open' === $status
                ? '<a class="academy-event-action academy-event-action--register" href="' . esc_url( $ticket_checkout ) . '">ثبت‌نام / خرید بلیت</a>'
                : '<a class="academy-event-action academy-event-action--view" href="' . esc_url( $url ) . '">مشاهده همایش</a>';

            $ticket_html = Academy_Site_HTML_Renderer::ticket_html( $tickets );

            $m = array(
                'event_id'             => (string) $id,
                'event_title'         => esc_html( $d['title'] ?? '' ),
                'event_description'   => wp_kses_post( $d['description'] ?? '' ),
                'event_excerpt'       => wp_kses_post( $d['excerpt'] ?? '' ),
                'event_type'          => esc_html( $d['type'] ?? '' ),
                'event_image'         => ! empty( $d['image_id'] ) ? wp_get_attachment_image( absint( $d['image_id'] ), 'full', false, array( 'class' => 'academy-event-image' ) ) : '',
                'event_image_url'     => ! empty( $d['image_id'] ) ? esc_url( wp_get_attachment_image_url( absint( $d['image_id'] ), 'full' ) ) : '',
                'event_date'          => esc_html( $d['date'] ?? '' ),
                'event_time'          => esc_html( $d['time'] ?? '' ),
                'event_location'      => esc_html( $d['location'] ?? '' ),
                'event_speakers'      => wp_kses_post( Academy_Site_HTML_Renderer::lines_html( $d['speakers'] ?? '' ) ),
                'event_price'         => esc_html( Academy_Site_HTML_Renderer::money( Academy_Site_HTML_Renderer::event_price( $tickets ) ) ),
                'event_status'        => esc_html( $label ),
                'event_status_key'    => esc_attr( $status ),
                'event_available'     => ! empty( $d['available'] ) ? '1' : '0',
                'event_url'           => esc_url( $url ),
                'event_action'        => $action,
                'event_action_url'    => esc_url( $url ),
                'event_qr_url'        => class_exists( 'Academy_Site_QR' ) ? esc_url( Academy_Site_QR::image_url( $url, 220 ) ) : '',
                'event_qr'            => class_exists( 'Academy_Site_QR' ) ? Academy_Site_QR::image_html( $url, 'academy-event-qr', 'QR رویداد', 220 ) : '',
                'event_tickets'       => $ticket_html,
                'seminar_id'          => (string) $id,
                'seminar_title'       => esc_html( $d['title'] ?? '' ),
                'seminar_description' => wp_kses_post( $d['description'] ?? '' ),
                'seminar_excerpt'     => wp_kses_post( $d['excerpt'] ?? '' ),
                'seminar_image'       => ! empty( $d['image_id'] ) ? wp_get_attachment_image( absint( $d['image_id'] ), 'full', false, array( 'class' => 'academy-event-image' ) ) : '',
                'seminar_image_url'   => ! empty( $d['image_id'] ) ? esc_url( wp_get_attachment_image_url( absint( $d['image_id'] ), 'full' ) ) : '',
                'seminar_date'        => esc_html( $d['date'] ?? '' ),
                'seminar_time'        => esc_html( $d['time'] ?? '' ),
                'seminar_location'    => esc_html( $d['location'] ?? '' ),
                'seminar_speakers'    => wp_kses_post( Academy_Site_HTML_Renderer::lines_html( $d['speakers'] ?? '' ) ),
                'seminar_price'       => esc_html( Academy_Site_HTML_Renderer::money( Academy_Site_HTML_Renderer::event_price( $tickets ) ) ),
                'seminar_status'      => esc_html( $label ),
                'seminar_status_key'  => esc_attr( $status ),
                'seminar_available'   => ! empty( $d['available'] ) ? '1' : '0',
                'seminar_url'         => esc_url( $url ),
                'seminar_action'      => $action,
                'seminar_action_url'  => esc_url( $url ),
                 'seminar_qr_url'      => class_exists( 'Academy_Site_QR' ) ? esc_url( Academy_Site_QR::image_url( $url, 220 ) ) : '',
                 'seminar_qr'          => class_exists( 'Academy_Site_QR' ) ? Academy_Site_QR::image_html( $url, 'academy-seminar-qr', 'QR همایش', 220 ) : '',
                'seminar_tickets'     => $ticket_html,
            );
        return $m;
    }
}
Academy_Site_Event_Renderer::boot();
