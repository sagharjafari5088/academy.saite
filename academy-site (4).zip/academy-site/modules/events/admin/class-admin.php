<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
// Admin UI is registered by Academy_Site_Events so Event, Ticket and Commerce
// mapping share one authorization and validation boundary.
