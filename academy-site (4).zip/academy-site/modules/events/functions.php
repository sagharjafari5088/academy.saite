<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
function academy_site_event( $event_id ) {
    return class_exists( 'Academy_Site_Events' ) ? Academy_Site_Events::get_event( $event_id ) : null;
}
function academy_site_event_ticket_types( $event_id ) {
    return class_exists( 'Academy_Site_Events' ) ? Academy_Site_Events::get_ticket_types( $event_id, true ) : array();
}
