<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Academy_Site_Lesson_Access {
	const REST_NAMESPACE = 'academy-site/v1';
	const TOKEN_TTL = 300;

	public static function boot() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );
		add_filter( 'academy_site_dynamic_data', array( __CLASS__, 'dynamic_data' ), 40, 2 );
	}

	public static function register_rest_routes() {
		register_rest_route( self::REST_NAMESPACE, '/me/courses/(?P<course_id>\\d+)/lessons/(?P<lesson_id>\\d+)', array(
			'methods' => WP_REST_Server::READABLE,
			'callback' => array( __CLASS__, 'lesson_access' ),
			'permission_callback' => array( __CLASS__, 'authenticated_permission' ),
		) );
		register_rest_route( self::REST_NAMESPACE, '/media/(?P<token>[A-Za-z0-9\\-_\\.]+)', array(
			'methods' => WP_REST_Server::READABLE,
			'callback' => array( __CLASS__, 'media_endpoint' ),
			'permission_callback' => '__return_true',
		) );
	}

	public static function authenticated_permission() { return is_user_logged_in(); }

	public static function lesson_access( WP_REST_Request $request ) {
		$user_id = get_current_user_id();
		$course_id = absint( $request['course_id'] );
		$lesson_id = absint( $request['lesson_id'] );
		if ( ! self::can_access_lesson( $user_id, $course_id, $lesson_id ) ) {
			return new WP_Error( 'academy_lesson_forbidden', 'دسترسی به این Lesson مجاز نیست.', array( 'status' => 403 ) );
		}
		$lesson = self::get_lesson( $course_id, $lesson_id );
		$progress = class_exists( 'Academy_Site_Progress' ) ? Academy_Site_Progress::get( $user_id, $course_id, $lesson_id ) : null;
		$media = self::get_protected_media_descriptor( $user_id, $course_id, $lesson_id, $lesson );
		return rest_ensure_response( array(
			'course_id' => $course_id,
			'lesson_id' => $lesson_id,
			'title' => sanitize_text_field( self::lesson_value( $lesson, 'title', 'lesson_title' ) ),
			'status' => sanitize_key( self::lesson_value( $lesson, 'status', 'status', 'draft' ) ),
			'duration' => absint( self::lesson_value( $lesson, 'duration', 'duration_seconds', 0 ) ),
			'progress' => $progress ? array(
				'status' => sanitize_key( $progress->status ),
				'position_seconds' => absint( $progress->position_seconds ),
				'completed_at' => $progress->completed_at,
				'last_viewed_at' => $progress->last_viewed_at,
			) : null,
			'media' => $media,
		) );
	}

	public static function can_access_lesson( $user_id, $course_id, $lesson_id ) {
		if ( ! absint( $user_id ) || ! absint( $course_id ) || ! absint( $lesson_id ) || ! class_exists( 'Academy_Site_Enrollment' ) ) return false;
		if ( ! Academy_Site_Enrollment::has_access( absint( $user_id ), absint( $course_id ) ) ) return false;
		$lesson = self::get_lesson( $course_id, $lesson_id );
		return $lesson && 'published' === ( self::lesson_value( $lesson, 'status', 'status', 'draft' ) );
	}

	public static function get_lesson( $course_id, $lesson_id ) {
		if ( ! class_exists( 'Academy_Site_Courses' ) ) return null;
		foreach ( Academy_Site_Courses::get_lessons( absint( $course_id ) ) as $lesson ) {
			if ( absint( self::lesson_value( $lesson, 'id', 'id', 0 ) ) === absint( $lesson_id ) ) return $lesson;
		}
		return null;
	}

	public static function get_protected_media_descriptor( $user_id, $course_id, $lesson_id, $lesson ) {
		$source = '';
		foreach ( array( 'video_attachment_id', 'video_id', 'media_id' ) as $key ) {
			if ( ! empty( self::lesson_value( $lesson, $key, $key, 0 ) ) ) { $source = 'attachment:' . absint( self::lesson_value( $lesson, $key, $key, 0 ) ); break; }
		}
		if ( ! $source && ! empty( self::lesson_value( $lesson, 'video_url', 'video_url', '' ) ) ) $source = 'url:' . esc_url_raw( self::lesson_value( $lesson, 'video_url', 'video_url', '' ) );
		if ( ! $source ) return array( 'available' => false, 'url' => '', 'expires' => 0 );
		$token = self::create_media_token( $user_id, $course_id, $lesson_id, $source );
		if ( is_wp_error( $token ) ) return array( 'available' => false, 'url' => '', 'expires' => 0 );
		return array(
			'available' => true,
			'url' => rest_url( self::REST_NAMESPACE . '/media/' . rawurlencode( $token ) ),
			'expires' => time() + self::TOKEN_TTL,
		);
	}

	public static function create_media_token( $user_id, $course_id, $lesson_id, $source ) {
		if ( ! self::can_access_lesson( $user_id, $course_id, $lesson_id ) ) return new WP_Error( 'forbidden', 'دسترسی غیرمجاز.' );
		$payload = wp_json_encode( array( 'u'=>absint($user_id), 'c'=>absint($course_id), 'l'=>absint($lesson_id), 's'=>$source, 'e'=>time()+self::TOKEN_TTL, 'n'=>wp_generate_password(16,false,false) ) );
		$encoded = self::base64url_encode( $payload );
		return $encoded . '.' . hash_hmac( 'sha256', $encoded, wp_salt( 'auth' ) );
	}

	public static function verify_media_token( $token ) {
		$parts = explode( '.', sanitize_text_field( $token ), 2 );
		if ( 2 !== count( $parts ) ) return new WP_Error( 'invalid_token', 'توکن نامعتبر است.' );
		list( $encoded, $signature ) = $parts;
		if ( ! hash_equals( hash_hmac( 'sha256', $encoded, wp_salt( 'auth' ) ), $signature ) ) return new WP_Error( 'invalid_signature', 'امضای توکن نامعتبر است.' );
		$data = json_decode( self::base64url_decode( $encoded ), true );
		if ( ! is_array( $data ) || empty($data['e']) || time() > absint($data['e']) ) return new WP_Error( 'expired_token', 'توکن نامعتبر یا منقضی شده است.' );
		if ( ! self::can_access_lesson( $data['u'] ?? 0, $data['c'] ?? 0, $data['l'] ?? 0 ) ) return new WP_Error( 'access_revoked', 'دسترسی منقضی یا لغو شده است.' );
		return $data;
	}

	public static function media_endpoint( WP_REST_Request $request ) {
		$data = self::verify_media_token( $request['token'] );
		if ( is_wp_error( $data ) ) return $data;
		$source = (string) $data['s'];
		$url = '';
		if ( 0 === strpos( $source, 'attachment:' ) ) $url = wp_get_attachment_url( absint( substr($source, 11) ) );
		elseif ( 0 === strpos( $source, 'url:' ) ) $url = esc_url_raw( substr($source, 4) );
		if ( ! $url ) return new WP_Error( 'academy_media_not_found', 'فایل رسانه‌ای پیدا نشد.', array('status'=>404) );
		$response = new WP_REST_Response( null, 302 );
		$response->header( 'Location', $url );
		$response->header( 'Cache-Control', 'private, no-store, max-age=0' );
		return $response;
	}

	private static function lesson_value( $lesson, $primary, $fallback = '', $default = '' ) {
		if ( is_array( $lesson ) ) {
			if ( array_key_exists( $primary, $lesson ) ) return $lesson[ $primary ];
			if ( $fallback && array_key_exists( $fallback, $lesson ) ) return $lesson[ $fallback ];
		} elseif ( is_object( $lesson ) ) {
			if ( isset( $lesson->{$primary} ) ) return $lesson->{$primary};
			if ( $fallback && isset( $lesson->{$fallback} ) ) return $lesson->{$fallback};
		}
		return $default;
	}

	public static function dynamic_data( $data, $context ) {
		if ( ! is_user_logged_in() || ! is_singular('academy_course') ) return $data;
		$course_id = absint(get_the_ID());
		$lesson_id = is_array($context) ? absint($context['lesson_id'] ?? 0) : 0;
		if ($lesson_id) $data['lesson_access'] = array('allowed'=>self::can_access_lesson(get_current_user_id(),$course_id,$lesson_id),'lesson'=>self::get_lesson($course_id,$lesson_id));
		return $data;
	}

	private static function base64url_encode($v){ return rtrim(strtr(base64_encode($v), '+/', '-_'), '='); }
	private static function base64url_decode($v){ return base64_decode(strtr($v, '-_', '+/')); }
}
Academy_Site_Lesson_Access::boot();
