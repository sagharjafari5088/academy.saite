(function(){
  'use strict';
  if(!window.AcademyAuth) return;
  const A=window.AcademyAuth;
  const post=(data)=>fetch(A.ajaxUrl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:new URLSearchParams(data)}).then(r=>r.json());
  const msg=(form,text,error)=>{const el=form&&form.querySelector('.academy-auth-message');if(el){el.textContent=text||'';el.classList.toggle('is-error',!!error);}};
  const otpState=()=>({phone:sessionStorage.getItem('academy_otp_phone')||'',purpose:sessionStorage.getItem('academy_otp_purpose')||'login',challenge:sessionStorage.getItem('academy_otp_challenge')||'',started:parseInt(sessionStorage.getItem('academy_otp_started')||'0',10)});
  const goOtp=(form,id)=>{sessionStorage.setItem('academy_otp_challenge',id);sessionStorage.setItem('academy_otp_started',Date.now().toString());const target=form.getAttribute('data-otp-url')||window.location.href;window.location.href=target+(target.indexOf('?')>-1?'&':'?')+'academy_otp=1';};

  document.addEventListener('submit',function(e){
    const form=e.target;
    if(form.id==='academy-login-form'||form.id==='academy-register-form'){
      e.preventDefault();const purpose=form.id==='academy-register-form'?'register':'login';const phone=form.querySelector('[name="phone"]').value;const btn=form.querySelector('[type="submit"]');if(btn)btn.disabled=true;msg(form,'در حال بررسی شماره موبایل…',false);
      post({action:'academy_request_otp',nonce:A.nonce,phone:phone,purpose:purpose}).then(r=>{
        if(!r.success)throw new Error(r.data&&r.data.message?r.data.message:'خطا در درخواست کد');
        sessionStorage.setItem('academy_otp_phone',phone);sessionStorage.setItem('academy_otp_purpose',purpose);sessionStorage.setItem('academy_otp_challenge',r.data.challenge_id);sessionStorage.setItem('academy_otp_started',Date.now().toString());
        msg(form,'کد پس از ۶ ثانیه ارسال می‌شود.',false);goOtp(form,r.data.challenge_id);
      }).catch(err=>{msg(form,err.message,true);if(btn)btn.disabled=false;});
    }
    if(form.id==='academy-otp-form'){
      e.preventDefault();const st=otpState();const btn=form.querySelector('[type="submit"]');if(btn)btn.disabled=true;
      post({action:'academy_verify_otp',nonce:A.nonce,phone:st.phone||form.querySelector('[name="phone"]')?.value||'',purpose:st.purpose,code:form.querySelector('[name="code"]').value}).then(r=>{
        if(!r.success)throw new Error(r.data&&r.data.message?r.data.message:'کد صحیح نیست');
        if(st.purpose==='register'){sessionStorage.setItem('academy_auth_challenge',r.data.challenge_id);window.location.href=form.getAttribute('data-register-url')||A.homeUrl;}
        else window.location.href=sessionStorage.getItem('academy_return_to')||r.data.redirect||A.homeUrl;
      }).catch(err=>{msg(form,err.message,true);if(btn)btn.disabled=false;});
    }
    if(form.id==='academy-complete-profile-form'){
      e.preventDefault();const fd=new FormData(form);fd.append('action','academy_complete_registration');fd.append('nonce',A.nonce);fd.append('challenge_id',sessionStorage.getItem('academy_auth_challenge')||'');const btn=form.querySelector('[type="submit"]');if(btn)btn.disabled=true;
      fetch(A.ajaxUrl,{method:'POST',body:fd}).then(r=>r.json()).then(r=>{if(!r.success)throw new Error(r.data&&r.data.message?r.data.message:'ثبت اطلاعات ناموفق بود');sessionStorage.removeItem('academy_auth_challenge');window.location.href=r.data.redirect||A.homeUrl;}).catch(err=>{msg(form,err.message,true);if(btn)btn.disabled=false;});
    }
  });

  const otpForm=document.querySelector('#academy-otp-form');
  if(otpForm){
    const st=otpState();const phoneField=otpForm.querySelector('[name="phone"]');if(phoneField)phoneField.value=st.phone;
    const started=st.started;const elapsed=started?Math.floor((Date.now()-started)/1000):0;const wait=Math.max(0,(A.delay||6)-elapsed);
    const countdown=otpForm.querySelector('[data-otp-countdown]');let left=Math.max(0,(A.delay||6)-elapsed);if(countdown)countdown.textContent=left+' ثانیه';
    if(left>0){const t=setInterval(()=>{left--;if(countdown)countdown.textContent=Math.max(0,left)+' ثانیه';if(left<=0)clearInterval(t);},1000);}
    const deliver=()=>{if(!st.challenge)return;post({action:'academy_deliver_otp',nonce:A.nonce,challenge_id:st.challenge}).then(dr=>{if(!dr.success)msg(otpForm,dr.data&&dr.data.message?dr.data.message:'ارسال کد ناموفق بود.',true);}).catch(()=>msg(otpForm,'ارسال کد ناموفق بود.',true));};
    if(wait<=0)deliver();else setTimeout(deliver,wait*1000);
    const resend=otpForm.querySelector('[data-otp-resend]');if(resend){resend.disabled=true;let cooldown=30;const rt=setInterval(()=>{cooldown--;resend.textContent=cooldown>0?'ارسال مجدد ('+cooldown+' ثانیه)':'ارسال مجدد';if(cooldown<=0){clearInterval(rt);resend.disabled=false;}},1000);resend.addEventListener('click',()=>{if(resend.disabled)return;resend.disabled=true;msg(otpForm,'در حال ارسال کد جدید…',false);post({action:'academy_resend_otp',nonce:A.nonce,phone:st.phone,purpose:st.purpose}).then(r=>{if(!r.success)throw new Error(r.data&&r.data.message?r.data.message:'ارسال مجدد ناموفق بود');sessionStorage.setItem('academy_otp_challenge',r.data.challenge_id);sessionStorage.setItem('academy_otp_started',Date.now().toString());msg(otpForm,'کد جدید پس از ۶ ثانیه ارسال می‌شود.',false);window.location.reload();}).catch(err=>{msg(otpForm,err.message,true);resend.disabled=false;});});}
  }
  const code=document.querySelector('#academy-otp-form [name=\"code\"]');if(code)code.focus();
})();
