<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Academy Site Auth — mobile OTP only.
 * Login and registration use separate SMS.ir templates.
 * OTP delivery is deliberately delayed by 6 seconds and remains valid for 2 minutes.
 */
final class Academy_Site_Auth {
    const TABLE = 'academy_otp_challenges';
    const TTL = 120;
    const SEND_DELAY = 6;
    const MAX_REQUESTS = 5;
    const MAX_ATTEMPTS = 5;
    const COOLDOWN = 30;

    public static function boot() {
        add_action( 'wp_ajax_nopriv_academy_request_otp', array( __CLASS__, 'ajax_request' ) );
        add_action( 'wp_ajax_academy_request_otp', array( __CLASS__, 'ajax_request' ) );

        add_action( 'wp_ajax_nopriv_academy_deliver_otp', array( __CLASS__, 'ajax_deliver' ) );
        add_action( 'wp_ajax_academy_deliver_otp', array( __CLASS__, 'ajax_deliver' ) );

        add_action( 'wp_ajax_nopriv_academy_resend_otp', array( __CLASS__, 'ajax_resend' ) );
        add_action( 'wp_ajax_academy_resend_otp', array( __CLASS__, 'ajax_resend' ) );

        add_action( 'wp_ajax_nopriv_academy_verify_otp', array( __CLASS__, 'ajax_verify' ) );
        add_action( 'wp_ajax_academy_verify_otp', array( __CLASS__, 'ajax_verify' ) );

        add_action( 'wp_ajax_nopriv_academy_complete_registration', array( __CLASS__, 'ajax_complete_registration' ) );
add_action( 'wp_ajax_academy_complete_registration', array( __CLASS__, 'ajax_complete_registration' ) );

        add_action( 'academy_site_otp_delivery', array( __CLASS__, 'deliver_scheduled' ), 10, 1 );
        add_action( 'academy_site_student_registered', array( __CLASS__, 'auto_login_registered' ), 5, 1 );

        add_filter( 'academy_site_dynamic_data', array( __CLASS__, 'dynamic_data' ), 5, 2 );

        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
    }

    public static function install() {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        dbDelta( "CREATE TABLE " . self::table() . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            phone VARCHAR(30) NOT NULL,
            purpose VARCHAR(20) NOT NULL,
            code_hash CHAR(64) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
            request_count TINYINT UNSIGNED NOT NULL DEFAULT 1,
            expires_at DATETIME NOT NULL,
            send_after DATETIME NOT NULL,
            delivered_at DATETIME NULL,
            verified_at DATETIME NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY phone_purpose(phone,purpose),
            KEY expires_at(expires_at),
            KEY status(status)
        ) " . $wpdb->get_charset_collate() . ";" );
    }

    public static function table() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE;
    }

    public static function assets() {
        wp_enqueue_script(
            'academy-auth',
            ACADEMY_SITE_URL . 'modules/auth/assets/auth.js',
            array(),
            ACADEMY_SITE_VERSION,
            true
        );

        wp_localize_script(
            'academy-auth',
            'AcademyAuth',
            array(
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'academy_auth' ),
                'delay'   => self::SEND_DELAY,
                'ttl'     => self::TTL,
                'homeUrl' => home_url( '/' ),
            )
        );
    }

    public static function normalize_phone( $phone ) {
        $phone = trim( (string) $phone );

        $phone = str_replace(
            array( ' ', '-', '(', ')' ),
            '',
            $phone
        );

        if ( strpos( $phone, '۰۰' ) === 0 ) {
            $phone = '00' . substr( $phone, 2 );
        }

        $phone = str_replace(
            array( '۰','۱','۲','۳','۴','۵','۶','۷','۸','۹' ),
            array( '0','1','2','3','4','5','6','7','8','9' ),
            $phone
        );

        if ( strpos( $phone, '00' ) === 0 ) {
            $phone = '+' . substr( $phone, 2 );
        }

        if ( preg_match( '/^09\d{9}$/', $phone ) ) {
            return '+98' . substr( $phone, 1 );
        }

        if ( preg_match( '/^9\d{9}$/', $phone ) ) {
            return '+98' . $phone;
        }

        if ( preg_match( '/^\+?98\d{10}$/', $phone ) ) {
            return '+' . ltrim( $phone, '+' );
        }

        return preg_replace( '/[^0-9+]/', '', $phone );
    }

    private static function crypto_key() {
        return hash(
            'sha256',
            wp_salt( 'auth' ) . '|' . wp_salt( 'secure_auth' ),
            true
        );
    }

    private static function protect_code( $code ) {
        if ( function_exists( 'openssl_encrypt' ) ) {
            $iv = random_bytes( 16 );

            $cipher = openssl_encrypt(
                (string) $code,
                'AES-256-CBC',
                self::crypto_key(),
                OPENSSL_RAW_DATA,
                $iv
            );

            if ( false !== $cipher ) {
                return base64_encode( $iv . $cipher );
            }
        }

        return hash_hmac(
            'sha256',
            (string) $code,
            self::crypto_key()
        ) . ':' . base64_encode( (string) $code );
    }

    private static function unprotect_code( $value ) {
        if ( ! is_string( $value ) || '' === $value ) {
            return false;
        }

        if ( function_exists( 'openssl_decrypt' ) ) {
            $raw = base64_decode( $value, true );

            if ( false !== $raw && strlen( $raw ) > 16 ) {
                $plain = openssl_decrypt(
                    substr( $raw, 16 ),
                    'AES-256-CBC',
                    self::crypto_key(),
                    OPENSSL_RAW_DATA,
                    substr( $raw, 0, 16 )
                );

                if ( false !== $plain ) {
                    return $plain;
                }
            }
        }

        if ( false !== strpos( $value, ':' ) ) {
            $parts = explode( ':', $value, 2 );

            $code = base64_decode( $parts[1], true );

            if (
                false !== $code &&
                hash_equals(
                    $parts[0],
                    hash_hmac(
                        'sha256',
                        $code,
                        self::crypto_key()
                    )
                )
            ) {
                return $code;
            }
        }

        return false;
    }

    public static function nonce_ok( $nonce ) {
        return wp_verify_nonce(
            sanitize_text_field( wp_unslash( $nonce ) ),
            'academy_auth'
        );
    }

    public static function user_by_phone( $phone ) {
        $users = get_users(
            array(
                'number'     => 1,
                'meta_key'   => 'academy_phone',
                'meta_value' => $phone,
                'fields'     => 'ids',
            )
        );

        return $users ? absint( $users[0] ) : 0;
    }

    public static function request( $phone, $purpose = 'login' ) {
        global $wpdb;

        $phone = self::normalize_phone( $phone );

        $purpose = in_array(
            $purpose,
            array( 'login', 'register' ),
            true
        ) ? $purpose : 'login';

        if ( ! preg_match( '/^\+989\d{9}$/', $phone ) ) {
            return new WP_Error(
                'invalid_phone',
                'شماره موبایل معتبر نیست.'
            );
        }

        $exists = self::user_by_phone( $phone );

        if ( 'login' === $purpose && ! $exists ) {
            return new WP_Error(
                'not_registered',
                'این شماره هنوز ثبت‌نام نکرده است. ابتدا ثبت‌نام کنید.'
            );
        }

        if ( 'register' === $purpose && $exists ) {
            return new WP_Error(
                'already_registered',
                'این شماره قبلاً ثبت‌نام شده است. وارد شوید.'
            );
        }

        $now = time();

        $recent = (int) $wpdb->get_var(
            $wpdb->prepare(
                'SELECT COUNT(*) FROM ' . self::table() . ' WHERE phone=%s AND purpose=%s AND created_at >= %s',
                $phone,
                $purpose,
                gmdate(
                    'Y-m-d H:i:s',
                    $now - HOUR_IN_SECONDS
                )
            )
        );

        if ( $recent >= self::MAX_REQUESTS ) {
            return new WP_Error(
                'rate_limited',
                'تعداد درخواست‌های OTP بیش از حد مجاز است. بعداً دوباره تلاش کنید.'
            );
        }

        $last = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . self::table() . ' WHERE phone=%s AND purpose=%s ORDER BY id DESC LIMIT 1',
                $phone,
                $purpose
            )
        );

        if (
            $last &&
            ( $now - strtotime( $last->created_at . ' UTC' ) ) < self::COOLDOWN
        ) {
            return new WP_Error(
                'cooldown',
                'لطفاً کمی بعد دوباره درخواست دهید.'
            );
        }

        $wpdb->query(
            $wpdb->prepare(
                "UPDATE " . self::table() . " SET status='cancelled' WHERE phone=%s AND purpose=%s AND status='pending'",
                $phone,
                $purpose
            )
        );

        $code = (string) wp_rand( 100000, 999999 );

        $created = gmdate(
            'Y-m-d H:i:s',
            $now
        );

        $expires = gmdate(
            'Y-m-d H:i:s',
            $now + self::TTL
        );

        $send_after = gmdate(
            'Y-m-d H:i:s',
            $now + self::SEND_DELAY
        );

        $ok = $wpdb->insert(
            self::table(),
            array(
                'phone'         => $phone,
                'purpose'       => $purpose,
                'code_hash'     => hash( 'sha256', $code ),
                'status'        => 'pending',
                'attempts'      => 0,
                'request_count' => $recent + 1,
                'expires_at'    => $expires,
                'send_after'    => $send_after,
                'created_at'    => $created,
            ),
            array(
                '%s',
                '%s',
                '%s',
                '%s',
                '%d',
                '%d',
                '%s',
                '%s',
                '%s',
            )
        );

        if ( false === $ok ) {
            return new WP_Error(
                'db_error',
                'ایجاد درخواست OTP ناموفق بود.'
            );
        }

        $id = (int) $wpdb->insert_id;

        set_transient(
            'academy_otp_delivery_' . $id,
            array(
                'code'    => self::protect_code( $code ),
                'phone'   => $phone,
                'purpose' => $purpose,
                'user_id' => $exists,
            ),
            self::TTL
        );

        wp_schedule_single_event(
            $now + self::SEND_DELAY,
            'academy_site_otp_delivery',
            array( $id )
        );

        return array(
            'challenge_id' => $id,
            'expires_in'   => self::TTL,
            'send_after'   => self::SEND_DELAY,
        );
    }

    public static function deliver( $challenge_id ) {
        global $wpdb;

        $row = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . self::table() . ' WHERE id=%d LIMIT 1',
                absint( $challenge_id )
            )
        );

        if ( ! $row || 'pending' !== $row->status ) {
            return new WP_Error(
                'otp_unavailable',
                'درخواست OTP معتبر نیست.'
            );
        }

        if ( strtotime( $row->expires_at . ' UTC' ) <= time() ) {
            return new WP_Error(
                'otp_expired',
                'درخواست OTP منقضی شده است.'
            );
        }

        if ( strtotime( $row->send_after . ' UTC' ) > time() ) {
            return new WP_Error(
                'otp_not_ready',
                'ارسال OTP هنوز آماده نیست.'
            );
        }

        if ( $row->delivered_at ) {
            return array( 'delivered' => true );
        }

        $payload = get_transient(
            'academy_otp_delivery_' . $row->id
        );

        if ( ! is_array( $payload ) || empty( $payload['code'] ) ) {
            return new WP_Error(
                'otp_delivery_data_missing',
                'اطلاعات ارسال OTP پیدا نشد.'
            );
        }

        $plain_code = self::unprotect_code(
            $payload['code']
        );

        if ( false === $plain_code || '' === $plain_code ) {
            return new WP_Error(
                'otp_delivery_data_invalid',
                'اطلاعات امن OTP قابل بازیابی نیست.'
            );
        }

        $key = 'register' === $row->purpose
            ? 'register_otp'
            : 'login_otp';

        $user = $row->user_id
            ? get_userdata( $row->user_id )
            : false;

        $first = $user
            ? ( $user->first_name ?: $user->display_name )
            : '';

        if ( ! class_exists( 'Academy_Site_SMS' ) ) {
            return new WP_Error(
                'sms_unavailable',
                'سرویس پیامک در دسترس نیست.'
            );
        }

        $result = Academy_Site_SMS::send_template(
            absint( $row->user_id ),
            $key,
            array(
                'Code'      => $plain_code,
                'FirstName' => $first,
                'Name'      => $first,
            ),
            array(
                'phone'          => $row->phone,
                'idempotency_key'=> 'otp:' . $row->id,
            )
        );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        $wpdb->update(
            self::table(),
            array(
                'delivered_at' => gmdate( 'Y-m-d H:i:s' ),
            ),
            array(
                'id' => $row->id,
            ),
            array( '%s' ),
            array( '%d' )
        );

        return array(
            'delivered' => true,
        );
    }

    public static function deliver_scheduled( $challenge_id ) {
        self::deliver( $challenge_id );
    }

    public static function verify( $phone, $purpose, $code ) {
        global $wpdb;

        $phone = self::normalize_phone( $phone );

        $purpose = in_array(
            $purpose,
            array( 'login', 'register' ),
            true
        ) ? $purpose : 'login';

        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM " . self::table() . " WHERE phone=%s AND purpose=%s AND status='pending' ORDER BY id DESC LIMIT 1",
                $phone,
                $purpose
            )
        );

        if ( ! $row ) {
            return new WP_Error(
                'otp_not_found',
                'کد معتبر نیست.'
            );
        }

        if ( strtotime( $row->expires_at . ' UTC' ) <= time() ) {
            return new WP_Error(
                'otp_expired',
                'کد منقضی شده است.'
            );
        }

        if ( ! $row->delivered_at ) {
            return new WP_Error(
                'otp_not_delivered',
                'کد هنوز ارسال نشده است.'
            );
        }

        if ( (int) $row->attempts >= self::MAX_ATTEMPTS ) {
            return new WP_Error(
                'otp_locked',
                'تعداد تلاش بیش از حد مجاز است.'
            );
        }

        $wpdb->update(
            self::table(),
            array(
                'attempts' => (int) $row->attempts + 1,
            ),
            array(
                'id' => (int) $row->id,
            ),
            array( '%d' ),
            array( '%d' )
        );

        if (
            ! hash_equals(
                $row->code_hash,
                hash( 'sha256', (string) $code )
            )
        ) {
            return new WP_Error(
                'otp_invalid',
                'کد واردشده صحیح نیست.'
            );
        }

        $wpdb->update(
            self::table(),
            array(
                'status'      => 'verified',
                'verified_at' => gmdate( 'Y-m-d H:i:s' ),
            ),
            array(
                'id' => (int) $row->id,
            ),
            array( '%s', '%s' ),
            array( '%d' )
        );

        return array(
            'challenge_id' => (int) $row->id,
            'phone'        => $phone,
            'purpose'      => $purpose,
        );
    }

    public static function ajax_request() {
        if ( ! self::nonce_ok( $_POST['nonce'] ?? '' ) ) {
            wp_send_json_error(
                array(
                    'message' => 'درخواست نامعتبر است.',
                ),
                403
            );
        }

        $r = self::request(
            $_POST['phone'] ?? '',
            $_POST['purpose'] ?? 'login'
        );

        is_wp_error( $r )
            ? wp_send_json_error(
                array(
                    'message' => $r->get_error_message(),
                    'code'    => $r->get_error_code(),
                ),
                429
            )
            : wp_send_json_success( $r );
    }

    public static function ajax_deliver() {
        if ( ! self::nonce_ok( $_POST['nonce'] ?? '' ) ) {
            wp_send_json_error(
                array(
                    'message' => 'درخواست نامعتبر است.',
                ),
                403
            );
        }

        $r = self::deliver(
            absint( $_POST['challenge_id'] ?? 0 )
        );

        is_wp_error( $r )
            ? wp_send_json_error(
                array(
                    'message' => $r->get_error_message(),
                ),
                400
            )
            : wp_send_json_success( $r );
    }

    public static function ajax_resend() {
        if ( ! self::nonce_ok( $_POST['nonce'] ?? '' ) ) {
            wp_send_json_error(
                array(
                    'message' => 'درخواست نامعتبر است.',
                ),
                403
            );
        }

        $r = self::request(
            $_POST['phone'] ?? '',
            $_POST['purpose'] ?? 'login'
        );

        if ( is_wp_error( $r ) ) {
            wp_send_json_error(
                array(
                    'message' => $r->get_error_message(),
                    'code'    => $r->get_error_code(),
                ),
                429
            );
        }

        wp_send_json_success( $r );
    }

    public static function ajax_verify() {
        if ( ! self::nonce_ok( $_POST['nonce'] ?? '' ) ) {
            wp_send_json_error(
                array(
                    'message' => 'درخواست نامعتبر است.',
                ),
                403
            );
        }

        $r = self::verify(
            $_POST['phone'] ?? '',
            $_POST['purpose'] ?? 'login',
            $_POST['code'] ?? ''
        );

        if ( is_wp_error( $r ) ) {
            wp_send_json_error(
                array(
                    'message' => $r->get_error_message(),
                ),
                403
            );
        }

        if ( 'login' === $r['purpose'] ) {
            $uid = self::user_by_phone(
                $r['phone']
            );

            if ( ! $uid ) {
                wp_send_json_error(
                    array(
                        'message' => 'کاربر یافت نشد.',
                    ),
                    404
                );
            }

            wp_set_auth_cookie(
                $uid,
                true
            );

            wp_send_json_success(
                array(
                    'user_id' => $uid,
                    'redirect' => home_url( '/' ),
                )
            );
        }

        set_transient(
            'academy_auth_verified_' . $r['challenge_id'],
            array(
                'phone'   => $r['phone'],
                'purpose' => $r['purpose'],
            ),
            10 * MINUTE_IN_SECONDS
        );

        wp_send_json_success(
            array(
                'challenge_id' => $r['challenge_id'],
                'redirect'     => home_url( '/' ),
            )
        );
    }

    /**
     * Complete registration.
     *
     * Required fields:
     * first_name
     * last_name
     * phone
     * birth_date
     * gender
     * province
     * city
     */
    public static function ajax_complete_registration() {

        /* امنیت درخواست */
        if ( ! self::nonce_ok( $_POST['nonce'] ?? '' ) ) {
            wp_send_json_error(
                array(
                    'message' => 'درخواست نامعتبر است.',
                ),
                403
            );
        }

        /* شناسه احراز OTP */
        $cid = absint(
            $_POST['challenge_id'] ?? 0
        );

        /* بررسی احراز OTP */
        $v = get_transient(
            'academy_auth_verified_' . $cid
        );

        if ( ! $v || 'register' !== $v['purpose'] ) {
            wp_send_json_error(
                array(
                    'message' => 'احراز شماره منقضی شده است.',
                ),
                403
            );
        }

        /* شماره موبایل تأییدشده */
        $phone = self::normalize_phone(
            $v['phone']
        );

        $submitted_phone = self::normalize_phone(
            $_POST['phone'] ?? ''
        );

        if ( ! $submitted_phone ) {
            wp_send_json_error(
                array(
                    'message' => 'شماره موبایل الزامی است.',
                ),
                422
            );
        }

        if ( $submitted_phone !== $phone ) {
            wp_send_json_error(
                array(
                    'message' => 'شماره موبایل با شماره تأییدشده یکسان نیست.',
                ),
                422
            );
        }

        /* جلوگیری از ثبت شماره تکراری */
        if ( self::user_by_phone( $phone ) ) {
            wp_send_json_error(
                array(
                    'message' => 'این شماره قبلاً ثبت شده است.',
                ),
                409
            );
        }

        /* دریافت اطلاعات فرم */
        $first = sanitize_text_field(
            wp_unslash(
                $_POST['first_name'] ?? ''
            )
        );

        $last = sanitize_text_field(
            wp_unslash(
                $_POST['last_name'] ?? ''
            )
        );

        $birth_date = sanitize_text_field(
            wp_unslash(
                $_POST['birth_date'] ?? ''
            )
        );

        $gender = sanitize_text_field(
            wp_unslash(
                $_POST['gender'] ?? ''
            )
        );

        $province = sanitize_text_field(
            wp_unslash(
                $_POST['province'] ?? ''
            )
        );

        $city = sanitize_text_field(
            wp_unslash(
                $_POST['city'] ?? ''
            )
        );

        /*
         * بررسی اجباری بودن تمام فیلدها
         *
         * این بررسی سمت سرور است؛
         * بنابراین حتی اگر required از HTML حذف شود،
         * ثبت‌نام با اطلاعات ناقص انجام نمی‌شود.
         */

        if ( '' === $first ) {
            wp_send_json_error(
                array(
                    'message' => 'نام الزامی است.',
                ),
                422
            );
        }

        if ( '' === $last ) {
            wp_send_json_error(
                array(
                    'message' => 'نام خانوادگی الزامی است.',
                ),
                422
            );
        }

        if ( '' === $phone ) {
            wp_send_json_error(
                array(
                    'message' => 'شماره موبایل الزامی است.',
                ),
                422
            );
        }

        if ( '' === $birth_date ) {
            wp_send_json_error(
                array(
                    'message' => 'تاریخ تولد الزامی است.',
                ),
                422
            );
        }

        if ( '' === $gender ) {
            wp_send_json_error(
                array(
                    'message' => 'جنسیت الزامی است.',
                ),
                422
            );
        }

        if ( '' === $province ) {
            wp_send_json_error(
                array(
                    'message' => 'استان الزامی است.',
                ),
                422
            );
        }

        if ( '' === $city ) {
            wp_send_json_error(
                array(
                    'message' => 'شهر الزامی است.',
                ),
                422
            );
        }

        /* ایجاد کاربر وردپرس */
        $uid = wp_insert_user(
            array(
                'user_login' => 'academy_' . wp_generate_password(
                    10,
                    false,
                    false
                ),
                'user_pass' => wp_generate_password(
                    32,
                    true,
                    true
                ),
                'display_name' => trim(
                    $first . ' ' . $last
                ),
                'first_name' => $first,
                'last_name' => $last,
                'role' => get_option(
                    'default_role',
                    'subscriber'
                ),
            )
        );

        if ( is_wp_error( $uid ) ) {
            wp_send_json_error(
                array(
                    'message' => $uid->get_error_message(),
                ),
                500
            );
        }

        /* ذخیره اطلاعات دانشجو */
        update_user_meta(
            $uid,
            'academy_phone',
            $phone
        );

        update_user_meta(
            $uid,
            'mobile',
            $phone
        );

        update_user_meta(
            $uid,
            'birth_date',
            $birth_date
        );

        update_user_meta(
            $uid,
            'gender',
            $gender
        );

        update_user_meta(
            $uid,
            'city',
            $city
        );

        update_user_meta(
            $uid,
            'province',
            $province
        );

        update_user_meta(
            $uid,
            'academy_status',
            'active'
        );

        /* پاکسازی اطلاعات موقت */
        delete_transient(
            'academy_auth_verified_' . $cid
        );

        delete_transient(
            'academy_otp_delivery_' . $cid
        );

        /* ورود خودکار دانشجو */
        wp_set_auth_cookie(
            $uid,
            true
        );

        /* رویداد ثبت دانشجو */
        do_action(
            'academy_site_student_registered',
            $uid
        );

        /* انتقال به صفحه خوش‌آمد */
        wp_send_json_success(
            array(
                'user_id' => $uid,
                'name' => trim(
                    $first . ' ' . $last
                ),
                'redirect' => add_query_arg(
                    'academy_registered',
                    '1',
                    get_option(
                        'academy_site_welcome_url',
                        home_url( '/' )
                    )
                ),
            )
        );
    }

    public static function auto_login_registered( $user_id ) {
        if (
            ! is_user_logged_in() &&
            $user_id
        ) {
            wp_set_auth_cookie(
                absint( $user_id ),
                true
            );
        }
    }

    public static function dynamic_data( $data ) {
        if ( is_user_logged_in() ) {

            $u = get_userdata(
                get_current_user_id()
            );

            $data['student_name'] = $u
                ? $u->display_name
                : '';

            $data['student_first_name'] = $u
                ? $u->first_name
                : '';

            $data['student_last_name'] = $u
                ? $u->last_name
                : '';

            $data['student_phone'] = $u
                ? get_user_meta(
                    $u->ID,
                    'academy_phone',
                    true
                )
                : '';

            $data['student_birth_date'] = $u
                ? get_user_meta(
                    $u->ID,
                    'birth_date',
                    true
                )
                : '';

            $data['student_gender'] = $u
                ? get_user_meta(
                    $u->ID,
                    'gender',
                    true
                )
                : '';

            $data['student_province'] = $u
                ? get_user_meta(
                    $u->ID,
                    'province',
                    true
                )
                : '';

            $data['student_city'] = $u
                ? get_user_meta(
                    $u->ID,
                    'city',
                    true
                )
                : '';

            $data['student_status'] = $u
                ? (
                    get_user_meta(
                        $u->ID,
                        'academy_status',
                        true
                    ) ?: 'active'
                )
                : '';
        }

        return $data;
    }
}

Academy_Site_Auth::boot();