<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** CRM segmentation + campaigns. Data and business logic are presentation-agnostic. */
final class Academy_Site_Campaigns {
    const CAMPAIGN_TABLE = 'academy_campaigns';
    const EXECUTION_TABLE = 'academy_campaign_executions';
    const GROUP_TABLE = 'academy_crm_groups';
    const USER_GROUP_TABLE = 'academy_crm_user_groups';
    const CRON = 'academy_site_campaign_scheduler';

    public static function boot() {
        add_action( 'init', array( __CLASS__, 'register_cpt' ) );
        add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ), 40 );
        add_action( self::CRON, array( __CLASS__, 'run_scheduler' ) );
        add_action( 'init', array( __CLASS__, 'ensure_columns' ), 20 );
        if ( ! wp_next_scheduled( self::CRON ) ) wp_schedule_event( time() + 900, 'hourly', self::CRON );
    }

    public static function tables() {
        global $wpdb;
        return array(
            'campaigns' => $wpdb->prefix . self::CAMPAIGN_TABLE,
            'executions' => $wpdb->prefix . self::EXECUTION_TABLE,
            'groups' => $wpdb->prefix . self::GROUP_TABLE,
            'user_groups' => $wpdb->prefix . self::USER_GROUP_TABLE,
        );
    }

    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $t = self::tables(); $c = $wpdb->get_charset_collate();
        dbDelta( "CREATE TABLE {$t['campaigns']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, title VARCHAR(190) NOT NULL, status VARCHAR(20) NOT NULL DEFAULT 'draft', segment LONGTEXT NOT NULL, template_key VARCHAR(80) NOT NULL DEFAULT 'crm_campaign', template_id VARCHAR(80) NULL, wallet_amount DECIMAL(20,2) NOT NULL DEFAULT 0.00, wallet_expires_at DATETIME NULL, starts_at DATETIME NULL, ends_at DATETIME NULL, schedule_type VARCHAR(30) NOT NULL DEFAULT 'manual', settings LONGTEXT NULL, created_by BIGINT UNSIGNED NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, PRIMARY KEY(id), KEY status_schedule(status,starts_at), KEY ends_at(ends_at) ) $c;" );
        dbDelta( "CREATE TABLE {$t['executions']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, campaign_id BIGINT UNSIGNED NOT NULL, user_id BIGINT UNSIGNED NOT NULL, sms_status VARCHAR(20) NOT NULL DEFAULT 'pending', wallet_status VARCHAR(20) NOT NULL DEFAULT 'pending', sms_log_id BIGINT UNSIGNED NULL, wallet_transaction_id BIGINT UNSIGNED NULL, idempotency_key VARCHAR(190) NOT NULL, executed_at DATETIME NULL, error_message TEXT NULL, created_at DATETIME NOT NULL, PRIMARY KEY(id), UNIQUE KEY campaign_user(campaign_id,user_id), UNIQUE KEY idempotency(idempotency_key), KEY campaign_status(campaign_id,sms_status,wallet_status), KEY user_id(user_id) ) $c;" );
        dbDelta( "CREATE TABLE {$t['groups']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(190) NOT NULL, slug VARCHAR(190) NOT NULL, description TEXT NULL, created_by BIGINT UNSIGNED NULL, created_at DATETIME NOT NULL, PRIMARY KEY(id), UNIQUE KEY slug(slug) ) $c;" );
        dbDelta( "CREATE TABLE {$t['user_groups']} (
            group_id BIGINT UNSIGNED NOT NULL, user_id BIGINT UNSIGNED NOT NULL, created_at DATETIME NOT NULL, PRIMARY KEY(group_id,user_id), KEY user_id(user_id), KEY group_id(group_id) ) $c;" );
    }

    public static function ensure_columns(){global $wpdb;$table=self::tables()['campaigns'];$exists=$wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM {$table} LIKE %s",'template_id'));if(!$exists)$wpdb->query("ALTER TABLE {$table} ADD template_id VARCHAR(80) NULL AFTER template_key");}

    public static function register_cpt() { register_post_type( 'academy_campaign', array( 'labels'=>array('name'=>'Campaigns','singular_name'=>'Campaign'), 'public'=>false, 'show_ui'=>false, 'supports'=>array('title') ) ); }

    public static function create_group( $name, $description = '' ) {
        global $wpdb; $name = sanitize_text_field( $name ); if ( '' === $name ) return new WP_Error('group_name','نام گروه الزامی است.');
        $slug = sanitize_title( $name ); if ( '' === $slug ) $slug = 'group-' . wp_generate_password(6,false,false);
        $ok = $wpdb->insert(self::tables()['groups'], array('name'=>$name,'slug'=>$slug,'description'=>sanitize_textarea_field($description),'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql',true)), array('%s','%s','%s','%d','%s'));
        return false === $ok ? new WP_Error('group_create','ایجاد گروه ناموفق بود.') : (int)$wpdb->insert_id;
    }

    public static function groups() { global $wpdb; return $wpdb->get_results('SELECT * FROM '.self::tables()['groups'].' ORDER BY name ASC'); }

    public static function add_user_to_group( $user_id, $group_id ) { global $wpdb; return $wpdb->replace(self::tables()['user_groups'],array('group_id'=>absint($group_id),'user_id'=>absint($user_id),'created_at'=>current_time('mysql',true)),array('%d','%d','%s')); }
    public static function remove_user_from_group( $user_id, $group_id ) { global $wpdb; return $wpdb->delete(self::tables()['user_groups'],array('group_id'=>absint($group_id),'user_id'=>absint($user_id)),array('%d','%d')); }
    public static function group_user_ids( $group_id ) { global $wpdb; return array_map('intval',(array)$wpdb->get_col($wpdb->prepare('SELECT user_id FROM '.self::tables()['user_groups'].' WHERE group_id=%d',absint($group_id)))); }

    public static function create( $args ) {
        global $wpdb;
        $a=wp_parse_args($args,array('title'=>'','status'=>'draft','segment'=>array(),'template_key'=>'crm_campaign','template_id'=>'','wallet_amount'=>0,'wallet_expires_at'=>null,'starts_at'=>null,'ends_at'=>null,'schedule_type'=>'manual','settings'=>array(),'created_by'=>get_current_user_id()));
        if(!$a['title']) return new WP_Error('invalid_campaign','عنوان کمپین الزامی است.');
        $now=current_time('mysql',true); $ok=$wpdb->insert(self::tables()['campaigns'],array('title'=>sanitize_text_field($a['title']),'status'=>sanitize_key($a['status']),'segment'=>wp_json_encode($a['segment'],JSON_UNESCAPED_UNICODE),'template_key'=>sanitize_key($a['template_key']),'template_id'=>preg_replace('/[^0-9]/','',(string)$a['template_id']),'wallet_amount'=>number_format(max(0,(float)$a['wallet_amount']),2,'.',''),'wallet_expires_at'=>self::date($a['wallet_expires_at']),'starts_at'=>self::date($a['starts_at']),'ends_at'=>self::date($a['ends_at']),'schedule_type'=>sanitize_key($a['schedule_type']),'settings'=>wp_json_encode($a['settings'],JSON_UNESCAPED_UNICODE),'created_by'=>absint($a['created_by'])?:null,'created_at'=>$now,'updated_at'=>$now),array('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%d','%s','%s'));
        return false===$ok?new WP_Error('campaign_create','ایجاد کمپین ناموفق بود.'):(int)$wpdb->insert_id;
    }
    public static function get($id){global $wpdb;$r=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.self::tables()['campaigns'].' WHERE id=%d',absint($id)));if($r){$r->segment=json_decode($r->segment,true)?:array();$r->settings=json_decode($r->settings,true)?:array();}return $r;}
    private static function date($v){if(!$v)return null;$ts=strtotime($v);return $ts?gmdate('Y-m-d H:i:s',$ts):null;}

    /** Flexible CRM segment. */
    public static function users_for_campaign($campaign){
        $s=$campaign->segment; $args=array('number'=>-1,'fields'=>array('ID','display_name','user_login','first_name','last_name')); $meta=array();
        if(!empty($s['gender']) && is_array($s['gender'])) $meta[]=array('key'=>'gender','value'=>array_map('sanitize_text_field',$s['gender']),'compare'=>'IN');
        if(!empty($s['province'])) $meta[]=array('key'=>'province','value'=>sanitize_text_field($s['province']),'compare'=>'=');
        if(!empty($s['city'])) $meta[]=array('key'=>'city','value'=>sanitize_text_field($s['city']),'compare'=>'=');
        if(!empty($s['status'])) $meta[]=array('key'=>'academy_status','value'=>sanitize_text_field($s['status']),'compare'=>'=');
        if(!empty($s['group_id'])) { $ids=self::group_user_ids($s['group_id']); if(!$ids)return array(); $args['include']=$ids; }
        if($meta)$args['meta_query']=$meta;
        $users=get_users($args);$out=array();$now=current_time('timestamp');
        foreach($users as $u){
            if(!empty($s['registered_after']) && strtotime($u->user_registered) < strtotime($s['registered_after'].' 00:00:00'))continue;
            if(!empty($s['registered_before']) && strtotime($u->user_registered) > strtotime($s['registered_before'].' 23:59:59'))continue;
            if(!empty($s['birthday_today'])){ $birth=get_user_meta($u->ID,'birth_date',true); if(!$birth || !self::same_birthday($birth))continue; }
            if(!empty($s['age_min']) || !empty($s['age_max'])){ $birth=get_user_meta($u->ID,'birth_date',true); if(!$birth)continue; $age=self::age($birth); if(!empty($s['age_min'])&&$age<(int)$s['age_min'])continue;if(!empty($s['age_max'])&&$age>(int)$s['age_max'])continue; }
            if(!empty($s['has_course'])){ $ok=class_exists('Academy_Site_Enrollment')&&Academy_Site_Enrollment::has_access($u->ID,absint($s['has_course']));if(!$ok)continue; }
            if(!empty($s['completed_course'])){ $ok=class_exists('Academy_Site_Progress')&&100===Academy_Site_Progress::calculate($u->ID,absint($s['completed_course']));if(!$ok)continue; }
            if(!empty($s['event_id'])){global $wpdb;$table=$wpdb->prefix.'academy_event_registrations';$ok=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE user_id=%d AND event_id=%d AND status IN ('registered','confirmed')",$u->ID,absint($s['event_id'])));if(!$ok)continue;}
            $out[]=$u;
        }
        return $out;
    }
    private static function age($birth){$birth=trim((string)$birth);if(preg_match('/^(13|14)\d{2}[\/-](\d{1,2})[\/-](\d{1,2})$/',$birth,$m)){ $gy=(int)$m[1]; $jy=(int)$m[0]; $current=(int)wp_date('Y',current_time('timestamp'),wp_timezone()); $approx_jy=$current-621; return max(0,$approx_jy-$jy-((int)wp_date('md',current_time('timestamp'),wp_timezone()) < ((int)$m[1]*100+(int)$m[2]) ? 1:0)); } $ts=strtotime($birth);if(!$ts)return 0;$b=new DateTime('@'.$ts);$n=new DateTime('now',new DateTimeZone(wp_timezone_string()));$b->setTimezone(new DateTimeZone(wp_timezone_string()));return $n->diff($b)->y;}
    private static function same_birthday($birth){$birth=trim((string)$birth);if(preg_match('/^(?:13|14)\d{2}[\/-](\d{1,2})[\/-](\d{1,2})$/',$birth,$m)){return sprintf('%02d-%02d',(int)$m[1],(int)$m[2])===wp_date('m-d',current_time('timestamp'),wp_timezone());}$ts=strtotime($birth);return $ts?wp_date('m-d',$ts,wp_timezone())===wp_date('m-d',current_time('timestamp'),wp_timezone()):false;}

    public static function parameters_for_user($user_id,$campaign){
        $u=get_userdata($user_id);if(!$u)return array();$birth=get_user_meta($user_id,'birth_date',true);return array(
            'FirstName'=>$u->first_name?:$u->display_name,'LastName'=>$u->last_name,'Name'=>$u->display_name,'Gender'=>get_user_meta($user_id,'gender',true),
            'Province'=>get_user_meta($user_id,'province',true),'City'=>get_user_meta($user_id,'city',true),'BirthDate'=>$birth,'Age'=>$birth?self::age($birth):'',
            'Campaign'=>$campaign->title,
        );
    }

    public static function run_scheduler(){global $wpdb;$t=self::tables();$now=current_time('mysql',true);$campaigns=$wpdb->get_results($wpdb->prepare("SELECT id FROM {$t['campaigns']} WHERE status='active' AND (starts_at IS NULL OR starts_at<=%s) AND (ends_at IS NULL OR ends_at>=%s) ORDER BY id ASC",$now,$now));foreach($campaigns as $c)self::execute_campaign($c->id);}
    public static function execute_campaign($campaign_id){$c=self::get($campaign_id);if(!$c||'active'!==$c->status)return new WP_Error('campaign_inactive','کمپین فعال نیست.');$users=self::users_for_campaign($c);$count=0;foreach($users as $u){$r=self::execute_for_user($c,$u->ID);if(!is_wp_error($r))$count++;}return $count;}
    private static function execute_for_user($c,$user_id){global $wpdb;$t=self::tables();$key=hash('sha256',$c->id.':'.$user_id);$existing=$wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['executions']} WHERE idempotency_key=%s LIMIT 1",$key));if($existing)return(int)$existing;$wpdb->insert($t['executions'],array('campaign_id'=>$c->id,'user_id'=>$user_id,'idempotency_key'=>$key,'created_at'=>current_time('mysql',true)),array('%d','%d','%s','%s'));$exec=(int)$wpdb->insert_id;if(!$exec)return new WP_Error('execution_create','ثبت اجرای کمپین ناموفق بود.');$errors=array();$sms_status='skipped';
        if(class_exists('Academy_Site_SMS')){$params=self::parameters_for_user($user_id,$c);$r=Academy_Site_SMS::send_template($user_id,$c->template_key,$params,array('campaign_id'=>$c->id,'template_id'=>$c->template_id));if(is_wp_error($r)){$sms_status='failed';$errors[]=$r->get_error_message();}else{$sms_status='sent';}}
        $wpdb->update($t['executions'],array('sms_status'=>$sms_status,'executed_at'=>current_time('mysql',true),'error_message'=>$errors?implode(' | ',$errors):null),array('id'=>$exec),array('%s','%s','%s'),array('%d'));return$exec;
    }

    public static function admin_menu(){add_menu_page('Academy CRM','Academy CRM','manage_options','academy-site-crm',array(__CLASS__,'admin_page'),'dashicons-groups',58);}
    public static function admin_page(){if(!current_user_can('manage_options'))return;$tab=sanitize_key($_GET['tab']??'students');if(isset($_POST['create_group'])){check_admin_referer('academy_crm');self::create_group($_POST['group_name']??'',$_POST['group_description']??'');echo'<div class="notice notice-success"><p>گروه ذخیره شد.</p></div>';}
        echo'<div class="wrap"><h1>Academy CRM</h1><nav class="nav-tab-wrapper">';foreach(array('students'=>'دانشجویان','groups'=>'گروه‌ها','campaigns'=>'کمپین‌ها')as$k=>$v)echo'<a class="nav-tab '.($tab===$k?'nav-tab-active':''). '" href="'.esc_url(add_query_arg(array('page'=>'academy-site-crm','tab'=>$k),admin_url('admin.php'))).'">'.esc_html($v).'</a>';echo'</nav>';
        if('groups'===$tab)self::groups_page();elseif('campaigns'===$tab)self::campaigns_page();else self::students_page();echo'</div>';}
    private static function groups_page(){echo'<h2>گروه‌های CRM</h2><form method="post">';wp_nonce_field('academy_crm');echo'<p><input name="group_name" class="regular-text" placeholder="نام گروه" required> <input name="group_description" class="regular-text" placeholder="توضیح"></p><p><button class="button button-primary" name="create_group" value="1">ایجاد گروه</button></p></form><table class="widefat striped"><thead><tr><th>گروه</th><th>تعداد اعضا</th></tr></thead><tbody>';global$wpdb;foreach(self::groups()as$g){$n=(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM '.self::tables()['user_groups'].' WHERE group_id=%d',$g->id));echo'<tr><td>'.esc_html($g->name).'</td><td>'.$n.'</td></tr>';}echo'</tbody></table>';}
    private static function students_page(){
        global $wpdb;
        if(isset($_POST['assign_group'])){
            check_admin_referer('academy_crm_assign_group');
            $gid=absint($_POST['assign_group_id']??0); $uids=array_map('absint',(array)($_POST['user_ids']??array()));
            foreach($uids as $uid) if($gid&&$uid) self::add_user_to_group($uid,$gid);
            echo '<div class="notice notice-success"><p>'.count($uids).' دانشجو به گروه اضافه شد.</p></div>';
        }
        $s=array('gender'=>sanitize_text_field($_GET['gender']??''),'province'=>sanitize_text_field($_GET['province']??''),'city'=>sanitize_text_field($_GET['city']??''),'status'=>sanitize_text_field($_GET['status']??''),'group_id'=>absint($_GET['group_id']??0));
        $meta=array(); foreach(array('gender','province','city','status')as$k)if($s[$k])$meta[]=array('key'=>'status'===$k?'academy_status':$k,'value'=>$s[$k]);
        $args=array('number'=>100,'meta_query'=>$meta); if($s['group_id'])$args['include']=self::group_user_ids($s['group_id']);
        $users=get_users($args);
        $provinces=array('آذربایجان شرقی','آذربایجان غربی','اردبیل','اصفهان','البرز','ایلام','بوشهر','تهران','چهارمحال و بختیاری','خراسان جنوبی','خراسان رضوی','خراسان شمالی','خوزستان','زنجان','سمنان','سیستان و بلوچستان','فارس','قزوین','قم','کردستان','کرمان','کرمانشاه','کهگیلویه و بویراحمد','گلستان','گیلان','لرستان','مازندران','مرکزی','هرمزگان','همدان','یزد');
        echo '<h2>دانشجویان</h2><form method="get"><input type="hidden" name="page" value="academy-site-crm"><input type="hidden" name="tab" value="students"><select name="gender"><option value="">همه جنسیت‌ها</option><option value="female" '.selected($s['gender'],'female',false).'>زن</option><option value="male" '.selected($s['gender'],'male',false).'>مرد</option></select> <select name="province"><option value="">همه استان‌ها</option>';
        foreach($provinces as$p)echo'<option '.selected($s['province'],$p,false).'>'.esc_html($p).'</option>';
        echo'</select> <input name="city" value="'.esc_attr($s['city']).'" placeholder="شهر"> <select name="status"><option value="">همه وضعیت‌ها</option><option value="active" '.selected($s['status'],'active',false).'>فعال</option><option value="inactive" '.selected($s['status'],'inactive',false).'>غیرفعال</option></select> <select name="group_id"><option value="">همه گروه‌ها</option>';
        foreach(self::groups()as$g)echo'<option value="'.$g->id.'" '.selected($s['group_id'],$g->id,false).'>'.esc_html($g->name).'</option>';
        echo'</select> <button class="button">فیلتر</button></form><p>تعداد نتیجه: <strong>'.count($users).'</strong></p>';
        echo'<form method="post">'.wp_nonce_field('academy_crm_assign_group','_wpnonce',true,false).'<p><select name="assign_group_id" required><option value="">انتخاب گروه برای تخصیص</option>';
        foreach(self::groups()as$g)echo'<option value="'.$g->id.'">'.esc_html($g->name).'</option>';
        echo'</select> <button class="button" name="assign_group" value="1">افزودن انتخاب‌شده‌ها به گروه</button></p><table class="widefat striped"><thead><tr><th>انتخاب</th><th>نام</th><th>موبایل</th><th>جنسیت</th><th>استان</th><th>شهر</th><th>تولد</th><th>وضعیت</th></tr></thead><tbody>';
        foreach($users as$u)echo'<tr><td><input type="checkbox" name="user_ids[]" value="'.$u->ID.'"></td><td>'.esc_html($u->display_name).'</td><td>'.esc_html(get_user_meta($u->ID,'academy_phone',true)).'</td><td>'.esc_html(get_user_meta($u->ID,'gender',true)).'</td><td>'.esc_html(get_user_meta($u->ID,'province',true)).'</td><td>'.esc_html(get_user_meta($u->ID,'city',true)).'</td><td>'.esc_html(get_user_meta($u->ID,'birth_date',true)).'</td><td>'.esc_html(get_user_meta($u->ID,'academy_status',true)?:'active').'</td></tr>';
        echo'</tbody></table></form>';
    }
    private static function campaigns_page(){
        if(isset($_POST['save_campaign'])){
            check_admin_referer('academy_crm_campaign');
            $segment=array(
                'group_id'=>absint($_POST['group_id']??0),'gender'=>array_values(array_filter(array_map('sanitize_text_field',(array)($_POST['gender']??array())))),
                'province'=>sanitize_text_field($_POST['province']??''),'city'=>sanitize_text_field($_POST['city']??''),'status'=>sanitize_text_field($_POST['status']??''),
                'age_min'=>absint($_POST['age_min']??0),'age_max'=>absint($_POST['age_max']??0),'has_course'=>absint($_POST['has_course']??0),'completed_course'=>absint($_POST['completed_course']??0),'event_id'=>absint($_POST['event_id']??0),
                'birthday_today'=>!empty($_POST['birthday_today'])?1:0,'registered_after'=>sanitize_text_field($_POST['registered_after']??''),'registered_before'=>sanitize_text_field($_POST['registered_before']??''),
            );
            $r=self::create(array('title'=>sanitize_text_field($_POST['title']??''),'status'=>sanitize_key($_POST['status_campaign']??'draft'),'segment'=>$segment,'template_key'=>sanitize_key($_POST['template_key']??'crm_campaign'),'template_id'=>preg_replace('/[^0-9]/','',(string)($_POST['template_id']??'')),'starts_at'=>sanitize_text_field($_POST['starts_at']??''),'ends_at'=>sanitize_text_field($_POST['ends_at']??''),'schedule_type'=>sanitize_key($_POST['schedule_type']??'manual')));
            echo is_wp_error($r)?'<div class="notice notice-error"><p>'.esc_html($r->get_error_message()).'</p></div>':'<div class="notice notice-success"><p>کمپین با موفقیت ذخیره شد.</p></div>';
        }
        if(isset($_GET['run_campaign'])){ $r=self::execute_campaign(absint($_GET['run_campaign'])); echo is_wp_error($r)?'<div class="notice notice-error"><p>'.esc_html($r->get_error_message()).'</p></div>':'<div class="notice notice-success"><p>اجرای کمپین انجام شد. تعداد اجرای ثبت‌شده: '.intval($r).'</p></div>'; }
        $groups=self::groups(); $courses=get_posts(array('post_type'=>'academy_course','numberposts'=>100,'post_status'=>'publish')); $events=get_posts(array('post_type'=>'academy_event','numberposts'=>100,'post_status'=>'publish'));
        echo'<h2>ایجاد کمپین پیامکی</h2><form method="post">'.wp_nonce_field('academy_crm_campaign','_wpnonce',true,false).'<table class="form-table">';
        echo'<tr><th>نام کمپین</th><td><input name="title" class="regular-text" required></td></tr><tr><th>قالب پیامک</th><td><select name="template_key">';foreach(Academy_Site_SMS::TEMPLATES as$k=>$v)echo'<option value="'.esc_attr($k).'">'.esc_html($v).'</option>';echo'</select></td></tr>';
        echo'<tr><th>Template ID این کمپین</th><td><input name="template_id" inputmode="numeric" class="regular-text" placeholder="اختیاری؛ در صورت خالی از تنظیمات SMS استفاده می‌شود"></td></tr><tr><th>گروه</th><td><select name="group_id"><option value="0">همه / بدون گروه</option>';foreach($groups as$g)echo'<option value="'.$g->id.'">'.esc_html($g->name).'</option>';echo'</select></td></tr>';
        echo'<tr><th>جنسیت</th><td><label><input type="checkbox" name="gender[]" value="female"> زن</label> <label><input type="checkbox" name="gender[]" value="male"> مرد</label></td></tr>';
        echo'<tr><th>استان / شهر</th><td><input name="province" placeholder="استان"> <input name="city" placeholder="شهر"></td></tr><tr><th>وضعیت دانشجو</th><td><select name="status"><option value="">همه</option><option value="active">فعال</option><option value="inactive">غیرفعال</option></select></td></tr>';
        echo'<tr><th>سن</th><td><input type="number" name="age_min" min="0" placeholder="حداقل"> تا <input type="number" name="age_max" min="0" placeholder="حداکثر"></td></tr>';
        echo'<tr><th>دوره</th><td><select name="has_course"><option value="0">بدون فیلتر</option>';foreach($courses as$c)echo'<option value="'.$c->ID.'">'.esc_html($c->post_title).'</option>';echo'</select> <small>دوره خریداری/دارای دسترسی</small></td></tr>';
        echo'<tr><th>تکمیل دوره</th><td><select name="completed_course"><option value="0">بدون فیلتر</option>';foreach($courses as$c)echo'<option value="'.$c->ID.'">'.esc_html($c->post_title).'</option>';echo'</select></td></tr>';
        echo'<tr><th>رویداد</th><td><select name="event_id"><option value="0">بدون فیلتر</option>';foreach($events as$e)echo'<option value="'.$e->ID.'">'.esc_html($e->post_title).'</option>';echo'</select></td></tr>';
        echo'<tr><th>فقط متولدین امروز</th><td><input type="checkbox" name="birthday_today" value="1"></td></tr><tr><th>بازه ثبت‌نام</th><td><input type="date" name="registered_after"> تا <input type="date" name="registered_before"></td></tr>';
        echo'<tr><th>زمان‌بندی</th><td><select name="status_campaign"><option value="draft">پیش‌نویس</option><option value="active">فعال</option></select> <select name="schedule_type"><option value="manual">دستی</option><option value="scheduled">زمان‌بندی‌شده</option></select> <input type="datetime-local" name="starts_at"> تا <input type="datetime-local" name="ends_at"></td></tr>';
        echo'</table><p><button class="button button-primary" name="save_campaign" value="1">ذخیره کمپین</button></p></form><hr><h2>کمپین‌های موجود</h2><table class="widefat striped"><thead><tr><th>نام</th><th>وضعیت</th><th>قالب</th><th>زمان شروع</th><th>عملیات</th></tr></thead><tbody>';
        global$wpdb;$rows=$wpdb->get_results('SELECT * FROM '.self::tables()['campaigns'].' ORDER BY id DESC LIMIT 100');foreach($rows as$r){echo'<tr><td>'.esc_html($r->title).'</td><td>'.esc_html($r->status).'</td><td>'.esc_html($r->template_key).'</td><td>'.esc_html($r->starts_at).'</td><td>'.('active'===$r->status?'<a class="button" href="'.esc_url(add_query_arg(array('page'=>'academy-site-crm','tab'=>'campaigns','run_campaign'=>$r->id),admin_url('admin.php'))).'">اجرای کمپین</a>':'—').'</td></tr>';}
        echo'</tbody></table>';
    }

}
Academy_Site_Campaigns::boot();
