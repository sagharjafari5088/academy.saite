<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Academy Site — Wallet Engine.
 *
 * Ledger-first wallet with row locking, idempotent references, allocation of
 * debits against credit entries, optional expiry, REST/Dynamic Data and a
 * minimal WordPress admin control surface. UI remains intentionally neutral.
 */
final class Academy_Site_Wallet {
    const ACCOUNT_TABLE     = 'academy_wallet_accounts';
    const TRANSACTION_TABLE = 'academy_wallet_transactions';
    const ALLOCATION_TABLE  = 'academy_wallet_allocations';
    const CRON_HOOK         = 'academy_site_wallet_expire';

    public static function boot() {
        add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );
        add_filter( 'academy_site_dynamic_data', array( __CLASS__, 'dynamic_data' ), 50, 2 );
        add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
        add_action( self::CRON_HOOK, array( __CLASS__, 'expire_credits' ) );

        if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', self::CRON_HOOK );
        }
    }

    public static function tables() {
        global $wpdb;
        return array(
            'accounts'     => $wpdb->prefix . self::ACCOUNT_TABLE,
            'transactions' => $wpdb->prefix . self::TRANSACTION_TABLE,
            'allocations' => $wpdb->prefix . self::ALLOCATION_TABLE,
        );
    }

    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $t = self::tables();
        $charset = $wpdb->get_charset_collate();

        dbDelta( "CREATE TABLE {$t['accounts']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            balance DECIMAL(20,2) NOT NULL DEFAULT 0.00,
            currency VARCHAR(10) NOT NULL DEFAULT 'USD',
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY user_id (user_id),
            KEY status (status)
        ) {$charset};" );

        dbDelta( "CREATE TABLE {$t['transactions']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            account_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            type VARCHAR(20) NOT NULL,
            amount DECIMAL(20,2) NOT NULL,
            balance_after DECIMAL(20,2) NOT NULL,
            currency VARCHAR(10) NOT NULL,
            reference VARCHAR(190) NULL,
            description TEXT NULL,
            expires_at DATETIME NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'posted',
            metadata LONGTEXT NULL,
            created_by BIGINT UNSIGNED NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY account_reference (account_id, reference),
            KEY user_created (user_id, created_at),
            KEY account_created (account_id, created_at),
            KEY type_status (type, status),
            KEY expires_status (expires_at, status)
        ) {$charset};" );

        dbDelta( "CREATE TABLE {$t['allocations']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            debit_transaction_id BIGINT UNSIGNED NOT NULL,
            credit_transaction_id BIGINT UNSIGNED NOT NULL,
            amount DECIMAL(20,2) NOT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY debit_credit (debit_transaction_id, credit_transaction_id),
            KEY credit_transaction (credit_transaction_id),
            KEY debit_transaction (debit_transaction_id)
        ) {$charset};" );
    }

    public static function currency() {
        $currency = apply_filters( 'academy_site_wallet_currency', '' );
        if ( ! $currency && function_exists( 'get_woocommerce_currency' ) ) {
            $currency = get_woocommerce_currency();
        }
        if ( ! $currency ) {
            $currency = get_option( 'academy_site_wallet_currency', 'IRT' );
        }
        return strtoupper( sanitize_text_field( $currency ) );
    }

    public static function ensure_account( $user_id ) {
        global $wpdb;
        $user_id = absint( $user_id );
        if ( ! $user_id || ! get_user_by( 'id', $user_id ) ) {
            return new WP_Error( 'invalid_user', 'کاربر معتبر نیست.' );
        }
        $t = self::tables();
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['accounts']} WHERE user_id = %d LIMIT 1", $user_id ) );
        if ( $row ) { return $row; }
        $now = current_time( 'mysql', true );
        $ok = $wpdb->insert( $t['accounts'], array(
            'user_id' => $user_id,
            'balance' => '0.00',
            'currency' => self::currency(),
            'status' => 'active',
            'created_at' => $now,
            'updated_at' => $now,
        ), array( '%d','%s','%s','%s','%s','%s' ) );
        if ( false === $ok ) {
            $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['accounts']} WHERE user_id = %d LIMIT 1", $user_id ) );
            return $row ?: new WP_Error( 'wallet_account_error', 'ایجاد حساب کیف پول ناموفق بود.' );
        }
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['accounts']} WHERE id = %d", $wpdb->insert_id ) );
    }

    public static function get_account( $user_id ) {
        return self::ensure_account( $user_id );
    }

    public static function get_balance( $user_id ) {
        $account = self::get_account( $user_id );
        if ( is_wp_error( $account ) ) { return $account; }
        return array( 'amount' => (float) $account->balance, 'currency' => $account->currency, 'status' => $account->status );
    }

    public static function credit( $user_id, $amount, $args = array() ) {
        $args = wp_parse_args( $args, array(
            'type' => 'credit', 'reference' => '', 'description' => '', 'expires_at' => null,
            'metadata' => array(), 'created_by' => get_current_user_id(),
        ) );
        return self::post( $user_id, $amount, $args );
    }

    public static function gift( $user_id, $amount, $args = array() ) {
        $args['type'] = 'gift';
        return self::credit( $user_id, $amount, $args );
    }

    public static function refund( $user_id, $amount, $args = array() ) {
        $args['type'] = 'refund';
        return self::credit( $user_id, $amount, $args );
    }

    public static function debit( $user_id, $amount, $args = array() ) {
        $args['type'] = 'debit';
        return self::post( $user_id, $amount, $args );
    }

    public static function adjust( $user_id, $amount, $args = array() ) {
        $args = wp_parse_args( $args, array( 'reference' => '', 'description' => '', 'metadata' => array(), 'created_by' => get_current_user_id() ) );
        return self::post( $user_id, $amount, array_merge( $args, array( 'type' => 'adjustment' ) ) );
    }

    public static function post( $user_id, $amount, $args = array() ) {
        global $wpdb;
        $amount = round( (float) $amount, 2 );
        if ( $amount <= 0 ) { return new WP_Error( 'invalid_amount', 'مبلغ باید بیشتر از صفر باشد.' ); }
        $user_id = absint( $user_id );
        $account = self::ensure_account( $user_id );
        if ( is_wp_error( $account ) ) { return $account; }
        $args = wp_parse_args( $args, array( 'type' => 'credit', 'reference' => '', 'description' => '', 'expires_at' => null, 'metadata' => array(), 'created_by' => get_current_user_id() ) );
        $allowed = array( 'credit', 'gift', 'refund', 'debit', 'adjustment', 'expiration' );
        $type = in_array( $args['type'], $allowed, true ) ? $args['type'] : 'credit';
        $reference = sanitize_text_field( $args['reference'] );
        $t = self::tables();
        $now = current_time( 'mysql', true );

        $wpdb->query( 'START TRANSACTION' );
        try {
            $locked = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['accounts']} WHERE id = %d FOR UPDATE", (int) $account->id ) );
            if ( ! $locked ) { throw new Exception( 'حساب کیف پول پیدا نشد.' ); }

            if ( $reference !== '' ) {
                $existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['transactions']} WHERE account_id = %d AND reference = %s LIMIT 1", (int) $locked->id, $reference ) );
                if ( $existing ) { $wpdb->query( 'COMMIT' ); return (int) $existing->id; }
            }

            $old_balance = (float) $locked->balance;
            $is_debit = in_array( $type, array( 'debit', 'expiration' ), true ) || ( 'adjustment' === $type && ! empty( $args['direction'] ) && 'debit' === $args['direction'] );
            $new_balance = $is_debit ? $old_balance - $amount : $old_balance + $amount;
            if ( $new_balance < 0 ) {
                $wpdb->query( 'ROLLBACK' );
                return new WP_Error( 'insufficient_funds', 'موجودی کیف پول کافی نیست.' );
            }

            $expires = self::normalize_datetime( $args['expires_at'] );
            $metadata = wp_json_encode( is_array( $args['metadata'] ) ? $args['metadata'] : array(), JSON_UNESCAPED_UNICODE );
            $ok = $wpdb->insert( $t['transactions'], array(
                'account_id' => (int) $locked->id,
                'user_id' => $user_id,
                'type' => $type,
                'amount' => number_format( $amount, 2, '.', '' ),
                'balance_after' => number_format( $new_balance, 2, '.', '' ),
                'currency' => $locked->currency,
                'reference' => $reference !== '' ? $reference : null,
                'description' => sanitize_textarea_field( $args['description'] ),
                'expires_at' => $expires,
                'status' => 'posted',
                'metadata' => $metadata,
                'created_by' => absint( $args['created_by'] ) ?: null,
                'created_at' => $now,
            ), array( '%d','%d','%s','%s','%s','%s','%s','%s','%s','%s','%s','%d','%s' ) );
            if ( false === $ok ) { throw new Exception( 'ثبت تراکنش ناموفق بود.' ); }
            $tx_id = (int) $wpdb->insert_id;

            if ( $is_debit ) {
                $allocated = self::allocate_debit_locked( $tx_id, $locked->id, $amount, $now );
                if ( is_wp_error( $allocated ) ) { throw new Exception( $allocated->get_error_message() ); }
            }

            $updated = $wpdb->update( $t['accounts'], array( 'balance' => number_format( $new_balance, 2, '.', '' ), 'updated_at' => $now ), array( 'id' => (int) $locked->id ), array( '%s','%s' ), array( '%d' ) );
            if ( false === $updated ) { throw new Exception( 'به‌روزرسانی موجودی ناموفق بود.' ); }

            $wpdb->query( 'COMMIT' );
            do_action( 'academy_site_wallet_transaction_posted', $tx_id, $user_id, $type, $amount, $new_balance );
            return $tx_id;
        } catch ( Exception $e ) {
            $wpdb->query( 'ROLLBACK' );
            return new WP_Error( 'wallet_transaction_error', $e->getMessage() );
        }
    }

    private static function allocate_debit_locked( $debit_id, $account_id, $amount, $now ) {
        global $wpdb;
        $t = self::tables();
        $remaining = $amount;
        $credits = $wpdb->get_results( $wpdb->prepare(
            "SELECT tx.id, tx.amount, tx.expires_at, COALESCE(SUM(a.amount),0) allocated
             FROM {$t['transactions']} tx
             LEFT JOIN {$t['allocations']} a ON a.credit_transaction_id = tx.id
             WHERE tx.account_id = %d
             AND tx.type IN ('credit','gift','refund','adjustment')
             AND tx.status = 'posted'
             AND (tx.expires_at IS NULL OR tx.expires_at > %s)
             GROUP BY tx.id
             HAVING (tx.amount - allocated) > 0
             ORDER BY (tx.expires_at IS NULL), tx.expires_at ASC, tx.id ASC
             FOR UPDATE",
            (int) $account_id, $now
        ) );
        foreach ( $credits as $credit ) {
            if ( $remaining <= 0 ) { break; }
            $available = max( 0, (float) $credit->amount - (float) $credit->allocated );
            $take = min( $remaining, $available );
            if ( $take <= 0 ) { continue; }
            $ok = $wpdb->insert( $t['allocations'], array(
                'debit_transaction_id' => $debit_id,
                'credit_transaction_id' => (int) $credit->id,
                'amount' => number_format( $take, 2, '.', '' ),
                'created_at' => $now,
            ), array( '%d','%d','%s','%s' ) );
            if ( false === $ok ) { return new WP_Error( 'allocation_error', 'تخصیص تراکنش کیف پول ناموفق بود.' ); }
            $remaining -= $take;
        }
        if ( $remaining > 0.0001 ) { return new WP_Error( 'allocation_error', 'موجودی قابل تخصیص کافی نیست.' ); }
        return true;
    }

    public static function get_transactions( $user_id, $args = array() ) {
        global $wpdb;
        $args = wp_parse_args( $args, array( 'limit' => 50, 'offset' => 0, 'type' => '' ) );
        $limit = min( 100, max( 1, absint( $args['limit'] ) ) );
        $offset = max( 0, absint( $args['offset'] ) );
        $t = self::tables();
        $params = array( absint( $user_id ) );
        $sql = "SELECT * FROM {$t['transactions']} WHERE user_id = %d";
        if ( $args['type'] !== '' ) { $sql .= ' AND type = %s'; $params[] = sanitize_key( $args['type'] ); }
        $sql .= ' ORDER BY id DESC LIMIT %d OFFSET %d'; $params[] = $limit; $params[] = $offset;
        return $wpdb->get_results( $wpdb->prepare( $sql, $params ) );
    }

    public static function expire_credits() {
        global $wpdb;
        $t = self::tables();
        $now = current_time( 'mysql', true );
        $credits = $wpdb->get_results( $wpdb->prepare(
            "SELECT tx.id, tx.user_id, tx.account_id, tx.amount,
                    COALESCE(SUM(a.amount),0) allocated
             FROM {$t['transactions']} tx
             LEFT JOIN {$t['allocations']} a ON a.credit_transaction_id = tx.id
             WHERE tx.type IN ('credit','gift','refund')
             AND tx.status = 'posted'
             AND tx.expires_at IS NOT NULL
             AND tx.expires_at <= %s
             GROUP BY tx.id
             HAVING (tx.amount - allocated) > 0
             ORDER BY tx.id ASC
             LIMIT 100",
            $now
        ) );
        foreach ( $credits as $credit ) {
            $remaining = round( (float) $credit->amount - (float) $credit->allocated, 2 );
            if ( $remaining <= 0 ) { continue; }
            self::debit( $credit->user_id, $remaining, array(
                'type' => 'expiration',
                'reference' => 'expiry:' . (int) $credit->id,
                'description' => 'انقضای اعتبار کیف پول',
                'metadata' => array( 'expired_transaction_id' => (int) $credit->id ),
                'created_by' => 0,
            ) );
        }
    }

    public static function register_rest_routes() {
        register_rest_route( 'academy-site/v1', '/me/wallet', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array( __CLASS__, 'rest_wallet' ),
            'permission_callback' => function() { return is_user_logged_in(); },
        ) );
        register_rest_route( 'academy-site/v1', '/me/wallet/transactions', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array( __CLASS__, 'rest_transactions' ),
            'permission_callback' => function() { return is_user_logged_in(); },
        ) );
    }

    public static function rest_wallet() {
        return rest_ensure_response( array(
            'balance' => self::get_balance( get_current_user_id() ),
        ) );
    }

    public static function rest_transactions( WP_REST_Request $request ) {
        return rest_ensure_response( array(
            'transactions' => self::get_transactions( get_current_user_id(), array(
                'limit' => absint( $request->get_param( 'limit' ) ) ?: 50,
                'offset' => absint( $request->get_param( 'offset' ) ),
                'type' => sanitize_key( $request->get_param( 'type' ) ?: '' ),
            ) ),
        ) );
    }

    public static function dynamic_data( $data, $context ) {
        if ( ! is_user_logged_in() ) { return $data; }
        $user_id = get_current_user_id();
        $data['wallet'] = array(
            'balance' => self::get_balance( $user_id ),
            'transactions' => self::get_transactions( $user_id, array( 'limit' => 20 ) ),
        );
        return $data;
    }

    public static function admin_menu() {
        add_menu_page( 'Academy Wallet', 'کیف پول آکادمی', 'manage_options', 'academy-wallet', array( __CLASS__, 'admin_page' ), 'dashicons-money-alt', 58 );
    }

    public static function admin_page() {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'دسترسی غیرمجاز.' ); }
        $message = '';
        if ( isset( $_POST['academy_wallet_action'] ) ) {
            check_admin_referer( 'academy_wallet_admin' );
            $user_id = absint( $_POST['user_id'] ?? 0 );
            $amount = (float) ( $_POST['amount'] ?? 0 );
            $action = sanitize_key( $_POST['academy_wallet_action'] );
            $description = sanitize_textarea_field( wp_unslash( $_POST['description'] ?? '' ) );
            $expires = sanitize_text_field( wp_unslash( $_POST['expires_at'] ?? '' ) );
            $args = array( 'description' => $description, 'expires_at' => $expires ?: null, 'created_by' => get_current_user_id(), 'reference' => 'admin:' . wp_generate_uuid4() );
            if ( 'credit' === $action ) { $result = self::credit( $user_id, $amount, $args ); }
            elseif ( 'gift' === $action ) { $result = self::gift( $user_id, $amount, $args ); }
            elseif ( 'refund' === $action ) { $result = self::refund( $user_id, $amount, $args ); }
            else { $result = self::debit( $user_id, $amount, $args ); }
            $message = is_wp_error( $result ) ? $result->get_error_message() : 'تراکنش با موفقیت ثبت شد.';
        }
        echo '<div class="wrap"><h1>کیف پول آکادمی</h1>';
        if ( $message ) { echo '<div class="notice notice-info"><p>' . esc_html( $message ) . '</p></div>'; }
        echo '<form method="post">'; wp_nonce_field( 'academy_wallet_admin' );
        echo '<table class="form-table">';
        echo '<tr><th>شناسه کاربر</th><td><input type="number" min="1" name="user_id" required></td></tr>';
        echo '<tr><th>مبلغ</th><td><input type="number" min="0.01" step="0.01" name="amount" required></td></tr>';
        echo '<tr><th>نوع عملیات</th><td><select name="academy_wallet_action"><option value="credit">Credit</option><option value="gift">Gift</option><option value="refund">Refund</option><option value="debit">Debit</option></select></td></tr>';
        echo '<tr><th>انقضا</th><td><input type="datetime-local" name="expires_at"></td></tr>';
        echo '<tr><th>دلیل</th><td><textarea class="large-text" name="description"></textarea></td></tr>';
        echo '</table>'; submit_button( 'ثبت تراکنش' ); echo '</form></div>';
    }

    private static function normalize_datetime( $value ) {
        if ( empty( $value ) ) { return null; }
        $timestamp = strtotime( (string) $value );
        return $timestamp ? gmdate( 'Y-m-d H:i:s', $timestamp ) : null;
    }
}

Academy_Site_Wallet::boot();
