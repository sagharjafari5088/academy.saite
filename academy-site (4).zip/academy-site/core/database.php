<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Shared migration helpers. Modules own their own tables and migrations. */
function academy_site_db_run_installers() {
    foreach ( academy_site_module_manifest() as $module ) {
        $file = academy_site_module_file( $module );
        if ( ! file_exists( $file ) ) continue;
        try {
            require_once $file;
            $classes = array(
                'Academy_Site_' . str_replace( ' ', '_', ucwords( str_replace( '-', ' ', $module ) ) ),
            );
            foreach ( $classes as $class ) {
                if ( class_exists( $class ) && method_exists( $class, 'install' ) ) {
                    call_user_func( array( $class, 'install' ) );
                }
            }
        } catch ( Throwable $e ) {
            error_log( '[Academy Site] Installer ' . $module . ' failed: ' . $e->getMessage() );
        }
    }
}
