<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Academy Site canonical HTML-widget variable contract.
 * These names are stable across modules and must never be renamed per screen.
 */
final class Academy_Site_Variables {
    const GLOBAL = array(
        'student-name',
    );
    const CERTIFICATE = array(
        'student-name', 'national-id', 'date', 'duration', 'template-title', 'custom-field', 'certificate-qr',
    );
    const INSTRUCTOR = array(
        'instructor-name', 'instructor-subtitle', 'instructor-description', 'instructor-image', 'instructor-qr',
    );
    public static function all(){ return array_values(array_unique(array_merge(self::GLOBAL,self::CERTIFICATE,self::INSTRUCTOR))); }
}
