<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Academy Site module loader.
 * Each module is isolated: a module failure is logged and skipped instead of
 * aborting the whole plugin/WordPress request.
 */
function academy_site_module_manifest() {
    return array(
        'admin-hub','articles','contact','courses','enrollment','events','faq','homepage','instructors',
        'notifications','seminars','testimonials','woocommerce','progress','lesson-access',
        'certificates','wallet','sms','campaigns','auth','students','support','student-card',
        'my-courses','consultations','dynamic','qr','commerce'
    );
}

function academy_site_module_file( $module ) {
    return ACADEMY_SITE_PATH . 'modules/' . sanitize_key( $module ) . '/' . sanitize_key( $module ) . '.php';
}

function academy_site_load_module( $module ) {
    static $runtime_loaded = array();

    $module = sanitize_key( $module );
    if ( ! $module ) return false;

    // "loaded" is request-local. Never use a persisted option as a reason
    // to skip requiring a module on a later WordPress request; CPTs, hooks,
    // REST routes and admin menus must be registered on every request.
    if ( isset( $runtime_loaded[ $module ] ) ) {
        return 'loaded' === $runtime_loaded[ $module ];
    }

    $file = academy_site_module_file( $module );
    if ( ! file_exists( $file ) ) {
        $runtime_loaded[ $module ] = 'missing';
        $states = get_option( 'academy_site_loaded_modules', array() );
        if ( ! is_array( $states ) ) $states = array();
        $states[ $module ] = 'missing';
        update_option( 'academy_site_loaded_modules', $states, false );
        return false;
    }

    try {
        require_once $file;
        $runtime_loaded[ $module ] = 'loaded';
        $states = get_option( 'academy_site_loaded_modules', array() );
        if ( ! is_array( $states ) ) $states = array();
        $states[ $module ] = 'loaded';
        update_option( 'academy_site_loaded_modules', $states, false );
        return true;
    } catch ( Throwable $e ) {
        $runtime_loaded[ $module ] = 'error';
        $states = get_option( 'academy_site_loaded_modules', array() );
        if ( ! is_array( $states ) ) $states = array();
        $states[ $module ] = 'error';
        update_option( 'academy_site_loaded_modules', $states, false );
        error_log( '[Academy Site] Module ' . $module . ' failed: ' . $e->getMessage() );
        return false;
    }
}

function academy_site_load_modules() {
    static $done = false;
    if ( $done ) return;
    $done = true;
    foreach ( academy_site_module_manifest() as $module ) {
        academy_site_load_module( $module );
    }
}

function academy_site_reset_module_status() {
    delete_option( 'academy_site_loaded_modules' );
}

add_action( 'admin_menu', function() {
    add_submenu_page(
        'options-general.php',
        'Academy Site — وضعیت ماژول‌ها',
        'Academy Site Modules',
        'manage_options',
        'academy-site-modules',
        function() {
            if ( ! current_user_can( 'manage_options' ) ) return;
            $states = get_option( 'academy_site_loaded_modules', array() );
            if ( ! is_array( $states ) ) $states = array();
            echo '<div class="wrap"><h1>وضعیت ماژول‌های Academy Site</h1><p>خطای یک ماژول نباید باعث Fatal Error کل افزونه شود.</p><table class="widefat striped"><thead><tr><th>Module</th><th>Status</th></tr></thead><tbody>';
            foreach ( academy_site_module_manifest() as $m ) {
                $state = $states[ $m ] ?? 'not-loaded';
                $label = 'loaded' === $state ? 'فعال' : ( 'error' === $state ? 'خطا' : ( 'missing' === $state ? 'فایل موجود نیست' : 'بارگذاری نشده' ) );
                echo '<tr><td><code>' . esc_html( $m ) . '</code></td><td>' . esc_html( $label ) . '</td></tr>';
            }
            echo '</tbody></table></div>';
        }
    );
}, 99 );
