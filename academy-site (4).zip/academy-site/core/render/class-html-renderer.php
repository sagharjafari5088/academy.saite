<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Academy Site — Elementor HTML Widget Dynamic Renderer.
 *
 * Contract:
 * - Elementor owns layout/design/CSS.
 * - Academy Site owns data/business logic.
 * - HTML Widget templates use {{markers}} and {{#collections}}...{{/collections}}.
 * - No Template ID, CSS, or visual layout is hard-coded here.
 */
final class Academy_Site_HTML_Renderer {

    public static function boot() {
        add_filter( 'elementor/widget/render_content', array( __CLASS__, 'render' ), 20, 2 );
    }

    public static function render( $content, $widget ) {
        if ( ! is_object( $widget ) || strpos( $content, '{{' ) === false ) {
            return $content;
        }

        
        $class = get_class( $widget );
        $widget_name = method_exists( $widget, 'get_name' ) ? (string) $widget->get_name() : '';
        $is_html = ( 'html' === strtolower( $widget_name ) )
            || stripos( $class, 'Widget_HTML' ) !== false
            || stripos( $class, '\\Html\\' ) !== false
            || stripos( $class, '\\HTML\\' ) !== false;

        if ( ! $is_html ) {
            return $content;
        }

        return self::replace( $content );
    }

    public static function replace( $html ) {
        /*
         * Academy Site HTML Widget loops.
         *
         * The HTML Widget contains ONE designed card. Academy Site repeats
         * that card using live data. Elementor Loop Grid is intentionally not
         * required for Academy collections.
         *
         * Example:
         * <div data-academy-loop="certificates">
         *   <article data-academy-loop-item> ... {{student-name}} ... </article>
         * </div>
         */
        $html = self::render_widget_loops( $html );

        /*
         * Public collection aliases:
         * courses, instructors, events/seminars, articles, testimonials, faq/faqs.
         */
        $collections = array(
            array( 'courses', 'course' ),
            array( 'course', 'course' ),
            array( 'instructors', 'instructor' ),
            array( 'instructor', 'instructor' ),
            array( 'events', 'seminar' ),
            array( 'event', 'seminar' ),
            array( 'seminars', 'seminar' ),
            array( 'seminar', 'seminar' ),
            array( 'articles', 'article' ),
            array( 'article', 'article' ),
            array( 'testimonials', 'testimonial' ),
            array( 'testimonial', 'testimonial' ),
            array( 'faq', 'faq' ),
            array( 'faqs', 'faq' ),
            array( 'certificates', 'certificate' ),
            array( 'certificate', 'certificate' ),
        );

        foreach ( $collections as $collection ) {
            $html = self::collection( $html, $collection[0], $collection[1] );
        }

        $ctx = self::context();
        $map = self::global_map();
        if ( $ctx ) {
            $map = array_merge( $map, self::map( $ctx['type'], $ctx['data'] ) );
        }

        if ( $ctx ) {
            $map['academy.current_type'] = $ctx['type'];
            $map['academy.current_id']   = (string) $ctx['id'];
            $map['academy.current_url']  = esc_url( get_permalink( $ctx['id'] ) );

            if ( 'course' === $ctx['type'] ) {
                $lessons = self::lessons( $ctx['id'] );
                $html = self::nested( $html, 'course_lessons', $lessons, 'lesson' );
                $map['course_lessons'] = self::lessons_html( $lessons );
            }

            if ( 'seminar' === $ctx['type'] ) {
                $tickets = self::tickets( $ctx['id'] );
                $html = self::nested( $html, 'seminar_tickets', $tickets, 'ticket' );
                $html = self::nested( $html, 'event_tickets', $tickets, 'ticket' );
                $map['seminar_tickets'] = self::ticket_html( $tickets );
                $map['event_tickets']   = self::ticket_html( $tickets );
            }
        }

        /*
         * Dashboard/member data is available independently of a single
         * post context. Empty collections become empty strings.
         */
        $html = self::replace_map( $html, self::member_map() );

        return self::replace_map( $html, $map );
    }


    private static function render_widget_loops( $html ) {
        $re = '/<(?P<tag>[a-zA-Z][a-zA-Z0-9]*)\b(?P<attrs>[^>]*\bdata-academy-loop\s*=\s*["\'](?P<name>[^"\']+)["\'][^>]*)>(?P<body>.*?)<\/(?P=tag)>/is';

        return preg_replace_callback(
            $re,
            function( $m ) {
                $name = sanitize_key( $m['name'] );
                $body = $m['body'];

                $types = array(
                    'instructors' => 'instructor', 'instructor' => 'instructor',
                    'certificates' => 'certificate', 'certificate' => 'certificate',
                    'courses' => 'course', 'course' => 'course',
                    'events' => 'seminar', 'event' => 'seminar',
                    'seminars' => 'seminar', 'seminar' => 'seminar',
                    'articles' => 'article', 'article' => 'article',
                    'testimonials' => 'testimonial', 'testimonial' => 'testimonial',
                    'faq' => 'faq', 'faqs' => 'faq',
                );

                if ( ! isset( $types[ $name ] ) ) {
                    return $m[0];
                }

                $type = $types[ $name ];

                /*
                 * The card is explicitly marked as the repeatable template.
                 * This prevents accidental duplication of wrappers/controls.
                 */
                $item_re = '/<(?P<tag>[a-zA-Z][a-zA-Z0-9]*)\b(?P<attrs>[^>]*\bdata-academy-loop-item(?:\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]+))?[^>]*)>(?P<body>.*?)<\/(?P=tag)>/is';

                if ( ! preg_match( $item_re, $body, $item ) ) {
                    /*
                     * Backward compatible fallback: the entire inner HTML is
                     * treated as the card template.
                     */
                    $template = $body;
                    $before = '';
                    $after = '';
                } else {
                    $template = $item[0];
                    $before = substr( $body, 0, strpos( $body, $item[0] ) );
                    $after = substr( $body, strpos( $body, $item[0] ) + strlen( $item[0] ) );
                }

                $items = self::widget_loop_items( $type );

                $out = '';
                foreach ( $items as $data ) {
                    $out .= self::replace_map( $template, self::widget_loop_map( $type, $data ) );
                }

                /*
                 * Keep the original loop wrapper. This is important for the
                 * user's CSS/JS (grid, flex, carousel, etc.).
                 */
                return '<' . $m['tag'] . $m['attrs'] . '>' . $before . $out . $after . '</' . $m['tag'] . '>';
            },
            $html
        );
    }

    private static function widget_loop_items( $type ) {
        // Ensure the domain module is loaded before reading its data.
        $modules = array(
            'course' => 'courses',
            'instructor' => 'instructors',
            'seminar' => 'events',
            'article' => 'articles',
            'testimonial' => 'testimonials',
            'faq' => 'faq',
            'certificate' => 'certificates',
        );
        if ( isset( $modules[ $type ] ) && function_exists( 'academy_site_load_module' ) ) {
            academy_site_load_module( $modules[ $type ] );
        }

        if ( 'certificate' === $type ) {
            if ( ! class_exists( 'Academy_Site_Certificates' ) ) {
                return array();
            }

            $national_id = '';
            $verification_mode = false;

            foreach ( array( 'academy_national_id', 'national_id' ) as $param ) {
                if ( isset( $_GET[ $param ] ) ) {
                    $verification_mode = true;
                    $national_id = Academy_Site_Certificates::normalize_national_id( wp_unslash( $_GET[ $param ] ) );
                    break;
                }
            }

            // Also accept a normal GET/POST form submission. A normal GET form
            // is recommended for Elementor because the server-rendered loop can
            // then be filtered before the HTML Widget is rendered.
            if ( ! $verification_mode && isset( $_POST['academy_national_id'] ) ) {
                $verification_mode = true;
                $national_id = Academy_Site_Certificates::normalize_national_id( wp_unslash( $_POST['academy_national_id'] ) );
            } elseif ( ! $verification_mode && isset( $_POST['national_id'] ) ) {
                $verification_mode = true;
                $national_id = Academy_Site_Certificates::normalize_national_id( wp_unslash( $_POST['national_id'] ) );
            }

            if ( $verification_mode && ! $national_id ) {
                return array();
            }

            if ( $national_id ) {
                return Academy_Site_Certificates::verify_by_national_id( $national_id );
            }

            // On normal certificate archive pages, return all issued records.
            if ( method_exists( 'Academy_Site_Certificates', 'get_all' ) ) {
                return (array) Academy_Site_Certificates::get_all();
            }
            return array();
        }

        return self::list( $type );
    }

    private static function widget_loop_map( $type, $data ) {
        return self::map( $type, $data );
    }

    

    private static function collection( $html, $name, $type ) {
        $re = '/\{\{\#\s*' . preg_quote( $name, '/' ) . '\s*\}\}(.*?)\{\{\/\s*' . preg_quote( $name, '/' ) . '\s*\}\}/is';

        if ( ! preg_match( $re, $html ) ) {
            return $html;
        }

        if ( 'certificate' === $type ) {
            $items = self::widget_loop_items( 'certificate' );
        } else {
            $items = self::list( $type );
        }

        if ( ! $items && self::editor_preview() ) {
            $items = self::preview( $type );
        }

        return preg_replace_callback(
            $re,
            function ( $m ) use ( $items, $type ) {
                $out = '';
                foreach ( $items as $data ) {
                    $out .= self::replace_map( $m[1], self::widget_loop_map( $type, $data ) );
                }
                return $out;
            },
            $html
        );
    }

    private static function nested( $html, $name, $items, $type ) {
        $re = '/\{\{\#\s*' . preg_quote( $name, '/' ) . '\s*\}\}(.*?)\{\{\/\s*' . preg_quote( $name, '/' ) . '\s*\}\}/is';

        if ( ! preg_match( $re, $html ) ) {
            return $html;
        }

        return preg_replace_callback(
            $re,
            function ( $m ) use ( $items, $type ) {
                $out = '';
                foreach ( (array) $items as $data ) {
                    $out .= self::replace_map( $m[1], self::widget_loop_map( $type, $data ) );
                }
                return $out;
            },
            $html
        );
    }

    private static function replace_map( $html, $map ) {
        if ( ! is_array( $map ) ) {
            return $html;
        }

        return preg_replace_callback(
            '/\{\{\s*([a-zA-Z0-9_.:-]+)\s*\}\}/',
            function ( $m ) use ( $map ) {
                $requested = strtolower( trim( $m[1] ) );
                $candidates = array_unique( array(
                    $requested,
                    str_replace( '-', '_', $requested ),
                    str_replace( '_', '-', $requested ),
                ) );

                foreach ( $candidates as $key ) {
                    if ( array_key_exists( $key, $map ) ) {
                        return (string) $map[ $key ];
                    }
                }

                return $m[0];
            },
            $html
        );
    }

    private static function editor_preview() {
        return class_exists( 'Elementor\\Plugin' )
            && isset( \Elementor\Plugin::$instance->editor )
            && \Elementor\Plugin::$instance->editor->is_edit_mode();
    }

    private static function context() {

        /*
         * A certificate detail page is a normal WordPress/Elementor page.
         * It is selected by ?certificate=VERIFICATION-CODE and therefore does
         * not need a fake WordPress post type. This also makes
         * {{template-title}}, {{date}}, etc. available inside ordinary
         * Elementor HTML Widgets on the verification page.
         */
        if ( isset( $_GET['certificate'] ) && class_exists( 'Academy_Site_Certificates' ) ) {

            $code = sanitize_text_field(
                wp_unslash( $_GET['certificate'] )
            );

            if ( $code ) {

                $certificate = Academy_Site_Certificates::get_by_code( $code );

                if ( $certificate && 'issued' === $certificate->status ) {

                    return array(
                        'type' => 'certificate',
                        'id'   => absint( $certificate->id ),
                        'data' => $certificate,
                    );
                }
            }
        }

        $id = absint( get_queried_object_id() );
        $post = $id ? get_post( $id ) : null;

        if ( ! $post ) {
            return null;
        }

        $types = array(
            'academy_course'       => 'course',
            'academy_instructor'   => 'instructor',
            'academy_event'        => 'seminar',
            'academy_article'      => 'article',
            'academy_testimonial'  => 'testimonial',
            'academy_faq'          => 'faq',
        );

        if ( ! isset( $types[ $post->post_type ] ) ) {
            return null;
        }

        $type = $types[ $post->post_type ];
        $data = self::fetch( $type, $id );

        return $data ? array( 'id' => $id, 'type' => $type, 'data' => $data ) : null;
    }

    private static function fetch( $type, $id ) {
        $id = absint( $id );

        if ( 'course' === $type && class_exists( 'Academy_Site_Courses' ) ) {
            return Academy_Site_Courses::get_course( $id );
        }
        if ( 'instructor' === $type && class_exists( 'Academy_Site_Instructors' ) ) {
            return Academy_Site_Instructors::get_instructor( $id );
        }
        if ( 'seminar' === $type && class_exists( 'Academy_Site_Events' ) ) {
            return Academy_Site_Events::get_event( $id );
        }
        if ( 'article' === $type && class_exists( 'Academy_Site_Articles' ) ) {
            return Academy_Site_Articles::get( $id );
        }
        if ( 'testimonial' === $type && class_exists( 'Academy_Site_Testimonials' ) ) {
            return Academy_Site_Testimonials::get( $id );
        }
        if ( 'faq' === $type && class_exists( 'Academy_Site_Faq' ) ) {
            return Academy_Site_Faq::get( $id );
        }

        return null;
    }

    private static function list( $type ) {
        $module_by_type = array(
            'course' => 'courses',
            'instructor' => 'instructors',
            'seminar' => 'events',
            'article' => 'articles',
            'testimonial' => 'testimonials',
            'faq' => 'faq',
        );
        if ( isset( $module_by_type[ $type ] ) && function_exists( 'academy_site_load_module' ) ) {
            academy_site_load_module( $module_by_type[ $type ] );
        }

        $post_types = array(
            'course'      => 'academy_course',
            'instructor'  => 'academy_instructor',
            'seminar'     => 'academy_event',
            'article'     => 'academy_article',
            'testimonial' => 'academy_testimonial',
            'faq'         => 'academy_faq',
        );

        if ( ! isset( $post_types[ $type ] ) ) {
            return array();
        }

        $posts = get_posts( array(
            'post_type'      => $post_types[ $type ],
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'no_found_rows'  => true,
        ) );

        $out = array();

        foreach ( $posts as $post ) {
            $data = self::fetch( $type, $post->ID );
            if ( $data ) {
                $out[] = $data;
            }
        }

        return $out;
    }

        private static function map( $type, $d ) {
        $map = apply_filters( 'academy_site_render_map', array(), $type, $d );
        return is_array( $map ) ? $map : array();
    }

    private static function global_map() {
        $defaults = array(
            'login_url' => home_url('/login/'),
            'register_url' => home_url('/register/'),
            'otp_url' => home_url('/otp/'),
            'complete_registration_url' => home_url('/complete-registration/'),
            'welcome_url' => home_url('/'),
            'consultation_url' => home_url('/consultation/'),
            'certificate_verify_url' => home_url('/certificate-verification/'),
            'student_dashboard_url' => home_url('/student/'),
            'payment_status' => '',
            'payment_message' => '',
        );
        $map=array();
        foreach($defaults as $key=>$fallback){ $map[$key]=esc_url(get_option('academy_site_'.$key,$fallback)); }
        $payment = sanitize_key( $_GET['academy_payment'] ?? '' );
        if ( 'success' === $payment ) { $map['payment_status']='success'; $map['payment_message']='پرداخت با موفقیت تأیید شد.'; }
        elseif ( 'failed' === $payment ) { $map['payment_status']='failed'; $map['payment_message']='پرداخت انجام نشد یا توسط درگاه تأیید نشد.'; }
        return $map;
    }

    private static function member_map() {
        $empty = array(
            'student_name'            => '',
            'student_phone'           => '',
            'student_first_name'      => '',
            'student_last_name'       => '',
            'student_birth_date'      => '',
            'student_gender'          => '',
            'student_city'            => '',
            'student_province'        => '',
            'student_status'          => '',
            'wallet_balance'          => '',
            'my_courses'              => '',
            'my_courses_count'        => '0',
            'my_events'               => '',
            'my_certificates'         => '',
            'wallet_transactions'     => '',
            'student_orders'          => '',
            'course_recommendations'  => '',
            'my_courses_url'          => '',
            'my_events_url'           => '',
            'wallet_url'              => '',
            'profile_url'             => '',
            'dashboard_url'           => '',
            'logout_url'              => '',
            'certificate_verify_endpoint' => esc_url( rest_url( 'academy-site/v1/certificates/by-national-id/' ) ),
        );

        if ( ! is_user_logged_in() ) {
            return $empty;
        }

        $uid = get_current_user_id();
        $user = get_userdata( $uid );

        if ( ! $user ) {
            return $empty;
        }

        $courses = class_exists( 'Academy_Site_My_Courses' )
            ? Academy_Site_My_Courses::get_my_courses( $uid )
            : array();

        $events = class_exists( 'Academy_Site_Events' )
            ? Academy_Site_Events::get_user_registrations( $uid )
            : array();

        $certificates = class_exists( 'Academy_Site_Certificates' )
            ? Academy_Site_Certificates::user_certificates( $uid )
            : array();

        $phone = get_user_meta( $uid, 'academy_phone', true );
        $wallet = class_exists( 'Academy_Site_Wallet' )
            ? Academy_Site_Wallet::get_balance( $uid )
            : 0;

        $map = $empty;
        $map['student_name']       = esc_html( $user->display_name );
        $map['student_first_name'] = esc_html( $user->first_name );
        $map['student_last_name']  = esc_html( $user->last_name );
        $map['student_phone']      = esc_html( $phone );
        $map['student_birth_date'] = esc_html( get_user_meta( $uid, 'birth_date', true ) );
        $map['student_gender']     = esc_html( get_user_meta( $uid, 'gender', true ) );
        $map['student_city']       = esc_html( get_user_meta( $uid, 'city', true ) );
        $map['student_province']   = esc_html( get_user_meta( $uid, 'province', true ) );
        $map['student_status']     = esc_html( get_user_meta( $uid, 'academy_status', true ) ?: 'active' );

        // Student card + QR (no avatar).
        $card = class_exists( 'Academy_Site_Student_Card' ) ? Academy_Site_Student_Card::get( $uid ) : null;
        $card_token = $card ? (string) ( $card->public_token ?? '' ) : '';
        $card_url = ( $card_token && class_exists( 'Academy_Site_QR' ) )
            ? Academy_Site_QR::student_card_url( $card_token )
            : '';
        $map['student_card_number'] = $card ? esc_html( $card->card_number ?? '' ) : '';
        $map['student_card_url'] = esc_url( $card_url );
        $map['student_card_qr_url'] = $card_url && class_exists( 'Academy_Site_QR' )
            ? esc_url( Academy_Site_QR::image_url( $card_url, 240 ) )
            : '';
        $map['student_card_qr'] = $card_url && class_exists( 'Academy_Site_QR' )
            ? Academy_Site_QR::image_html( $card_url, 'academy-student-card-qr', 'QR کارت دانشجویی', 240 )
            : '';

        $wallet_amount = is_array( $wallet ) ? (float) ( $wallet['amount'] ?? 0 ) : (float) $wallet;
        $map['wallet_balance']     = esc_html( self::money( $wallet_amount ) );
        $map['my_courses']         = self::my_courses_html( $courses );
        $map['my_courses_count']   = (string) count( $courses );
        $map['my_events']          = self::my_events_html( $events );
        $map['my_certificates']    = self::my_certificates_html( $certificates );
        $transactions = class_exists('Academy_Site_Wallet') ? Academy_Site_Wallet::get_transactions($uid, array('limit'=>100)) : array();
        $map['wallet_transactions'] = self::wallet_transactions_html($transactions);
        $orders = class_exists('Academy_Site_Commerce') ? Academy_Site_Commerce::user_orders($uid) : array();
        $map['student_orders'] = self::orders_html($orders);
        $map['course_recommendations'] = self::recommendations_html($courses);

        $map['dashboard_url'] = esc_url( apply_filters( 'academy_site_dashboard_url', home_url( '/dashboard/' ) ) );
        $map['profile_url']   = esc_url( apply_filters( 'academy_site_profile_url', home_url( '/profile/' ) ) );
        $map['my_courses_url']= esc_url( apply_filters( 'academy_site_my_courses_url', home_url( '/my-courses/' ) ) );
        $map['my_events_url'] = esc_url( apply_filters( 'academy_site_my_events_url', home_url( '/my-events/' ) ) );
        $map['wallet_url']    = esc_url( apply_filters( 'academy_site_wallet_url', home_url( '/wallet/' ) ) );
        $map['logout_url']    = esc_url( wp_logout_url( home_url( '/' ) ) );

        return $map;
    }

    private static function my_courses_html( $courses ) {
        $out = '';
        foreach ( (array) $courses as $course ) {
            $c = is_object( $course ) ? (array) $course : (array) $course;
            $url = esc_url( $c['url'] ?? '#' );
            $out .= '<article class="academy-my-course-card">';
            $out .= '<div class="academy-my-course-image">' . ( ! empty( $c['thumbnail'] ) ? '<img src="' . esc_url( $c['thumbnail'] ) . '" alt="' . esc_attr( $c['title'] ?? '' ) . '">' : '' ) . '</div>';
            $out .= '<div class="academy-my-course-content">';
            $out .= '<h3>' . esc_html( $c['title'] ?? '' ) . '</h3>';
            $out .= '<div class="academy-my-course-progress">' . esc_html( (int) ( $c['progress'] ?? 0 ) ) . '%</div>';
            $out .= '<a class="academy-my-course-action" href="' . $url . '">مشاهده دوره</a>';
            $out .= '</div></article>';
        }
        return $out;
    }

    private static function my_events_html( $events ) {
        $out = '';
        foreach ( (array) $events as $event ) {
            $e = is_object( $event ) ? (array) $event : (array) $event;
            $event_id = absint( $e['event_id'] ?? $e['id'] ?? 0 );
            $url = $event_id ? get_permalink( $event_id ) : '#';
            $title = $e['event_title'] ?? ( $event_id ? get_the_title( $event_id ) : '' );
            $out .= '<article class="academy-my-event-card">';
            $out .= '<h3>' . esc_html( $title ) . '</h3>';
            if ( ! empty( $e['registered_at'] ) ) {
                $out .= '<div class="academy-my-event-date">' . esc_html( $e['registered_at'] ) . '</div>';
            }
            $out .= '<a class="academy-my-event-action" href="' . esc_url( $url ) . '">مشاهده همایش</a>';
            $out .= '</article>';
        }
        return $out;
    }

    private static function wallet_transactions_html( $transactions ) {
        $out=''; foreach((array)$transactions as $tx){$a=(float)($tx->amount??0);$type=sanitize_key($tx->type??'');$sign=in_array($type,array('debit','expiration'),true)?'-':'+';$out.='<article class="academy-wallet-transaction"><span>'.esc_html($tx->description??$type).'</span><strong>'.$sign.esc_html(number_format_i18n($a)).'</strong><time>'.esc_html($tx->created_at??'').'</time></article>';} return $out;
    }
    private static function orders_html( $orders ) {
        $out=''; foreach((array)$orders as $o){$title='سفارش #'.absint($o->id);if('course'===$o->item_type)$title=get_the_title($o->item_id);if('event_ticket'===$o->item_type&&class_exists('Academy_Site_Events')){$t=Academy_Site_Events::get_ticket($o->item_id);$title=$t?get_the_title($t->event_id):$title;}$out.='<article class="academy-order"><strong>'.esc_html($title).'</strong><span>'.esc_html(number_format_i18n((float)$o->amount)).' تومان</span><span>'.esc_html($o->status).'</span><time>'.esc_html($o->created_at).'</time></article>';} return $out;
    }
    private static function recommendations_html( $courses ) {
        $owned=array(); foreach((array)$courses as $c)$owned[]=absint(is_object($c)?($c->id??0):($c['id']??0));
        $posts=get_posts(array('post_type'=>'academy_course','post_status'=>'publish','posts_per_page'=>4,'post__not_in'=>$owned,'orderby'=>'date','order'=>'DESC','no_found_rows'=>true));$out='';foreach($posts as $p)$out.='<a class="academy-course-recommendation" href="'.esc_url(get_permalink($p->ID)).'">'.esc_html($p->post_title).'</a>';return $out;
    }

    private static function my_certificates_html( $certificates ) {
        $out = '';
        foreach ( (array) $certificates as $certificate ) {
            $c = is_object( $certificate ) ? (array) $certificate : (array) $certificate;
            $course_id = absint( $c['course_id'] ?? 0 );
            $out .= '<article class="academy-certificate-card">';
            $out .= '<h3>' . esc_html( $course_id ? get_the_title( $course_id ) : 'گواهینامه' ) . '</h3>';
            $out .= '<div class="academy-certificate-number">' . esc_html( $c['verification_code'] ?? $c['code'] ?? '' ) . '</div>';
            $out .= '<div class="academy-certificate-date">' . esc_html( $c['issued_at'] ?? '' ) . '</div>';
            if ( class_exists( 'Academy_Site_Certificates' ) ) { $rendered = Academy_Site_Certificates::render_certificate( $certificate ); if ( $rendered ) $out .= '<div class="academy-certificate-preview">' . $rendered . '</div>'; }
            if ( ! empty( $c['verification_code'] ) && class_exists( 'Academy_Site_QR' ) ) {
                $verify_url = Academy_Site_QR::certificate_url( $c['verification_code'] );
                $out .= '<div class="academy-certificate-qr">' . Academy_Site_QR::image_html( $verify_url, 'academy-certificate-qr', 'QR گواهینامه', 180 ) . '</div>';
            }
            $out .= '</article>';
        }
        return $out;
    }

    private static function lessons( $id ) {
        return class_exists( 'Academy_Site_Courses' )
            ? Academy_Site_Courses::get_lessons( $id, 'published' )
            : array();
    }

    private static function tickets( $id ) {
        return class_exists( 'Academy_Site_Events' )
            ? Academy_Site_Events::get_ticket_types( $id, true )
            : array();
    }

    private static function lessons_html( $lessons ) {
        $out = '';
        foreach ( (array) $lessons as $lesson ) {
            $m = self::map( 'lesson', $lesson );
            $out .= '<article class="academy-lesson">';
            $out .= '<div class="academy-lesson-number">' . esc_html( $m['lesson_order'] ) . '</div>';
            $out .= '<div class="academy-lesson-content"><h3>' . esc_html( $m['lesson_title'] ) . '</h3><div>' . esc_html( $m['lesson_duration'] ) . '</div></div>';
            $out .= $m['lesson_action'];
            $out .= '</article>';
        }
        return $out;
    }

    public static function instructor_courses( $id ) {
        $posts = get_posts( array(
            'post_type'      => 'academy_course',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'meta_key'       => '_academy_course_instructor_id',
            'meta_value'     => absint( $id ),
            'no_found_rows'  => true,
        ) );

        $out = '';
        foreach ( $posts as $post ) {
            $out .= '<a class="academy-instructor-course" href="' . esc_url( get_permalink( $post->ID ) ) . '">' . esc_html( get_the_title( $post ) ) . '</a>';
        }
        return $out;
    }

    public static function ticket_html( $tickets ) {
        $out = '';
        foreach ( (array) $tickets as $ticket ) {
            $m = self::map( 'ticket', $ticket );
            $out .= '<article class="academy-ticket-card">';
            $out .= '<div class="academy-ticket-header"><h3 class="academy-ticket-title">' . esc_html( $m['ticket_name'] ) . '</h3><div class="academy-ticket-type">' . esc_html( $m['ticket_type'] ) . '</div></div>';
            $out .= '<div class="academy-ticket-price">' . esc_html( $m['ticket_price'] ) . '</div>';
            $out .= '<div class="academy-ticket-capacity">' . esc_html( $m['ticket_capacity'] ) . '</div>';
            $out .= '<div class="academy-ticket-status">' . esc_html( $m['ticket_status'] ) . '</div>';
            $out .= '</article>';
        }
        return $out;
    }

    public static function event_price( $tickets ) {
        $prices = array();
        foreach ( (array) $tickets as $ticket ) {
            $price = (float) ( is_object( $ticket ) ? ( $ticket->price ?? 0 ) : ( $ticket['price'] ?? 0 ) );
            if ( $price > 0 ) {
                $prices[] = $price;
            }
        }
        return $prices ? min( $prices ) : 0;
    }

    public static function course_pricing( $course_id, $fallback ) {
        $fallback = max( 0, (float) $fallback );
        $current = $fallback;
        $regular = (float) get_post_meta( $course_id, '_academy_course_regular_price', true );
        $sale = (float) get_post_meta( $course_id, '_academy_course_sale_price', true );
        if ( $sale > 0 ) $current = $sale;
        elseif ( $current <= 0 ) $current = $fallback;
        if ( $regular <= 0 && $fallback > 0 ) $regular = $fallback;

        if ( class_exists( 'Academy_Site_WooCommerce' ) && function_exists( 'wc_get_product' ) ) {
            $best = null;
            foreach ( Academy_Site_WooCommerce::get_products_for_course( $course_id ) as $product_id ) {
                $product = wc_get_product( $product_id );
                if ( ! $product ) {
                    continue;
                }
                $product_current = (float) $product->get_price();
                if ( $product_current < 0 ) {
                    continue;
                }
                if ( null === $best || $product_current < $best['current'] ) {
                    $best = array(
                        'current' => $product_current,
                        'regular' => (float) $product->get_regular_price(),
                        'sale'    => (float) $product->get_sale_price(),
                    );
                }
            }
            if ( null !== $best ) {
                $current = $best['current'];
                $regular = $best['regular'];
                $sale = $best['sale'];
            }
        }

        $has_discount = $regular > 0 && $current > 0 && $current < $regular;
        $discount_percent = $has_discount ? (string) round( ( ( $regular - $current ) / $regular ) * 100 ) . '%' : '';

        return array(
            'current' => $current,
            'regular' => $regular,
            'sale' => $sale,
            'has_discount' => $has_discount,
            'discount_percent' => $discount_percent,
            'current_display' => self::money( $current ),
            'regular_display' => $has_discount ? self::money( $regular ) : '',
            'sale_display' => $has_discount ? self::money( $current ) : '',
            'html' => $has_discount
                ? '<span class="academy-course-price--sale"><del>' . esc_html( self::money( $regular ) ) . '</del><ins>' . esc_html( self::money( $current ) ) . '</ins></span>'
                : '<span class="academy-course-price--current">' . esc_html( self::money( $current ) ) . '</span>',
        );
    }

    public static function lines_html( $value ) {
        $lines=array_values(array_filter(array_map('trim',preg_split('/\r\n|\r|\n/',(string)$value)),'strlen')); if(!$lines)return ''; $out='<ul class="academy-lines-list">'; foreach($lines as $line)$out.='<li>'.esc_html($line).'</li>'; return $out.'</ul>';
    }

    public static function outcomes_html( $value ) {
        $lines = preg_split( '/\r\n|\r|\n/', (string) $value );
        $lines = array_values( array_filter( array_map( 'trim', $lines ), 'strlen' ) );
        if ( ! $lines ) {
            return '';
        }
        $out = '<ul class="academy-course-outcomes-list">';
        foreach ( $lines as $line ) {
            $out .= '<li>' . esc_html( $line ) . '</li>';
        }
        return $out . '</ul>';
    }

    public static function course_action( $id, $coming ) {
        if ( $coming || ! $id ) {
            return array( 'url' => '', 'html' => '' );
        }

        if ( is_user_logged_in()
            && class_exists( 'Academy_Site_Enrollment' )
            && Academy_Site_Enrollment::has_access( get_current_user_id(), $id ) ) {
            return array(
                'url'  => get_permalink( $id ),
                'html' => '<a class="academy-course-action academy-course-action--view" href="' . esc_url( get_permalink( $id ) ) . '">مشاهده دوره</a>',
            );
        }

        if ( class_exists( 'Academy_Site_Commerce' ) ) {
            $checkout = Academy_Site_Commerce::purchase_url( 'course', $id );
            return array(
                'url'  => $checkout,
                'html' => '<a class="academy-course-action academy-course-action--buy" href="' . esc_url( $checkout ) . '">خرید دوره</a>',
            );
        }

        if ( class_exists( 'Academy_Site_WooCommerce' ) && function_exists( 'wc_get_product' ) ) {
            foreach ( Academy_Site_WooCommerce::get_products_for_course( $id ) as $product_id ) {
                $product = wc_get_product( $product_id );
                if ( $product && $product->is_purchasable() && $product->is_visible() ) {
                    return array( 'url' => get_permalink( $product_id ), 'html' => '<a class="academy-course-action academy-course-action--buy" href="' . esc_url( get_permalink( $product_id ) ) . '">خرید دوره</a>' );
                }
            }
        }

        return array( 'url' => '', 'html' => '' );
    }

    public static function money( $value ) {
        $value = (float) $value;
        return $value > 0 ? number_format_i18n( $value ) . ' تومان' : 'رایگان';
    }

    public static function duration( $seconds ) {
        $seconds = absint( $seconds );
        $hours = floor( $seconds / 3600 );
        $minutes = floor( ( $seconds % 3600 ) / 60 );
        $secs = $seconds % 60;
        return $hours ? sprintf( '%d:%02d:%02d', $hours, $minutes, $secs ) : sprintf( '%02d:%02d', $minutes, $secs );
    }

    private static function preview( $type ) {
        $image = '<div class="academy-preview-image">تصویر نمونه</div>';

        if ( 'course' === $type ) {
            return array( array(
                'id'=>0,'title'=>'عنوان دوره نمونه','description'=>'توضیحات دوره نمونه','excerpt'=>'خلاصه دوره',
                'image_id'=>0,'image_url'=>'','image_html'=>$image,'price'=>15000000,'status'=>'active',
                'coming_soon'=>false,'instructor_id'=>0,'duration'=>'۲۳ ساعت','sessions'=>8,'outcomes'=>"مدیریت کاربردی هوش مصنوعی
بهینه‌سازی فرآیندهای کسب‌وکار
تولید محتوای هوشمند",'certificate_type'=>'گواهینامه رسمی آکادمی'
            ) );
        }

        if ( 'instructor' === $type ) {
            return array( array(
                'id'=>0,'name'=>'نام مدرس','title'=>'عنوان مدرس','bio'=>'توضیحات مدرس','excerpt'=>'',
                'specialties'=>'تخصص‌ها','image_html'=>$image,'image_url'=>''
            ) );
        }

        if ( 'seminar' === $type ) {
            return array( array(
                'id'=>0,'title'=>'عنوان همایش نمونه','description'=>'توضیحات همایش','excerpt'=>'خلاصه',
                'image_id'=>0,'date'=>'۱۴۰۵/۰۱/۱۵','time'=>'۱۸:۰۰','location'=>'تهران',
                'status'=>'open','available'=>true,'ticket_types'=>array()
            ) );
        }

        if ( 'article' === $type ) {
            return array( array(
                'id'=>0,'title'=>'عنوان مقاله نمونه','content'=>'متن مقاله نمونه','excerpt'=>'خلاصه مقاله',
                'image_html'=>$image,'image_url'=>''
            ) );
        }

        if ( 'testimonial' === $type ) {
            return array( array(
                'id'=>0,'title'=>'نام مشتری','name'=>'نام مشتری','role'=>'سمت','content'=>'متن نظر مشتری',
                'image_html'=>$image,'image_url'=>''
            ) );
        }

        if ( 'faq' === $type ) {
            return array( array( 'id'=>0,'title'=>'سؤال نمونه','answer'=>'پاسخ نمونه' ) );
        }

        return array();
    }
}
