ACADEMY SITE v1.28.0 — HTML WIDGET SYSTEM

هدف:
طراحی فرانت‌اند در Elementor HTML Widget و تزریق داده توسط Academy Site.

نحوه کار:
1) در Elementor یک HTML Widget بساز.
2) HTML/CSS طراحی خودت را داخل آن قرار بده.
3) Markerهای Academy را در محل داده قرار بده.
4) وقتی داده واقعی وارد شد، داده واقعی خودکار جایگزین Preview می‌شود.

COLLECTIONS

Courses:
{{#courses}} ... {{/courses}}

Instructors:
{{#instructors}} ... {{/instructors}}

Seminars:
{{#seminars}} ... {{/seminars}}

COURSE MARKERS
{{course_image}}
{{course_image_url}}
{{course_category}}
{{course_title}}
{{course_description}}
{{course_excerpt}}
{{course_instructor}}
{{course_instructor_url}}
{{course_price}}
{{course_status}}
{{coming_soon}}
{{course_action}}
{{course_action_url}}
{{course_id}}

INSTRUCTOR MARKERS
{{instructor_image}}
{{instructor_image_url}}
{{instructor_name}}
{{instructor_title}}
{{instructor_bio}}
{{instructor_action}}
{{instructor_action_url}}
{{instructor_id}}

SEMINAR MARKERS
{{seminar_image}}
{{seminar_image_url}}
{{seminar_title}}
{{seminar_description}}
{{seminar_excerpt}}
{{seminar_date}}
{{seminar_price}}
{{seminar_status}}
{{seminar_action}}
{{seminar_action_url}}
{{seminar_id}}

DESIGN PREVIEW
وقتی هنوز هیچ داده‌ای در سایت وجود ندارد، برای هر collection یک آیتم نمونه نمایش داده می‌شود تا بتوانی طراحی را کامل کنی. این داده نمونه فقط زمانی استفاده می‌شود که collection واقعی خالی باشد؛ با ورود اولین داده واقعی، Preview کنار می‌رود.

IMPORTANT
- ظاهر، CSS، layout و HTML کاملاً در Elementor/HTML Widget کنترل می‌شود.
- Academy Site فقط داده و خروجی‌های لازم را تزریق می‌کند.
- Shortcode Widget لازم نیست.
- برای صفحات واقعی و لیست‌ها از همین الگوی collection استفاده کن.


Course CTA rules v1.29.0:
- {{coming_soon}} suppresses purchase/access CTA.
- {{course_action}} is derived from the logged-in user's Academy enrollment.
- Active enrollment => مشاهده دوره.
- No active enrollment => خرید دوره, using the linked WooCommerce product.
- No linked purchasable product => no fabricated checkout link.
