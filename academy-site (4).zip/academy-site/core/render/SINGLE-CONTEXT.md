# Academy Site — Elementor HTML Widget Single Context

Use one Elementor Single Template per entity type. Do not hard-code an entity ID.

## Single Course

```html
<div class="academy-single-course">
  <img src="{{course_image_url}}" alt="{{course_title}}">
  <h1>{{course_title}}</h1>
  <div>{{course_category}}</div>
  <div>{{course_description}}</div>
  <div>{{course_instructor}}</div>
  <div>{{course_price}}</div>
  {{course_action}}
  {{coming_soon}}
</div>
```

## Single Instructor

```html
<div class="academy-single-instructor">
  <img src="{{instructor_image_url}}" alt="{{instructor_name}}">
  <h1>{{instructor_name}}</h1>
  <div>{{instructor_title}}</div>
  <div>{{instructor_bio}}</div>
</div>
```

## Single Event / Seminar

The current Events module uses `academy_event`. The HTML renderer exposes it through the `seminar_*` markers for consistency with existing seminar designs.

```html
<div class="academy-single-seminar">
  <img src="{{seminar_image_url}}" alt="{{seminar_title}}">
  <h1>{{seminar_title}}</h1>
  <div>{{seminar_description}}</div>
  <div>{{seminar_date}}</div>
  <div>{{seminar_time}}</div>
  <div>{{seminar_location}}</div>
  <div>{{seminar_price}}</div>
  <div>{{seminar_status}}</div>
</div>
```

The queried WordPress object determines the current entity automatically, so the same Elementor Single Template is reused for every entity of that type.
