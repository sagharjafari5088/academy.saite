<?php
if ( ! defined( 'ABSPATH' ) ) exit;
require_once __DIR__ . '/class-html-renderer.php';
$files=array('modules/certificates/certificate-renderer.php','modules/instructors/instructor-renderer.php','modules/courses/course-renderer.php','modules/courses/lesson-renderer.php','modules/events/event-renderer.php','modules/events/ticket-renderer.php','modules/articles/article-renderer.php','modules/testimonials/testimonial-renderer.php','modules/faq/faq-renderer.php');
foreach($files as $file){$path=dirname(__DIR__,2).'/'.$file;if(file_exists($path))require_once $path;}
add_action('plugins_loaded',array('Academy_Site_HTML_Renderer','boot'),30);
