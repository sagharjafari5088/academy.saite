﻿# Academy Site

Modular WordPress plugin for the Academy website.

## Architecture

Elementor:
- Page design
- Layout
- Responsive design
- Visual components

Academy Site:
- Data
- Database
- Business logic
- AJAX
- Admin
- Dynamic data
- Elementor integration

## Modules

- Homepage
- Instructors
- Courses
- Seminars
- Events
- Articles
- Testimonials
- FAQ
- Contact
- Notifications

Each module is isolated and developed independently.
