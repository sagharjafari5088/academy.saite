# Academy Site — Elementor HTML Contract v1.42

Put these templates in Elementor **HTML Widget**. Do not rename or remove the `{{markers}}` or collection wrappers. CSS is owned by Elementor; the plugin only supplies data/business logic.

- Courses: `{{#courses}}...{{/courses}}`
- Instructors: `{{#instructors}}...{{/instructors}}`
- Events/Seminars: `{{#events}}...{{/events}}` or `{{#seminars}}...{{/seminars}}`
- Articles: `{{#articles}}...{{/articles}}`
- FAQ: `{{#faq}}...{{/faq}}`
- Course lessons: `{{#course_lessons}}...{{/course_lessons}}`
- Event tickets: `{{#event_tickets}}...{{/event_tickets}}`

Backend changes must be additive: existing markers remain stable. New fields may be added without changing existing marker names.
