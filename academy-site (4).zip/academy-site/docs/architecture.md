# Academy Site — Project Architecture

Version: 1.0
Status: Active
Project: Academy Website

---

# 1. Project Purpose

Academy Site is the main modular WordPress plugin for the Academy website.

The plugin provides the backend logic, data management, administration,
AJAX functionality, security, dynamic data, and Elementor integration
for the public website.

The plugin does NOT replace Elementor as the page builder.

---

# 2. Core Development Principle

The project is modular.

Each major website section must be developed as an independent module.

Example:

modules/
├── instructors/
├── courses/
├── seminars/
├── events/
├── articles/
├── testimonials/
├── faq/
├── contact/
└── notifications/

A module must be as independent as possible from other modules.

---

# 3. Main Architecture

academy-site/
│
├── academy-site.php
│
├── core/
│   ├── loader.php
│   ├── database.php
│   ├── assets.php
│   ├── helpers.php
│   ├── permissions.php
│   └── elementor.php
│
├── modules/
│   ├── homepage/
│   ├── instructors/
│   ├── courses/
│   ├── seminars/
│   ├── events/
│   ├── articles/
│   ├── testimonials/
│   ├── faq/
│   ├── contact/
│   └── notifications/
│
└── docs/
    └── ARCHITECTURE.md

This structure must remain stable unless there is a clear architectural
reason to change it.

---

# 4. Elementor Rule

IMPORTANT:

All public page designs are created with Elementor.

The plugin must NOT be used to create the visual layout of normal
website pages.

Elementor is responsible for:

- Page layout
- Sections
- Containers
- Typography
- Colors
- Spacing
- Responsive design
- Images
- Buttons
- Visual presentation
- Page structure

The plugin is responsible for:

- Data
- Database
- Business logic
- Dynamic content
- AJAX
- Admin functionality
- Security
- Elementor data integration
- Dynamic widgets when necessary

---

# 5. Elementor Integration

The plugin connects data and functionality to Elementor.

General flow:

Plugin
    ↓
Database / Data
    ↓
Business Logic
    ↓
Elementor Integration
    ↓
Elementor Page
    ↓
User

The visual design remains inside Elementor.

Example:

Instructor data
    ↓
Instructor module
    ↓
Elementor dynamic data/widget
    ↓
Instructor page designed in Elementor

The plugin must never force a specific visual design unless a special
functional component requires it.

---

# 6. Module Architecture

Every major module should follow this structure:

modules/
└── module-name/
    ├── module-name.php
    ├── class-module-name.php
    ├── functions.php
    ├── ajax.php
    │
    ├── elementor/
    │   ├── class-elementor.php
    │   ├── dynamic-tags.php
    │   └── widgets/
    │
    ├── assets/
    │   ├── css/
    │   └── js/
    │
    └── admin/
        ├── class-admin.php
        └── templates/

Not every file must contain code immediately.

Files should only receive functionality when that functionality is
actually required.

---

# 7. Module Responsibilities

Each module is responsible for its own:

- Data
- Database logic
- Business logic
- Admin interface
- AJAX
- Elementor integration
- CSS
- JavaScript
- Validation
- Permissions related to that module

A module should not directly modify another module's internal logic.

If communication between modules is necessary, use WordPress hooks,
actions, filters, or a clearly defined shared API.

---

# 8. Core Responsibilities

The core contains functionality shared by multiple modules.

## loader.php

Responsible for loading modules.

It must NOT contain module-specific business logic.

## database.php

Contains shared database helpers.

Module-specific tables and queries belong to their own modules.

## assets.php

Contains shared helpers for loading CSS and JavaScript.

Module assets should normally be loaded only when needed.

## helpers.php

Contains generic helper functions used across modules.

Module-specific helpers belong inside the module.

## permissions.php

Contains shared security and permission helpers.

Module-specific permission rules belong inside the module.

## elementor.php

Contains the shared Elementor integration layer.

Module-specific Elementor functionality belongs inside the module.

---

# 9. Database Rules

Database design must be done per module.

Do NOT create one giant database table for the entire plugin.

Each module should only store the data it owns.

Before creating a new table, determine whether WordPress native
structures or existing plugin data can be safely reused.

Database changes must be:

- Sanitized
- Validated
- Prepared
- Secure
- Compatible with WordPress database APIs

Never directly concatenate untrusted user input into SQL queries.

---

# 10. Security Rules

All user input must be validated and sanitized.

AJAX requests must use:

- Nonces
- Permission checks
- Sanitization
- Validation

Admin actions must verify user capabilities.

Never trust:

- GET
- POST
- AJAX
- URL parameters
- Form submissions
- User IDs
- Database IDs

All external input is considered untrusted.

---

# 11. AJAX Rules

AJAX handlers belong inside the module that owns the functionality.

Example:

modules/instructors/ajax.php

should contain instructor-related AJAX actions.

Do not place instructor AJAX logic inside Core.

AJAX requests must use WordPress nonces and appropriate permission checks.

---

# 12. CSS Rules

Each module owns its own CSS.

Example:

modules/instructors/assets/css/instructors.css

Do not create one huge CSS file containing all modules.

Avoid global CSS that can accidentally affect:

- Elementor
- Theme
- Other modules
- WordPress Admin

Use module-specific class prefixes.

Example:

.academy-instructors-*

.academy-courses-*

.academy-events-*

---

# 13. JavaScript Rules

Each module owns its own JavaScript.

Example:

modules/instructors/assets/js/instructors.js

JavaScript should be loaded only where required.

Avoid global variables.

Use module-specific namespaces or scoped code.

---

# 14. Admin Rules

Each module has its own admin functionality.

Example:

modules/instructors/admin/

The module admin is responsible for:

- CRUD
- Settings
- Data management
- Validation
- Admin AJAX
- Admin assets

Do not put module-specific admin logic inside the Core.

---

# 15. Elementor Widget Rules

Custom Elementor widgets should only be created when normal Elementor
functionality cannot provide the required data integration.

Before creating a custom widget, check whether the requirement can be
implemented using:

- Elementor dynamic tags
- Custom fields
- Shortcodes
- Existing Elementor widgets
- Elementor templates

Avoid unnecessary custom widgets.

---

# 16. Page Design Rule

Pages are created in Elementor.

For example:

Instructor Profile Page

Elementor:
- Hero
- Instructor photo
- Name
- Biography layout
- Courses section
- Social links
- Buttons
- Typography
- Responsive layout

Plugin:
- Instructor data
- Instructor ID
- Database
- Dynamic values
- Course relationships
- Admin management

The plugin provides the data/functionality.
Elementor controls the visual page.

---

# 17. Development Workflow

Every module must follow this workflow:

STEP 1
Define requirements.

STEP 2
Define module architecture.

STEP 3
Define data/database requirements.

STEP 4
Define admin requirements.

STEP 5
Define Elementor integration.

STEP 6
Create module files.

STEP 7
Implement backend/data logic.

STEP 8
Implement admin functionality.

STEP 9
Implement Elementor integration.

STEP 10
Design the actual pages in Elementor.

STEP 11
Connect Elementor pages to module data.

STEP 12
Test desktop.

STEP 13
Test mobile.

STEP 14
Test security and permissions.

STEP 15
Test AJAX and edge cases.

STEP 16
Document the completed module.

Only after the current module is stable should development move to
the next module.

---

# 18. Chat Separation Rule

Each major module is developed in a separate conversation.

Example:

Chat 1
Instructors

Chat 2
Courses

Chat 3
Seminars

Chat 4
Events

Chat 5
Articles

The architecture in this document remains the common reference for
all module conversations.

A new module conversation must NOT redesign the entire architecture.

---

# 19. No Architecture Drift

The following must NOT happen without a clear reason:

- Renaming the main plugin
- Moving Core files
- Changing module architecture
- Creating duplicate Core systems
- Creating duplicate database systems
- Creating duplicate Elementor systems
- Moving page design from Elementor into PHP
- Creating module functionality inside another module
- Creating random global CSS/JS
- Rebuilding an existing system unnecessarily

If a structural change becomes necessary, document it first.

---

# 20. Testing Rule

Before declaring a module complete, test:

- Plugin activation
- WordPress admin
- Frontend
- Elementor editor
- Desktop
- Tablet
- Mobile
- AJAX
- Forms
- Permissions
- Nonces
- Empty data
- Invalid data
- Missing data
- Logged-in users
- Logged-out users
- PHP warnings
- PHP fatal errors
- JavaScript errors

---

# 21. Backward Compatibility

New modules must not break existing modules.

When modifying Core, test existing modules after the change.

Avoid changing shared Core functionality unless necessary.

---

# 22. Documentation Rule

Every completed module should contain a README.md describing:

- Purpose
- Features
- Database
- Admin
- Elementor integration
- AJAX
- Assets
- Dependencies
- Pages
- Shortcodes
- Hooks
- Important implementation notes

Example:

modules/instructors/README.md

---

# 23. Current Modules

The current planned modules are:

1. Homepage
2. Instructors
3. Courses
4. Seminars
5. Events
6. Articles
7. Testimonials
8. FAQ
9. Contact
10. Notifications

The exact module list can grow as the project grows.

New modules should follow the same architecture.

---

# 24. Important Project Constraint

The Academy website is being developed under a modular architecture.

The goal is:

One plugin
    +
Independent modules
    +
Elementor page design
    +
Shared Core
    =
Maintainable Academy Website

Do not sacrifice the architecture for a quick one-off implementation.

---

# 25. Final Rule

When starting any new module:

1. Read this architecture.
2. Understand the existing Core.
3. Inspect existing modules if relevant.
4. Define the new module.
5. Keep the module isolated.
6. Keep page design in Elementor.
7. Build only the functionality required by the module.
8. Test it completely.
9. Document it.
10. Then move to the next module.