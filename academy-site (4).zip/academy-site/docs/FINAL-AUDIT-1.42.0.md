# Academy Site 1.42.0 — Final Static Audit

## Architecture
- Core loads shared services and a fail-soft module loader.
- Admin Hub is bootstrapped directly so its menu does not depend on optional module loading.
- Module manifest contains unique module names and each module has its own entry file.
- Deactivation only clears scheduled jobs and rewrite rules; it does not delete student/order/certificate data.

## Elementor HTML Widget
- HTML rendering is limited to Elementor HTML widgets.
- `{{markers}}` are resolved by a stable backend renderer.
- Collection wrappers supported: courses, instructors, events, seminars, articles, FAQ, course lessons, event tickets.
- Global page URL markers are configurable from Academy Site → page settings.
- Course price markers include regular, sale/current, discount percentage and final HTML.
- Course action switches to `مشاهده دوره` only when the logged-in user has enrollment access.
- VIP/CIP event tickets expose a stable ticket class for Elementor CSS.
- Student avatar is not part of the student contract.

## Auth / OTP
- Login and registration use separate OTP purposes and SMS templates.
- OTP is 6 digits, valid for 120 seconds, with a 6-second delivery delay.
- The OTP page performs client-side delivery after the 6-second delay and WordPress cron remains the fallback.
- Resend creates a new challenge after cooldown and cancels older pending challenges.
- Verification requires a delivered, unexpired, pending challenge and has attempt limits.
- OTP delivery payload is encrypted at rest in the transient when OpenSSL is available.

## SMS.ir
- One API Key setting.
- Independent Template ID setting for each transactional/CRM message.
- SMS provider access is centralized in `Academy_Site_SMS`.
- Parameters are filtered by template contract.
- Transactional sends use idempotency keys.
- Birthday SMS and birthday wallet gift are independent idempotent operations.

## CRM / Birthday / Wallet
- CRM supports groups and profile segmentation.
- Campaign execution is idempotent per campaign/user.
- Birthday detection uses the site's WordPress timezone.
- Birthday wallet gifts can expire and the wallet expiry scheduler creates an expiration debit for unused credit.

## Commerce / ZarinPal
- Academy order and payment transaction tables are independent from course/event modules.
- ZarinPal request → gateway → callback → server-side verify is implemented.
- Enrollment/event registration is triggered only after verified Academy payment.
- Paid orders are protected from duplicate callback processing.

## Certificates
- Templates support text, image, and image+text modes.
- Issuance stores student, national ID, template and verification code.
- Certificate rendering resolves student/course/verification placeholders.
- Public verification works by verification code and national ID.
- Each certificate has its own QR verification URL.

## Static checks performed for this release
- All PHP files: `php -l` — pass.
- Auth JavaScript: `node --check` — pass.
- Elementor final HTML marker audit: 101 markers checked, no unknown markers.
- Final Elementor HTML templates: 22 files.
- Module manifest entry-file check: pass.
- Duplicate PHP class-name scan: no duplicate class definitions found.

## Runtime limitation
A real SMS.ir send and a real ZarinPal payment cannot be truthfully marked as live-tested without the site's real API key, Template IDs, Merchant ID and a real/sandbox transaction. Those integrations are isolated and configured from the WordPress admin so the credentials do not require code changes.
