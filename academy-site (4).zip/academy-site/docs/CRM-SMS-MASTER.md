# Academy CRM + SMS Master

## SMS.ir settings
All SMS.ir credentials live in **Settings → Academy SMS**. No Template ID is hard-coded in modules.

Required configuration:
- API Key
- Template ID: login OTP
- Template ID: registration OTP
- Template ID: recovery OTP
- Template ID: birthday
- Template ID: consultation
- Template ID: consultation admin
- Template ID: support
- Template ID: event registration
- Template ID: course purchase
- Template ID: course completed
- Template ID: certificate
- Template ID: CRM campaign
- Template ID: custom

The provider request uses SMS.ir's template/verify endpoint with `X-API-KEY`, `Mobile`, `TemplateId`, and `Parameters`. The API endpoint is centralized in the SMS module so authentication, logging and idempotency are shared.

## Supported SMS.ir parameter names
The SMS module supports the variable names shown in the SMS.ir panel, including:

`#TOKEN#`, `#OTP#`, `#CODE#`, `#NAME#`, `#TIME#`, `#VERIFICATIONCODE#`,
`#DATE#`, `#USERNAME#`, `#FULLNAME#`, `#ORDERID#`, `#PASSWORD#`, `#TITLE#`,
`#AMOUNT#`, `#PRICE#`, `#ORDER_NUMBER#`, `#LINK#`, `#STATUS#`,
`#ITEMS_COUNT#`, `#PHONE#` and Academy CRM/event/course/certificate variables.

The admin does not select variables per Template ID. The Template ID is the only
template-specific value. Academy builds all values it has for the current user
and event, removes empty values, and sends the remaining name/value pairs to
SMS.ir. Existing module calls can use either the SMS.ir uppercase names or the
legacy CamelCase aliases; the SMS module normalizes them centrally.

Important: SMS.ir still requires the variables actually used by a template to
match the names configured in that template. The plugin cannot invent a value
for a variable for which the current event has no data.
## Automatic birthday
A daily WordPress cron scans registered users with `birth_date`. A birthday message is sent once per user per local calendar day. A successful send has an idempotency key so repeated cron runs do not duplicate it.

## CRM segmentation
The CRM supports combinations of:
- Gender
- Province
- City
- Student status
- CRM group
- Minimum/maximum age
- Course access/purchase
- Course completion
- Event registration
- Birthday today
- Registration date range

Users can belong to multiple CRM groups. Groups are stored independently from user profile fields.

## SMS safety
- OTP codes are not stored in plaintext.
- SMS sending is centralized.
- Missing API keys or Template IDs stop the message and create a failed log entry.
- Provider errors are logged.
- Campaign execution is idempotent per campaign/user.
- SMS send operations can also carry an idempotency key, preventing duplicate transactional messages such as purchase, certificate, event and birthday notifications.
- Iranian mobile numbers are normalized before provider submission.
