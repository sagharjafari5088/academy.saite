# Academy Site 1.42.0 — Final Specification

## Architecture
- Core + independently loadable modules.
- Module failure is caught/logged and does not intentionally abort the rest of the plugin.
- Each module owns its own tables/migrations.
- Elementor owns HTML/CSS/layout/responsive behavior.
- Backend exposes a stable marker contract for Elementor HTML Widget.
- Existing markers are additive/stable; new fields are added without renaming old markers.

## Student/Auth
- Mobile-only login and registration.
- Login rejects unregistered numbers; registration rejects existing numbers.
- Separate SMS.ir templates for login OTP and registration OTP.
- OTP is 6 digits, delivered after 6 seconds, valid for 2 minutes, with cooldown/rate/attempt limits.
- Registration completion stores first name, last name, mobile, birth date, gender, province and city in WordPress user meta.
- Successful registration triggers welcome SMS and authenticated session.

## SMS.ir
- One API Key field.
- Per-message Template ID fields.
- Central SMS service with logging, idempotency and parameter filtering.
- CRM campaigns may optionally override Template ID per campaign.

## CRM
- Student segmentation by group, gender, province, city, status, age, courses, completed courses, events and birthday.
- Scheduled campaigns.
- Birthday SMS and configurable wallet gift with configurable expiry (default 24 hours).

## Instructors
- Image, name, title/activity area, description.
- Single/loop outputs and QR.

## Courses
- Title, subtitle, poster, description, outcomes, lessons, duration, sessions, instructor, certificate type/online availability.
- Regular/current/sale pricing.
- Coming Soon.
- Purchased students receive "مشاهده دوره" instead of purchase.
- Course learning-host/LMS delivery is intentionally deferred.

## Events
- Poster, date, time, location, speakers, capacity and ticket types.
- Ticket checkout collects first name, last name, national ID, mobile and optional organization.
- Paid registration creates ticket/invitation data and QR.

## Certificates
- Certificate templates can be text, image, or image+text.
- Manual issuance by student, national ID, optional course and template.
- Public lookup by national ID returns issued certificates.
- Each certificate has a unique verification code and QR URL.

## Student Panel
- Presentation-agnostic dynamic data for name, courses, certificates, events, wallet, orders, transactions and recommendations.
- No avatar requirement.

## Consultation
- Three consultation types.
- First name, last name, mobile, preferred morning/afternoon contact period and reason.
- SMS to applicant and configured consultant.

## Commerce / ZarinPal
- Independent Academy order and transaction tables.
- ZarinPal adapter stores Merchant ID in settings.
- Payment request → gateway → callback → server-side verify → paid order.
- Enrollment is granted only after verified payment.
- Event ticket registration is created only after verified payment.
- Duplicate callbacks are protected by paid-state/idempotency checks.
