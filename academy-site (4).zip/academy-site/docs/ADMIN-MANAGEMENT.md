# Academy Site — Central Admin Management

Version 1.45.0.

The WordPress **Academy Site** menu is the central management entry point. Front-end presentation remains Elementor/HTML-widget driven and is not coupled to these admin screens.

## Student file
Each student has a dedicated file with:
- identity/contact data
- gender, province, city, birth date and national ID
- active/inactive status
- wallet balance and manual credit/debit
- optional expiry for manually added credit
- course access grant/revoke and optional start/expiry
- certificates
- event registrations/tickets

## Other modules
- Instructors: create/edit profile data and image/QR payload.
- Courses: create/edit title, subtitle, descriptions, poster, instructor, prices (regular/sale/current), Coming Soon, duration, sessions, outcomes and certificate flag.
- Events: create/edit event data, capacity, speakers, invitation and ticket types.
- Certificates: existing certificate manager is exposed from the central Academy menu.
- CRM: existing segmentation/group/campaign manager is exposed from the central Academy menu.
- SMS.ir: API key and per-purpose Template IDs are managed by the SMS module and exposed from the central Academy menu.
- Commerce: ZarinPal settings and recent orders are exposed from the central Academy menu.
- Consultations: request list and status/consultant assignment are managed from Academy Site.
- Wallet: ledger and latest transactions are visible centrally; per-student changes are performed in the student file.
